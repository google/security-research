Exploit for kctf LTS 6.6.38
Run command "nsenter --target 1 -m -p" after run the bin/exploit.bin 
