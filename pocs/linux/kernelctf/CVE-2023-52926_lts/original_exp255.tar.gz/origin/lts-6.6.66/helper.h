#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/sendfile.h>
#include <err.h>
#include <stdbool.h>
#include <sched.h>

void set_stext_page(size_t page,size_t stext);

size_t virt_to_page(size_t addr);

size_t page_to_virt(size_t);

size_t helper_init();

size_t get_file_pa(int fd);

size_t get_file(int fd);

void kwrite64(size_t addr, size_t val);

size_t kread64(size_t addr);

size_t vmalloc(size_t size);

size_t kmalloc(size_t size);

size_t get_vma(size_t addr);

void kfree(size_t addr);

void print_kstring(size_t addr);

void set_cpu(int i);

void hexdump(void *_data, size_t byte_count);

