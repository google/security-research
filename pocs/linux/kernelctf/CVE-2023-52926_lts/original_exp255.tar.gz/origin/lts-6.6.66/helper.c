#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/sendfile.h>
#include <err.h>
#include <sys/ioctl.h>
#include <stdbool.h>

static int helper_fd;
#define DEV_HELPER "/dev/note3"

#define SYSCHK(x) ({              \
    typeof(x) __res = (x);        \
    if (__res == (typeof(x))-1)   \
        err(1, "SYSCHK(" #x ")"); \
    __res;                        \
})

#define mem_map 0xfffffffe00000000UL
#define PAGE_OFFSET 0xffffff8000000000UL

static size_t stext_page;
static size_t _stext;
void set_stext_page(size_t page, size_t stext)
{
    stext_page = page;
    _stext = stext;
}
size_t virt_to_page(size_t addr)
{
    if (((addr >> 36) & 0xf) == 0xc)
        return stext_page + (((addr - _stext) >> 12) << 6);
    else
        return (((addr - PAGE_OFFSET) >> 12) << 6) + mem_map;
}

size_t page_to_virt(size_t v13)
{
    return (v13 << 6) & 0xFFFFFFFFFFF000LL | 0xFF00000000000000LL;
}

size_t helper_init()
{
    //helper_fd = SYSCHK(open(DEV_HELPER, O_RDONLY));
    helper_fd = -1;
    return 0;
}
size_t get_file_pa(int fd)
{
    if (helper_fd < 0)
        return 0;
    size_t buf[2] = {};
    buf[0] = fd;
    ioctl(helper_fd, 0x664, buf);
    return buf[1];
}

size_t get_file(int fd)
{
    if (helper_fd < 0)
        return 0;
    size_t buf[2] = {};
    buf[0] = fd;
    ioctl(helper_fd, 0x661, buf);
    return buf[1];
}
void kwrite64(size_t addr, size_t val)
{
    if (helper_fd < 0)
        return;
    size_t buf[2] = {};
    buf[0] = addr;
    buf[1] = val;
    ioctl(helper_fd, 0x667, buf);
}
size_t kread64(size_t addr)
{
    if (helper_fd < 0)
        return 0;
    size_t buf[2] = {};
    buf[0] = addr;
    ioctl(helper_fd, 0x666, buf);
    return buf[1];
}

size_t get_vma(size_t addr)
{
    if (helper_fd < 0)
        return 0;
    size_t buf[2] = {};
    buf[0] = addr;
    ioctl(helper_fd, 0x700, buf);
    return buf[1];
}

size_t kmalloc(size_t size)
{
    if (helper_fd < 0)
        return 0;
    size_t buf[2] = {};
    buf[0] = size;
    ioctl(helper_fd, 0x662, buf);
    return buf[1];
}

size_t vmalloc(size_t size)
{
    if (helper_fd < 0)
        return 0;
    size_t buf[2] = {0, 1};
    buf[0] = size;
    ioctl(helper_fd, 0x662, buf);
    return buf[1];
}

void kfree(size_t addr)
{
    if (helper_fd < 0)
        return;
    size_t buf[2] = {};
    buf[0] = addr;
    ioctl(helper_fd, 0x663, buf);
}
void print_kstring(size_t addr)
{
    if (helper_fd < 0)
        return;
    if (addr == 0)
    {
        puts("");
        return;
    }
    size_t ne[0x10] = {};
    for (int i = 0; i < 0x10; i++)
        ne[i] = kread64(addr + i * 8);
    puts((char *)(ne));
}

void hexdump(void *_data, size_t byte_count)
{
    // printf("hexdump(%p, 0x%lx)\n", _data, (unsigned long)byte_count);
    for (unsigned long byte_offset = 0; byte_offset < byte_count;
         byte_offset += 16)
    {
        unsigned char *bytes = ((unsigned char *)_data) + byte_offset;
        unsigned long line_bytes = (byte_count - byte_offset > 16) ? 16 : (byte_count - byte_offset);
        char line[1000];
        char *linep = line;
        linep += sprintf(linep, "%08lx  ", byte_offset);
        for (int i = 0; i < 16; i++)
        {
            if (i >= line_bytes)
            {
                linep += sprintf(linep, "   ");
            }
            else
            {
                linep += sprintf(linep, "%02hhx ", bytes[i]);
            }
        }
        linep += sprintf(linep, " |");
        for (int i = 0; i < line_bytes; i++)
        {
            if (isalnum(bytes[i]) || ispunct(bytes[i]) ||
                bytes[i] == ' ')
            {
                *(linep++) = bytes[i];
            }
            else
            {
                *(linep++) = '.';
            }
        }
        linep += sprintf(linep, "|");
        puts(line);
    }
}