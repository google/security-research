#!/bin/bash

gcc -O2 -L . -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-6.6.27 exploit-6.6.27.c  -pthread -lm -lnl-cli-3 -lnl-route-3 -lnl-3 -lnl-nf-3 -ldl -DDEBUG
