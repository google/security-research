#!/bin/bash

gcc -O2 -L . -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-17800.147.54 exploit-17800.147.54.c  -pthread -lm -lnl-cli-3 -lnl-route-3 -lnl-3 -lnl-nf-3 -ldl -DDEBUG
