#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-17412.226.68 exploit-17412.226.68.c  -pthread -lm 
