#ifndef _MSG_H_
#define _MSG_H_

#include <sys/ipc.h>
#include <sys/msg.h>

#define MTYPE_PRIMARY 0x41
#define MTYPE_SECONDARY 0x42
#define MTYPE_FAKE 0x43

typedef struct
{
    long mtype;
    char mtext[0];
} msg_t;

struct list_head
{
    struct list_head *next, *prev;
};

struct msg_msg
{
    struct list_head m_list;
    long m_type;
    size_t m_ts; /* message text size */
    uint64_t next;
    uint64_t security;
    uint8_t text[0];
};

#endif