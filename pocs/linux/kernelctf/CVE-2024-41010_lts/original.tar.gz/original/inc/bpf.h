#ifndef _BPF_H_
#define _MSG_H_

#include <linux/bpf.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "bpf_insn.h"

int bpf(int cmd, union bpf_attr *attrs);
int map_create(int val_size, int max_entries);
int map_update(int mapfd, int key, void *pval);
int map_lookup(int mapfd, int key, void *pval);

#endif