#ifndef _SETUP_H_
#define _SETUP_H_

#include <stdlib.h>
#include <unistd.h>

#define DEF_CORE 0

void assign_to_core(int core_id);
int setup_sandbox(void);


#endif /* _SETUP_H_ */