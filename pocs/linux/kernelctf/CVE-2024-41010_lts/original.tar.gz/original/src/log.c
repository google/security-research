
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


/* Hexdump utility for debugging purposes */
void hexdump(void *mem, unsigned int len)
{
    unsigned int i = 0, j = 0;

    for (i = 0; i < len + ((len % 16) ? (16 - len % 16) : 0); i++)
    {
        if (i % 16 == 0)
            printf("0x%06x: ", i);

        if (i < len)
            printf("%02x ", 0xFF & ((char *)mem)[i]);
        else
            printf("   ");

        if (i % 16 == (16 - 1))
        {
            for (j = i - (16 - 1); j <= i; j++)
            {
                if (j >= len)
                    putchar(' ');
                else if (isprint(((char *)mem)[j]))
                    putchar(0xFF & ((char *)mem)[j]);
                else
                    putchar('.');
            }
            putchar('\n');
        }
    }
    return;
}