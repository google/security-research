extern int cur_handle;
#define htonll(x) ((1==htonl(1)) ? (x) : ((uint64_t)htonl((x) & 0xFFFFFFFF) << 32) | htonl((x) >> 32))

void new_rule(struct nl_sock * socket, char *table_name, char *chain_name, char *set_name){
    struct nl_msg * msg = nlmsg_alloc();
    //(NFNL_SUBSYS_IPSET << 8) | (IPSET_CMD_CREATE);
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            NFNL_MSG_BATCH_BEGIN,   // TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    struct nfgenmsg * h = malloc(sizeof(struct nfgenmsg));
    h->nfgen_family = 2;//NFPROTO_IPV4;
    h->version = 0;
    h->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr1), h, sizeof(struct nfgenmsg));

    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_NEWRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST|NLM_F_CREATE //NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * msg3 = nlmsg_alloc();
    struct nlmsghdr *hdr3 = nlmsg_put(
            msg3,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            NFNL_MSG_BATCH_END,// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    struct nl_msg * exprs = nlmsg_alloc();
    struct nl_msg *data_nest = nlmsg_alloc();
    struct nl_msg *expr_data = nlmsg_alloc(); 
    
    char *a = malloc(0x100);
    memset(a,0x41,0x100);
    nla_put_string(expr_data, NFTA_LOOKUP_SET, set_name);
    nla_put_u32(expr_data, NFTA_LOOKUP_SREG, htonl(NFT_REG_1));
    nla_put_string(data_nest, NFTA_EXPR_NAME, "lookup");
    nla_put_nested(data_nest, NFTA_EXPR_DATA, expr_data);

    nla_put_nested(exprs, NFTA_LIST_ELEM, data_nest);
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_nested(msg2, NFTA_RULE_EXPRESSIONS, exprs);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len) + NLMSG_ALIGN(hdr2->nlmsg_len) + NLMSG_ALIGN(hdr3->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    memcpy(buf+NLMSG_ALIGN(hdr1->nlmsg_len),hdr2, NLMSG_ALIGN(hdr2->nlmsg_len));
    memcpy(buf+NLMSG_ALIGN(hdr1->nlmsg_len)+NLMSG_ALIGN(hdr2->nlmsg_len),hdr3,NLMSG_ALIGN(hdr3->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
        printf("Create rule\n");
    }
    cur_handle++;
}

struct nlmsghdr * new_rule_lookup_msg(char *table_name, char *chain_name, char *set_name){
    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_NEWRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST|NLM_F_CREATE //NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * exprs = nlmsg_alloc();
    struct nl_msg *data_nest = nlmsg_alloc();
    struct nl_msg *expr_data = nlmsg_alloc();

    char *a = malloc(0x100);
    memset(a,0x41,0x100);
    nla_put_string(expr_data, NFTA_LOOKUP_SET, set_name);
    nla_put_u32(expr_data, NFTA_LOOKUP_SREG, htonl(NFT_REG_1));
    nla_put_string(data_nest, NFTA_EXPR_NAME, "lookup");
    nla_put_nested(data_nest, NFTA_EXPR_DATA, expr_data);

    nla_put_nested(exprs, NFTA_LIST_ELEM, data_nest);
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_nested(msg2, NFTA_RULE_EXPRESSIONS, exprs);
    cur_handle++;
    return hdr2;
}

void new_rule_immediate(struct nl_sock * socket, char *table_name, char *chain_name, uint32_t code, char *target_chain){
    struct nl_msg * msg = nlmsg_alloc();
    //(NFNL_SUBSYS_IPSET << 8) | (IPSET_CMD_CREATE);
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            NFNL_MSG_BATCH_BEGIN,   // TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    struct nfgenmsg * h = malloc(sizeof(struct nfgenmsg));
    h->nfgen_family = 2;//NFPROTO_IPV4;
    h->version = 0;
    h->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr1), h, sizeof(struct nfgenmsg));

    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_NEWRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST|NLM_F_CREATE //NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * msg3 = nlmsg_alloc();
    struct nlmsghdr *hdr3 = nlmsg_put(
            msg3,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            NFNL_MSG_BATCH_END,// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    struct nl_msg * exprs = nlmsg_alloc();
    struct nl_msg *data_nest = nlmsg_alloc();
    struct nl_msg *expr_data = nlmsg_alloc();
    struct nl_msg *data = nlmsg_alloc();
    struct nl_msg *data_verdict = nlmsg_alloc();
    

    nla_put_u32(data_verdict, NFTA_VERDICT_CODE, htonl(code));
    if(code==NFT_JUMP)
	    nla_put_string(data_verdict, NFTA_VERDICT_CHAIN, target_chain);
    nla_put_nested(data, NFTA_DATA_VERDICT, data_verdict);

    nla_put_u32(expr_data, NFTA_IMMEDIATE_DREG, htonl(NFT_REG_VERDICT));
    nla_put_nested(expr_data, NFTA_IMMEDIATE_DATA, data);

    nla_put_string(data_nest, NFTA_EXPR_NAME, "immediate");
    nla_put_nested(data_nest, NFTA_EXPR_DATA, expr_data);

    nla_put_nested(exprs, NFTA_LIST_ELEM, data_nest);
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_nested(msg2, NFTA_RULE_EXPRESSIONS, exprs);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len) + NLMSG_ALIGN(hdr2->nlmsg_len) + NLMSG_ALIGN(hdr3->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    memcpy(buf+NLMSG_ALIGN(hdr1->nlmsg_len),hdr2, NLMSG_ALIGN(hdr2->nlmsg_len));
    memcpy(buf+NLMSG_ALIGN(hdr1->nlmsg_len)+NLMSG_ALIGN(hdr2->nlmsg_len),hdr3,NLMSG_ALIGN(hdr3->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
        printf("Create rule\n");
    }
    cur_handle++;
}

void del_rule(struct nl_sock * socket, char *table_name, char *chain_name, uint64_t handle){
    struct nl_msg * msg = nlmsg_alloc();
    //(NFNL_SUBSYS_IPSET << 8) | (IPSET_CMD_CREATE);
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            NFNL_MSG_BATCH_BEGIN,   // TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    struct nfgenmsg * h = malloc(sizeof(struct nfgenmsg));
    h->nfgen_family = 2;//NFPROTO_IPV4;
    h->version = 0;
    h->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr1), h, sizeof(struct nfgenmsg));

    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_DELRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST//NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * msg3 = nlmsg_alloc();
    struct nlmsghdr *hdr3 = nlmsg_put(
            msg3,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            NFNL_MSG_BATCH_END,// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_u64(msg2, NFTA_RULE_HANDLE, htonll(handle));
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len) + NLMSG_ALIGN(hdr2->nlmsg_len) + NLMSG_ALIGN(hdr3->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    memcpy(buf+NLMSG_ALIGN(hdr1->nlmsg_len),hdr2, NLMSG_ALIGN(hdr2->nlmsg_len));
    memcpy(buf+NLMSG_ALIGN(hdr1->nlmsg_len)+NLMSG_ALIGN(hdr2->nlmsg_len),hdr3,NLMSG_ALIGN(hdr3->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
        //printf("Delete rule\n");
    }
}

struct nlmsghdr * del_rule_msg(char *table_name, char *chain_name, uint64_t handle){
    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_DELRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST//NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));

    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_u64(msg2, NFTA_RULE_HANDLE, htonll(handle));
    return hdr2;
}

struct nlmsghdr * new_rule_immediate_msg(char *table_name, char *chain_name, uint32_t code, char *target_chain){
    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_NEWRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST|NLM_F_CREATE //NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * exprs = nlmsg_alloc();
    struct nl_msg *data_nest = nlmsg_alloc();
    struct nl_msg *expr_data = nlmsg_alloc();
    struct nl_msg *data = nlmsg_alloc();
    struct nl_msg *data_verdict = nlmsg_alloc();

    nla_put_u32(data_verdict, NFTA_VERDICT_CODE, htonl(code));
    if(code==NFT_JUMP)
            nla_put_string(data_verdict, NFTA_VERDICT_CHAIN, target_chain);
    nla_put_nested(data, NFTA_DATA_VERDICT, data_verdict);

    nla_put_u32(expr_data, NFTA_IMMEDIATE_DREG, htonl(NFT_REG_VERDICT));
    nla_put_nested(expr_data, NFTA_IMMEDIATE_DATA, data);

    nla_put_string(data_nest, NFTA_EXPR_NAME, "immediate");
    nla_put_nested(data_nest, NFTA_EXPR_DATA, expr_data);

    nla_put_nested(exprs, NFTA_LIST_ELEM, data_nest);
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_nested(msg2, NFTA_RULE_EXPRESSIONS, exprs);
    cur_handle++;
    return hdr2;
}

struct nlmsghdr * new_rule_lookup_for_chain_msg(char *table_name, char *chain_name, char *set_name, int if_dreg){
    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_NEWRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST|NLM_F_CREATE //NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * exprs = nlmsg_alloc();
    struct nl_msg *data_nest = nlmsg_alloc();
    struct nl_msg *expr_data = nlmsg_alloc();

    char *a = malloc(0x100);
    memset(a,0x41,0x100);
    if(if_dreg)
        nla_put_u32(expr_data, NFTA_LOOKUP_DREG, htonl(NFT_REG_2));
    nla_put_string(expr_data, NFTA_LOOKUP_SET, set_name);
    nla_put_u32(expr_data, NFTA_LOOKUP_SREG, htonl(NFT_REG_1));
    nla_put_string(data_nest, NFTA_EXPR_NAME, "lookup");
    nla_put_nested(data_nest, NFTA_EXPR_DATA, expr_data);

    nla_put_nested(exprs, NFTA_LIST_ELEM, data_nest);
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_nested(msg2, NFTA_RULE_EXPRESSIONS, exprs);
    cur_handle++;
    return hdr2;
}
