#ifndef PWN_TC_FILTERS_H
#define PWN_TC_FILTERS_H

#define PWN_TC_FILTER_INTERFACE "lo"

// sub: filter section
int get_u32(__u32 *val, const char *arg, int base)
{
	unsigned long res;
	char *ptr;

	if (!arg || !*arg)
		return -1;
	res = strtoul(arg, &ptr, base);

	/* empty string or trailing non-digits */
	if (!ptr || ptr == arg || *ptr)
		return -1;

	/* overflow */
	if (res == ULONG_MAX && errno == ERANGE)
		return -1;

	/* in case UL > 32 bits */
	if (res > 0xFFFFFFFFUL)
		return -1;

	*val = res;
	return 0;
}

static int get_u32_handle_(__u32 *handle, const char *str)
{
	__u32 htid = 0, hash = 0, nodeid = 0;
	char *tmp = strchr(str, ':');

	if (tmp == NULL) {
		if (memcmp("0x", str, 2) == 0)
			return get_u32(handle, str, 16);
		return -1;
	}
	htid = strtoul(str, &tmp, 16);
	if (tmp == str && *str != ':' && *str != 0)
		return -1;
	if (htid >= 0x1000)
		return -1;
	if (*tmp) {
		str = tmp + 1;
		hash = strtoul(str, &tmp, 16);
		if (tmp == str && *str != ':' && *str != 0)
			return -1;
		if (hash >= 0x100)
			return -1;
		if (*tmp) {
			str = tmp + 1;
			nodeid = strtoul(str, &tmp, 16);
			if (tmp == str && *str != 0)
				return -1;
			if (nodeid >= 0x1000)
				return -1;
		}
	}
	*handle = (htid<<20)|(hash<<12)|nodeid;
	return 0;
}

__u32 get_u32_handle(const char* str) {
	__u32 handle = 0;
	if (get_u32_handle_(&handle, str)) {
		fatal("invalid u32 handle");
	}
	return handle;
}

int create_filter(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 target_class) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTFILTER;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));  // Protocol IP  TODO: why 1<<16 ? copied from https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_filter.c#L147

    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Simplified selector structure - match everything
    struct {
        struct tc_u32_sel sel;
        struct tc_u32_key keys[1];  // Only need one key for matching all
    } sel = {
        .sel = {
            .flags = TC_U32_TERMINAL,  // Terminal match
            .nkeys = 1,                // One key is sufficient
            .off = 0,
            .offmask = 0,
            .offshift = 0,
            .offoff = 0,
            .hoff = 0,
            .hmask = 0
        }
    };

    // Set up a key that matches everything
    sel.keys[0] = (struct tc_u32_key){
        .mask = 0,      // Match any value
        .val = 0,       // Value doesn't matter since mask is 0
        .off = 0,       // Start of packet
        .offmask = 0    // No offset mask needed
    };

    // Add the selector with the key
    mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set the target class
    mnl_attr_put_u32(nlh, TCA_U32_CLASSID, target_class);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

int create_filter_char(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 target_class, unsigned char first_byte) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTFILTER;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));  // Protocol IP  TODO: why 1<<16 ? copied from https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_filter.c#L147

    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Simplified selector structure - match everything
    struct {
        struct tc_u32_sel sel;
        struct tc_u32_key keys[1];  // Only need one key for matching all
    } sel = {
        .sel = {
            .flags = TC_U32_TERMINAL,  // Terminal match
            .nkeys = 1,                // One key is sufficient
            .off = 0,
            .offmask = 0,
            .offshift = 0,
            .offoff = 0,
            .hoff = 0,
            .hmask = 0
        }
    };

    // Set up a key that matches everything
	(void)first_byte;
    sel.keys[0] = (struct tc_u32_key){
        // .mask = 0x00000000,  // Mask for first byte
        .mask = 0xFF000000,  // Mask for first byte
        // .val = (__u32)0 << 24,  // Value to match, shifted to first byte position
        .val = (__u32)first_byte << 24,  // Value to match, shifted to first byte position
		.off = 20 + 0,           // IP header (20) + offset to dest port (2)
        .offmask = 0
    };

    // Add the selector with the key
    mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set the target class
    mnl_attr_put_u32(nlh, TCA_U32_CLASSID, target_class);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

int create_filter_char_specific(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 target_class, unsigned char first_byte, size_t offset) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTFILTER;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));
    
    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Simplified selector structure - match everything
    struct {
        struct tc_u32_sel sel;
        struct tc_u32_key keys[1];  // Only need one key for matching all
    } sel = {
        .sel = {
            .flags = TC_U32_TERMINAL,  // Terminal match
            .nkeys = 1,                // One key is sufficient
            .off = 0,
            .offmask = 0,
            .offshift = 0,
            .offoff = 0,
            .hoff = 0,
            .hmask = 0
        }
    };

    // Set up a key that matches everything
	(void)first_byte;
    sel.keys[0] = (struct tc_u32_key){
        .mask = 0xFF000000,  // Mask for first byte
        .val = (__u32)first_byte << 24,  // Value to match, shifted to first byte position
		.off = offset,           // IP header (20) + offset to dest port (2)
        .offmask = 0
    };

    // Add the selector with the key
    mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set the target class
    mnl_attr_put_u32(nlh, TCA_U32_CLASSID, target_class);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

int create_filter_char_top(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 target_class, unsigned char first_byte) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTFILTER;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));  // Protocol IP  TODO: why 1<<16 ? copied from https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_filter.c#L147

    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Simplified selector structure - match everything
    struct {
        struct tc_u32_sel sel;
        struct tc_u32_key keys[1];  // Only need one key for matching all
    } sel = {
        .sel = {
            .flags = TC_U32_TERMINAL,  // Terminal match
            .nkeys = 1,                // One key is sufficient
            .off = 0,
            .offmask = 0,
            .offshift = 0,
            .offoff = 0,
            .hoff = 0,
            .hmask = 0
        }
    };

    // Set up a key that matches everything
	(void)first_byte;
    sel.keys[0] = (struct tc_u32_key){
        // .mask = 0x00000000,  // Mask for first byte
        .mask = 0xF0000000,  // Mask for first byte
        // .val = (__u32)0 << 24,  // Value to match, shifted to first byte position
        .val = (__u32)first_byte << 24,  // Value to match, shifted to first byte position
		.off = 20 + 0,           // IP header (20) + offset to dest port (2)
        .offmask = 0
    };

    // Add the selector with the key
    mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set the target class
    mnl_attr_put_u32(nlh, TCA_U32_CLASSID, target_class);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

int create_filter_char_bottom(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 target_class, unsigned char first_byte) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTFILTER;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));  // Protocol IP  TODO: why 1<<16 ? copied from https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_filter.c#L147

    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Simplified selector structure - match everything
    struct {
        struct tc_u32_sel sel;
        struct tc_u32_key keys[1];  // Only need one key for matching all
    } sel = {
        .sel = {
            .flags = TC_U32_TERMINAL,  // Terminal match
            .nkeys = 1,                // One key is sufficient
            .off = 0,
            .offmask = 0,
            .offshift = 0,
            .offoff = 0,
            .hoff = 0,
            .hmask = 0
        }
    };

    // Set up a key that matches everything
	(void)first_byte;
    sel.keys[0] = (struct tc_u32_key){
        // .mask = 0x00000000,  // Mask for first byte
        .mask = 0x0F000000,  // Mask for first byte
        // .val = (__u32)0 << 24,  // Value to match, shifted to first byte position
        .val = (__u32)first_byte << 24,  // Value to match, shifted to first byte position
		.off = 20 + 0,           // IP header (20) + offset to dest port (2)
        .offmask = 0
    };

    // Add the selector with the key
    mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set the target class
    mnl_attr_put_u32(nlh, TCA_U32_CLASSID, target_class);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

#include <linux/tc_act/tc_skbedit.h>

int create_filter_qm(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 qm) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTFILTER;
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));  // Protocol IP  TODO: why 1<<16 ? copied from https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_filter.c#L147

    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Simplified selector structure - match everything
    struct {
        struct tc_u32_sel sel;
        struct tc_u32_key keys[1];  // Only need one key for matching all
    } sel = {
        .sel = {
            .flags = TC_U32_TERMINAL,  // Terminal match
            .nkeys = 1,                // One key is sufficient
            .off = 0,
            .offmask = 0,
            .offshift = 0,
            .offoff = 0,
            .hoff = 0,
            .hmask = 0
        }
    };

    // Set up a key that matches everything
    sel.keys[0] = (struct tc_u32_key){
        .mask = 0,      // Match any value
        .val = 0,       // Value doesn't matter since mask is 0
        .off = 0,       // Start of packet
        .offmask = 0    // No offset mask needed
    };

    // Add the selector with the key
    mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set up the skbedit action
    struct nlattr* actions_nest = mnl_attr_nest_start(nlh, TCA_U32_ACT);
    struct nlattr* action_nest = mnl_attr_nest_start(nlh, 1); // Index 1 for first action

    // Action kind: skbedit
    mnl_attr_put_strz(nlh, TCA_ACT_KIND, "skbedit");

    // Start action options
    struct nlattr* act_opts = mnl_attr_nest_start(nlh, TCA_ACT_OPTIONS);

    // Action header
    struct tc_skbedit skbedit_parm = {
        .action = TC_ACT_PIPE,  // Continue to next action, if any
        .index = 1              // Action index
    };
    mnl_attr_put(nlh, TCA_SKBEDIT_PARMS, sizeof(skbedit_parm), &skbedit_parm);

    // Queue mapping parameter - set to 2
    mnl_attr_put_u16(nlh, TCA_SKBEDIT_QUEUE_MAPPING, (__u16)qm);

    // End nested attributes
    mnl_attr_nest_end(nlh, act_opts);
    mnl_attr_nest_end(nlh, action_nest);
    mnl_attr_nest_end(nlh, actions_nest);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}


// int create_filter_char_eth0(int sock_fd, __u32 filter_handle, __u32 qdisc_handle, __u32 target_class, unsigned char first_byte) {
//     char buf[0x1000] = {0};
//     struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

//     nlh->nlmsg_type = RTM_NEWTFILTER;
//     nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

//     struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
//     tcm->tcm_family = AF_UNSPEC;
//     tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
//     tcm->tcm_handle = filter_handle;
//     tcm->tcm_parent = qdisc_handle;
//     tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));  // Protocol ALL

//     mnl_attr_put_strz(nlh, TCA_KIND, "u32");

//     struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

//     // Simplified selector structure - match everything
//     struct {
//         struct tc_u32_sel sel;
//         struct tc_u32_key keys[1];  // Only need one key for matching all
//     } sel = {
//         .sel = {
//             .flags = TC_U32_TERMINAL,  // Terminal match
//             .nkeys = 1,                // One key is sufficient
//             .off = 0,
//             .offmask = 0,
//             .offshift = 0,
//             .offoff = 0,
//             .hoff = 0,
//             .hmask = 0
//         }
//     };

// (void)first_byte;
//     // Set up a key that matches the first byte
//     sel.keys[0] = (struct tc_u32_key){
//         .mask = 0x0000ffff,  // Mask for first byte
//         .val = ((unsigned int)htons(1024 + first_byte)),  // Value to match, shifted to first byte position
//         .off = 20,            // Start of the packet
//         .offmask = 0
//     };

//     sel.keys[0] = (struct tc_u32_key){
//         .mask = 0xff000000,  // Mask for first byte of payload
//         .val = ((unsigned int)first_byte) << 24,  // First byte in network order
//         .off = 28,  // IP header (20) + UDP header (8)
//         .offmask = 0
//     };

//     // Add the selector with the key
//     mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

//     // Set the target class
//     mnl_attr_put_u32(nlh, TCA_U32_CLASSID, target_class);

//     mnl_attr_nest_end(nlh, opts);

//     return netlink_send(sock_fd, nlh);
// }

int delete_filter(int sock_fd, __u32 filter_handle, __u32 qdisc_handle) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    // Use RTM_DELTFILTER for deletion instead of RTM_NEWTFILTER
    nlh->nlmsg_type = RTM_DELTFILTER;
    // Remove NLM_F_CREATE flag since we're deleting
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;

    struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    tcm->tcm_ifindex = if_nametoindex(PWN_TC_FILTER_INTERFACE);
    tcm->tcm_handle = filter_handle;
    tcm->tcm_parent = qdisc_handle;
    tcm->tcm_info = TC_H_MAKE(1<<16, htons(ETH_P_ALL));

    // For deletion, we only need to specify the filter kind
    mnl_attr_put_strz(nlh, TCA_KIND, "u32");

	    struct nlattr* opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);

    // Add the selector with the key
    // mnl_attr_put(nlh, TCA_U32_SEL, sizeof(sel.sel) + sizeof(sel.keys[0]), &sel);

    // Set the target class
    mnl_attr_put_u32(nlh, TCA_U32_CLASSID, 65537);

    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

#endif