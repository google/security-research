#ifndef PWN_REPEAT_REQ_H
#define PWN_REPEAT_REQ_H

char *PWN_DST_IP = "127.0.0.1";

// get qdisc handle
__u32 gqh(const char *s_handle)
{
    __u32 result;
    SYSOK(get_qdisc_handle(&result, s_handle));
    return result;
}

// get class id
__u32 gci(const char *s_class)
{
    __u32 result;
    SYSOK(get_tc_classid(&result, s_class));
    return result;
}

__u32 get_id(const char *s_class)
{
    if (s_class[strlen(s_class) - 1] == '0' && s_class[strlen(s_class) - 2] == ':')
    {
        // eg 2.0
        return gqh(s_class);
    }
    else
    {
        // eg 2.1
        return gci(s_class);
    }
}

int send_req_port(int priority, unsigned short port)
{
    int sock;
    struct sockaddr_in server;

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0)
    {
        perror("Failed to create socket");
        return 1;
    }

    if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0)
    {
        perror("Failed to set socket priority");
        close(sock);
        return 1;
    }

    // Configure server address
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    if (inet_pton(AF_INET, PWN_DST_IP, &server.sin_addr) <= 0)
    {
        perror("Invalid address");
        close(sock);
        return 1;
    }

    // Send empty datagram
    if (sendto(sock, "", 0, 0, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("Failed to send");
        close(sock);
        return 1;
    }

    close(sock);
    return 0;
}

int send_req(int priority)
{
    int sock;
    struct sockaddr_in server;

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0)
    {
        perror("Failed to create socket");
        return 1;
    }

    if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0)
    {
        perror("Failed to set socket priority");
        close(sock);
        return 1;
    }

    // Configure server address
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(8888);
    if (inet_pton(AF_INET, PWN_DST_IP, &server.sin_addr) <= 0)
    {
        perror("Invalid address");
        close(sock);
        return 1;
    }

    // Send empty datagram
    if (sendto(sock, "", 0, 0, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("Failed to send");
        close(sock);
        return 1;
    }

    close(sock);
    return 0;
}

int send_req_noblock(int priority)
{
    int sock;
    struct sockaddr_in server;

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0)
    {
        perror("Failed to create socket");
        return 1;
    }

    if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0)
    {
        perror("Failed to set socket priority");
        close(sock);
        return 1;
    }

    // Set socket to non-blocking mode
    int flags = fcntl(sock, F_GETFL, 0);
    if (flags < 0)
    {
        perror("Failed to get socket flags");
        close(sock);
        return 1;
    }
    if (fcntl(sock, F_SETFL, flags | O_NONBLOCK) < 0)
    {
        perror("Failed to set socket to non-blocking");
        close(sock);
        return 1;
    }

    // Configure server address
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(8888);
    if (inet_pton(AF_INET, PWN_DST_IP, &server.sin_addr) <= 0)
    {
        perror("Invalid address");
        close(sock);
        return 1;
    }

    // Send empty datagram
    if (sendto(sock, "", 0, 0, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("Failed to send");
        close(sock);
        return 1;
    }

    close(sock);
    return 0;
}

int send_req_with_payload(int priority, const char *payload, const size_t payload_len)
{
    int sock;
    struct sockaddr_in server;

    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0)
    {
        perror("Failed to create socket");
        return 1;
    }

    // Set socket priority (equivalent to 0x10001)
    // int priority = 0x10001;
    if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0)
    {
        perror("Failed to set socket priority");
        close(sock);
        return 1;
    }

    // Configure server address
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(8888);
    if (inet_pton(AF_INET, PWN_DST_IP, &server.sin_addr) <= 0)
    {
        perror("Invalid address");
        close(sock);
        return 1;
    }

    // Send empty datagram
    if (sendto(sock, payload, payload_len, 0, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("Failed to send");
        close(sock);
        return 1;
    }

    close(sock);
    return 0;
}

#include <sys/ioctl.h>
// Checksum calculation for IP header
unsigned short in_cksum(unsigned short *addr, int len)
{
    int nleft = len;
    int sum = 0;
    unsigned short *w = addr;
    unsigned short answer = 0;

    while (nleft > 1)
    {
        sum += *w++;
        nleft -= 2;
    }

    if (nleft == 1)
    {
        *(unsigned char *)(&answer) = *(unsigned char *)w;
        sum += answer;
    }

    sum = (sum >> 16) + (sum & 0xffff);
    sum += (sum >> 16);
    answer = ~sum;
    return answer;
}

/**
 * Create a UDP packet with Ethernet, IP, and UDP headers
 */
void create_udp_packet(uint8_t *buffer, size_t *size,
                       const uint8_t *src_mac, const uint8_t *dst_mac,
                       const char *src_ip, const char *dst_ip,
                       uint16_t src_port, uint16_t dst_port,
                       const void *payload, size_t payload_size)
{

    // Make sure we don't exceed buffer size
    if (sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + payload_size > 1500)
    {
        fprintf(stderr, "Payload too large for Ethernet frame\n");
        *size = 0;
        return;
    }

    // Packet components
    struct ethhdr *eth = (struct ethhdr *)buffer;
    struct iphdr *ip = (struct iphdr *)(buffer + sizeof(struct ethhdr));
    struct udphdr *udp = (struct udphdr *)(buffer + sizeof(struct ethhdr) + sizeof(struct iphdr));
    uint8_t *data = buffer + sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr);

    // Clear buffer
    memset(buffer, 0, 1500);

    // Ethernet header
    memcpy(eth->h_dest, dst_mac, ETH_ALEN);
    memcpy(eth->h_source, src_mac, ETH_ALEN);
    eth->h_proto = htons(ETH_P_IP);

    // IP header
    ip->ihl = 5;     // Header length in 32-bit words (5 = 20 bytes)
    ip->version = 4; // IPv4
    ip->tos = 0;     // Type of service (0 = normal)
    ip->tot_len = htons(sizeof(struct iphdr) + sizeof(struct udphdr) + payload_size);
    ip->id = htons(rand() & 0xFFFF); // Random ID
    ip->frag_off = 0;                // No fragmentation
    ip->ttl = 64;                    // Time to live
    ip->protocol = IPPROTO_UDP;      // UDP protocol
    ip->check = 0;                   // Will calculate later
    ip->saddr = inet_addr(src_ip);   // Source IP
    ip->daddr = inet_addr(dst_ip);   // Destination IP

    // Calculate IP checksum
    ip->check = in_cksum((unsigned short *)ip, sizeof(struct iphdr));

    // UDP header
    udp->source = htons(src_port);
    udp->dest = htons(dst_port);
    udp->len = htons(sizeof(struct udphdr) + payload_size);
    udp->check = 0; // We'll leave UDP checksum as 0 (optional for IPv4)

    // Copy payload
    memcpy(data, payload, payload_size);

    // Set final size
    *size = sizeof(struct ethhdr) + sizeof(struct iphdr) + sizeof(struct udphdr) + payload_size;

    // Ensure minimum Ethernet frame size
    if (*size < ETH_ZLEN)
    {
        *size = ETH_ZLEN;
    }
}

/**
 * Send a packet to a multiqueue interface
 */
int send_packet_to_interface(const char *ifname, unsigned int queue_id, const void *packet, size_t packet_size, int noblock)
{
    int sock_fd;
    struct sockaddr_ll socket_address;
    struct ifreq if_req;
    int ret = -1;

    // Create a raw socket
    sock_fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (sock_fd < 0)
    {
        perror("socket creation failed");
        return -1;
    }

    // Get interface index
    memset(&if_req, 0, sizeof(if_req));
    strncpy(if_req.ifr_name, ifname, IFNAMSIZ - 1);
    if (ioctl(sock_fd, SIOCGIFINDEX, &if_req) < 0)
    {
        perror("SIOCGIFINDEX");
        close(sock_fd);
        return -1;
    }

    // Set up socket address structure
    memset(&socket_address, 0, sizeof(socket_address));
    socket_address.sll_family = AF_PACKET;
    socket_address.sll_protocol = htons(ETH_P_ALL);
    socket_address.sll_ifindex = if_req.ifr_ifindex;
    socket_address.sll_halen = ETH_ALEN;

    // Try to set queue selection via priority
    // int priority = queue_id;
    if (setsockopt(sock_fd, SOL_SOCKET, SO_PRIORITY, &queue_id, sizeof(queue_id)) < 0)
    {
        fprintf(stderr, "Warning: Setting priority failed: %s\n", strerror(errno));
    }

    if (noblock)
    {
        // Set socket to non-blocking mode
        int flags = fcntl(sock_fd, F_GETFL, 0);
        if (flags < 0)
        {
            perror("Failed to get socket flags");
            close(sock_fd);
            return 1;
        }
        if (fcntl(sock_fd, F_SETFL, flags | O_NONBLOCK) < 0)
        {
            perror("Failed to set socket to non-blocking");
            close(sock_fd);
            return 1;
        }

        // // After creating the socket, check its send buffer size
        // int sndbuf_size;
        // socklen_t optlen = sizeof(sndbuf_size);
        // if (getsockopt(sock_fd, SOL_SOCKET, SO_SNDBUF, &sndbuf_size, &optlen) == 0)
        // {
        //     printf("Socket send buffer size: %d bytes\n", sndbuf_size);
        // }

        // // Try increasing it
        // int new_sndbuf = 1024 * 1024; // 1MB
        // if (setsockopt(sock_fd, SOL_SOCKET, SO_SNDBUF, &new_sndbuf, sizeof(new_sndbuf)) < 0)
        // {
        //     perror("Failed to set SO_SNDBUF");
        // }
    }

    // Send the packet
    ret = sendto(sock_fd, packet, packet_size, 0,
                 (struct sockaddr *)&socket_address, sizeof(socket_address));

    if (ret < 0)
    {
        perror("sendto failed");
        close(sock_fd);
        return -1;
    }

    close(sock_fd);
    return 0;
}

// for src_port = 0xqrst, dst_port = 0xuvwx, offsets are 17: qr, 18: st, 19: uv, 20: wx
static int _send_mm0(uint16_t src_port, uint16_t dst_port, const char *payload, const size_t payload_size, unsigned int queue_id, int noblock)
{
    // MAC addresses
    uint8_t src_mac[6] = {0x00, 0x11, 0x22, 0x33, 0x44, 0x55}; // Source MAC
    uint8_t dst_mac[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}; // Broadcast

    // IP addresses
    char src_ip[] = "192.168.1.100";
    char dst_ip[] = "192.168.1.255"; // Broadcast

    // Buffer for our packet
    uint8_t packet[1500];
    size_t packet_size;

    // Create the UDP packet
    create_udp_packet(packet, &packet_size,
                      src_mac, dst_mac,
                      src_ip, dst_ip,
                      src_port, dst_port,
                      payload, payload_size);
    if (packet_size == 0)
    {
        fprintf(stderr, "Failed to create packet\n");
        return 1;
    }

    // Send the packet
    if (send_packet_to_interface("mm0", queue_id, packet, packet_size, noblock) != 0)
    {
        fprintf(stderr, "Failed to send packet\n");
        return 1;
    }

    return 0;
}

int send_mm0(uint16_t src_port, uint16_t dst_port)
{
    return _send_mm0(src_port, dst_port, "", 0, 0, 0);
}

int send_mm0_queue(uint16_t src_port, uint16_t dst_port, unsigned int queue_id)
{
    return _send_mm0(src_port, dst_port, "", 0, queue_id, 0);
}

int send_mm0_custom(uint16_t src_port, uint16_t dst_port, unsigned int queue_id, const char *payload, const size_t payload_size)
{
    return _send_mm0(src_port, dst_port, payload, payload_size, queue_id, 0);
}

int send_mm0_custom_noblock(uint16_t src_port, uint16_t dst_port, unsigned int queue_id, const char *payload, const size_t payload_size)
{
    return _send_mm0(src_port, dst_port, payload, payload_size, queue_id, 1);
}

#endif