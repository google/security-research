#ifndef PWN_IPLINK_H
#define PWN_IPLINK_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
// #include <net/if.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>

// Helper function to prepare and send netlink message
int send_netlink_message(int sock, struct nlmsghdr *nlh)
{
    struct sockaddr_nl nladdr = {0};
    struct iovec iov;
    struct msghdr msg = {0};
    
    nladdr.nl_family = AF_NETLINK;
    
    iov.iov_base = nlh;
    iov.iov_len = nlh->nlmsg_len;
    
    msg.msg_name = &nladdr;
    msg.msg_namelen = sizeof(nladdr);
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    
    return sendmsg(sock, &msg, 0);
}

int set_interface_flags(int sock, const char *ifname, int flags, int change)
{
    struct {
        struct nlmsghdr nlh;
        struct ifinfomsg ifm;
        char buf[64];
    } req;
    
    // Prepare the netlink request
    memset(&req, 0, sizeof(req));
    
    // Setup the netlink header
    req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
    req.nlh.nlmsg_type = RTM_SETLINK;
    req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
    req.nlh.nlmsg_seq = 1;
    
    // Setup the interface info message
    req.ifm.ifi_family = AF_UNSPEC;
    req.ifm.ifi_index = if_nametoindex(ifname);
    if (req.ifm.ifi_index == 0) {
        perror("if_nametoindex");
        close(sock);
        return -1;
    }
    
    // Set the interface flags
    req.ifm.ifi_change = change;
    req.ifm.ifi_flags = flags;
    
    // Send the netlink message
    if (send_netlink_message(sock, &req.nlh) < 0) {
        perror("send_netlink_message");
        close(sock);
        return -1;
    }
    
    // Read the ACK response
    char buf[4096];
    int len;
    struct nlmsghdr *resp_nlh;
    
    len = recv(sock, buf, sizeof(buf), 0);
    if (len < 0) {
        perror("recv");
        close(sock);
        return -1;
    }
    
    resp_nlh = (struct nlmsghdr *)buf;
    if (resp_nlh->nlmsg_type == NLMSG_ERROR) {
        struct nlmsgerr *err = NLMSG_DATA(resp_nlh);
        if (err->error != 0) {
            fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
            close(sock);
            return -1;
        }
    }
    return 0;
}

// Function to bring an interface up
int set_interface_up(int fd, const char *ifname)
{
    return set_interface_flags(fd, ifname, IFF_UP, IFF_UP);
}

// Function to bring an interface down
int set_interface_down(int fd, const char *ifname)
{
    return set_interface_flags(fd, ifname, 0, IFF_UP);
}

// Function to set interface MTU
int set_interface_mtu(int sock, const char *ifname, int mtu)
{
    struct {
        struct nlmsghdr nlh;
        struct ifinfomsg ifm;
        char buf[128];
    } req;
    struct rtattr *rta;
    
    // Create a netlink socket
    sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (sock < 0) {
        perror("socket");
        return -1;
    }
    
    // Prepare the netlink request
    memset(&req, 0, sizeof(req));
    
    // Setup the netlink header
    req.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ifinfomsg));
    req.nlh.nlmsg_type = RTM_SETLINK;
    req.nlh.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
    req.nlh.nlmsg_seq = 1;
    
    // Setup the interface info message
    req.ifm.ifi_family = AF_UNSPEC;
    req.ifm.ifi_index = if_nametoindex(ifname);
    if (req.ifm.ifi_index == 0) {
        perror("if_nametoindex");
        close(sock);
        return -1;
    }
    
    // Add the MTU attribute
    rta = (struct rtattr *)(((char *) &req) + NLMSG_ALIGN(req.nlh.nlmsg_len));
    rta->rta_type = IFLA_MTU;
    rta->rta_len = RTA_LENGTH(sizeof(int));
    memcpy(RTA_DATA(rta), &mtu, sizeof(int));
    req.nlh.nlmsg_len = NLMSG_ALIGN(req.nlh.nlmsg_len) + RTA_LENGTH(sizeof(int));
    
    // Send the netlink message
    if (send_netlink_message(sock, &req.nlh) < 0) {
        perror("send_netlink_message");
        close(sock);
        return -1;
    }
    
    // Read the ACK response
    char buf[4096];
    int len;
    struct nlmsghdr *resp_nlh;
    
    len = recv(sock, buf, sizeof(buf), 0);
    if (len < 0) {
        perror("recv");
        close(sock);
        return -1;
    }
    
    resp_nlh = (struct nlmsghdr *)buf;
    if (resp_nlh->nlmsg_type == NLMSG_ERROR) {
        struct nlmsgerr *err = NLMSG_DATA(resp_nlh);
        if (err->error != 0) {
            fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
            close(sock);
            return -1;
        }
    }
    
    return 0;
}

#endif