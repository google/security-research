#!/bin/bash
set -euo pipefail
make exp

mkdir -p out
cp exp out/