#ifndef PWN_PWN_ENV_H
#define PWN_PWN_ENV_H

// Write to a file so we can set our user ids
int write_mapping(const char *path, const char *content) {
    int fd = open(path, O_WRONLY);
    if (fd == -1) {
        printf("Failed to open %s: %s\n", path, strerror(errno));
        return -1;
    }
    
    if (write(fd, content, strlen(content)) != (ssize_t)strlen(content)) {
        printf("Failed to write to %s: %s\n", path, strerror(errno));
        close(fd);
        return -1;
    }
    close(fd);
    return 0;
}

void unshare_stuff(void) {
    // Unshare into new user namespace
    if (unshare(CLONE_NEWUSER | CLONE_NEWNET | CLONE_NEWNS) == -1) {
        printf("unshare failed: %s\n", strerror(errno));
        exit(-1);
    }

    // First disable setgroups
    if (write_mapping("/proc/self/setgroups", "deny") == -1) {
        printf("Failed to disable setgroups\n");
        exit(-1);
    }

    // Then map our UID and GID
    if (write_mapping("/proc/self/uid_map", "0 1000 1") == -1 ||
        write_mapping("/proc/self/gid_map", "0 1000 1") == -1) {
        printf("Failed to write ID mappings\n");
        exit(-1);
    }

    // // Bring up the loopback interface
    // printf("[>] Bringing up lo interface...\n");
    // if (system("./busybox ip link set lo up") != 0) {
    //     printf("Failed to bring up loopback interface.\n");
    //     exit(-1);
    // }
}

#endif