#ifndef PWN_QDISC_H
#define PWN_QDISC_H

// net/sched section begin
// TODO: verify that these structs are updated
// struct tc_estimator {
// 	signed char	interval;
// 	unsigned char	ewma_log;
// };

// https://elixir.bootlin.com/linux/v6.11/source/include/uapi/linux/pkt_sched.h#L68
#define TC_H_MAJ_MASK (0xFFFF0000U)
#define TC_H_MIN_MASK (0x0000FFFFU)
#define TC_H_MAJ(h) ((h)&TC_H_MAJ_MASK)
#define TC_H_MIN(h) ((h)&TC_H_MIN_MASK)
#define TC_H_MAKE(maj,min) (((maj)&TC_H_MAJ_MASK)|((min)&TC_H_MIN_MASK))

#define TC_H_UNSPEC	(0U)
#define TC_H_ROOT	(0xFFFFFFFFU)
#define TC_H_INGRESS    (0xFFFFFFF1U)
#define TC_H_CLSACT	TC_H_INGRESS

#define TC_H_MIN_PRIORITY	0xFFE0U
#define TC_H_MIN_INGRESS	0xFFF2U
#define TC_H_MIN_EGRESS		0xFFF3U

#include <sys/types.h>
unsigned int if_nametoindex(const char *ifname);

// https://github.com/pantoniou/iproute2/blob/master/tc/tc_util.c#L76
int get_qdisc_handle(__u32 *h, const char *str)
{
	*h = 0;
	__u32 maj;
	char *p;

	maj = TC_H_UNSPEC;
	if (strcmp(str, "none") == 0)
		goto ok;
	maj = strtoul(str, &p, 16);
	if (p == str || maj >= (1 << 16))
		return -1;
	maj <<= 16;
	if (*p != ':' && *p != 0)
		return -1;
ok:
	*h = maj;
	return 0;
}

int get_tc_classid(__u32 *h, const char *str)
{
	__u32 maj, min;
	char *p;

	maj = TC_H_ROOT;
	if (strcmp(str, "root") == 0)
		goto ok;
	maj = TC_H_UNSPEC;
	if (strcmp(str, "none") == 0)
		goto ok;
	maj = strtoul(str, &p, 16);
	if (p == str) {
		maj = 0;
		if (*p != ':')
			return -1;
	}
	if (*p == ':') {
		if (maj >= (1<<16))
			return -1;
		maj <<= 16;
		str = p+1;
		min = strtoul(str, &p, 16);
		if (*p != 0)
			return -1;
		if (min >= (1<<16))
			return -1;
		maj |= min;
	} else if (*p != 0)
		return -1;

ok:
	*h = maj;
	return 0;
}

// #define PWN_TC_QDISC_INTERFACE "lo"
#define PWN_TC_QDISC_INTERFACE "mm0"

int create_qdisc(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "drr");

	return netlink_send(sock_fd, nlh);
}

// struct tc_plug_qopt {
// 	/* TCQ_PLUG_BUFFER: Inset a plug into the queue and
// 	 *  buffer any incoming packets
// 	 * TCQ_PLUG_RELEASE_ONE: Dequeue packets from queue head
// 	 *   to beginning of the next plug.
// 	 * TCQ_PLUG_RELEASE_INDEFINITE: Dequeue all packets from queue.
// 	 *   Stop buffering packets until the next TCQ_PLUG_BUFFER
// 	 *   command is received (just act as a pass-thru queue).
// 	 * TCQ_PLUG_LIMIT: Increase/decrease queue size
// 	 */
// 	int             action;
// 	__u32           limit;
// };

int create_qdisc_plug1024(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "plug");
	
	struct tc_plug_qopt opt = {
		.limit = 4096
	};
	mnl_attr_put(nlh, TCA_OPTIONS, sizeof(struct tc_plug_qopt), &opt);
	
	return netlink_send(sock_fd, nlh);
}

int modify_qdisc_plug_unplug(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "plug");
	
	struct tc_plug_qopt opt = {
		.action = TCQ_PLUG_RELEASE_INDEFINITE,
	};
	mnl_attr_put(nlh, TCA_OPTIONS, sizeof(struct tc_plug_qopt), &opt);
	
	// return netlink_send(sock_fd, nlh);
	return netlink_send(sock_fd, nlh);
}

int modify_qdisc_plug_replug(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "plug");
	
	struct tc_plug_qopt opt = {
		.action = TCQ_PLUG_BUFFER,
	};
	mnl_attr_put(nlh, TCA_OPTIONS, sizeof(struct tc_plug_qopt), &opt);
	
	return netlink_send(sock_fd, nlh);
	// return netlink_send(sock_fd, nlh);
}


int create_qdisc_multiq(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "multiq");
	
	struct tc_multiq_qopt opt = {
		.bands = 3,
		.max_bands = 3
	}; // values don't actually matter, it's never used
	mnl_attr_put(nlh, TCA_OPTIONS, sizeof(struct tc_multiq_qopt ), &opt);
	
	return netlink_send(sock_fd, nlh);
}
int create_qdisc_prio(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "prio");
	
	struct tc_prio_qopt opt = {
		.bands = 3,
		.priomap = {0,1,2}
	};
	mnl_attr_put(nlh, TCA_OPTIONS, sizeof(struct tc_prio_qopt), &opt);
	
	return netlink_send(sock_fd, nlh);
}

int replace_qdisc_prio(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_REPLACE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "prio");
	
	struct tc_prio_qopt opt = {
		.bands = 3,
		.priomap = {0,1,2}
	};
	mnl_attr_put(nlh, TCA_OPTIONS, sizeof(struct tc_prio_qopt), &opt);
	
	return netlink_send(sock_fd, nlh);
}

int replace_qdisc_drr(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE | NLM_F_REPLACE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "drr");
	
	return netlink_send(sock_fd, nlh);
}


// struct tc_etf_qopt {
// 	__s32 delta;
// 	__s32 clockid;
// 	__u32 flags;
// #define TC_ETF_DEADLINE_MODE_ON	_BITUL(0)
// #define TC_ETF_OFFLOAD_ON	_BITUL(1)
// #define TC_ETF_SKIP_SOCK_CHECK	_BITUL(2)
// };

int create_qdisc_etf(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "etf");
	

	struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    
    // For DRR, you might want to set quantum (optional)
    // Default quantum is 2000 bytes
	struct tc_etf_qopt opt = {
		.delta = 0,
		.clockid = 11,  // CLOCK_TAI
		.flags = TC_ETF_SKIP_SOCK_CHECK
	};

	enum {
		TCA_ETF_UNSPEC,
		TCA_ETF_PARMS,
		__TCA_ETF_MAX,
	};

	mnl_attr_put(nlh, TCA_ETF_PARMS, sizeof(struct tc_etf_qopt), &opt);
    
    mnl_attr_nest_end(nlh, opts);
	
	return netlink_send(sock_fd, nlh);
}

int create_qdisc_fqcodel(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "fq_codel");
	

	struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    enum {
	TCA_FQ_CODEL_UNSPEC,
	TCA_FQ_CODEL_TARGET,
	TCA_FQ_CODEL_LIMIT,
	TCA_FQ_CODEL_INTERVAL,
	TCA_FQ_CODEL_ECN,
	TCA_FQ_CODEL_FLOWS,
	TCA_FQ_CODEL_QUANTUM,
	TCA_FQ_CODEL_CE_THRESHOLD,
	TCA_FQ_CODEL_DROP_BATCH_SIZE,
	TCA_FQ_CODEL_MEMORY_LIMIT,
	TCA_FQ_CODEL_CE_THRESHOLD_SELECTOR,
	TCA_FQ_CODEL_CE_THRESHOLD_MASK,
	__TCA_FQ_CODEL_MAX
};

	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_LIMIT, 0xffffffff); // never hit
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_TARGET, 0); // no delay
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_INTERVAL, 0); // no delay
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_FLOWS, 1); // deterministic sorting
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_MEMORY_LIMIT, 0xffffffff); // never hit
    
    mnl_attr_nest_end(nlh, opts);
	
	return netlink_send(sock_fd, nlh);
}

int modify_qdisc_fqcodel(int sock_fd, __u32 my_handle, __u32 parent_handle, __u32 limit) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "fq_codel");
	

	struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    enum {
	TCA_FQ_CODEL_UNSPEC,
	TCA_FQ_CODEL_TARGET,
	TCA_FQ_CODEL_LIMIT,
	TCA_FQ_CODEL_INTERVAL,
	TCA_FQ_CODEL_ECN,
	TCA_FQ_CODEL_FLOWS,
	TCA_FQ_CODEL_QUANTUM,
	TCA_FQ_CODEL_CE_THRESHOLD,
	TCA_FQ_CODEL_DROP_BATCH_SIZE,
	TCA_FQ_CODEL_MEMORY_LIMIT,
	TCA_FQ_CODEL_CE_THRESHOLD_SELECTOR,
	TCA_FQ_CODEL_CE_THRESHOLD_MASK,
	__TCA_FQ_CODEL_MAX
};

	// mnl_attr_put_u32(nlh, TCA_FQ_CODEL_LIMIT, limit);
	// mnl_attr_put_u32(nlh, TCA_FQ_CODEL_TARGET, 0);
	// mnl_attr_put_u32(nlh, TCA_FQ_CODEL_INTERVAL, 0);
	// mnl_attr_put_u32(nlh, TCA_FQ_CODEL_FLOWS, 1);
	// mnl_attr_put_u32(nlh, TCA_FQ_CODEL_MEMORY_LIMIT, 0xffffffff);
	(void)limit;
	
    
    mnl_attr_nest_end(nlh, opts);
	
	return netlink_send(sock_fd, nlh);
}

int replace_qdisc_fqcodel(int sock_fd, __u32 my_handle, __u32 parent_handle, __u32 limit) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_CREATE | NLM_F_REPLACE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "fq_codel");
	

	struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    enum {
	TCA_FQ_CODEL_UNSPEC,
	TCA_FQ_CODEL_TARGET,
	TCA_FQ_CODEL_LIMIT,
	TCA_FQ_CODEL_INTERVAL,
	TCA_FQ_CODEL_ECN,
	TCA_FQ_CODEL_FLOWS,
	TCA_FQ_CODEL_QUANTUM,
	TCA_FQ_CODEL_CE_THRESHOLD,
	TCA_FQ_CODEL_DROP_BATCH_SIZE,
	TCA_FQ_CODEL_MEMORY_LIMIT,
	TCA_FQ_CODEL_CE_THRESHOLD_SELECTOR,
	TCA_FQ_CODEL_CE_THRESHOLD_MASK,
	__TCA_FQ_CODEL_MAX
};

	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_LIMIT, limit);
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_TARGET, 0);
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_INTERVAL, 0);
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_FLOWS, 1);
	mnl_attr_put_u32(nlh, TCA_FQ_CODEL_MEMORY_LIMIT, 0xffffffff);
	
    
    mnl_attr_nest_end(nlh, opts);

	// return netlink_send(sock_fd, nlh);
	return netlink_send_noack(sock_fd, nlh);
}

int create_qdisc_hhf(int sock_fd, __u32 my_handle, __u32 parent_handle, const __u32 limit_) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "hhf");
	
	enum {
		TCA_HHF_UNSPEC,
		TCA_HHF_BACKLOG_LIMIT,
		TCA_HHF_QUANTUM,
		TCA_HHF_HH_FLOWS_LIMIT,
		TCA_HHF_RESET_TIMEOUT,
		TCA_HHF_ADMIT_BYTES,
		TCA_HHF_EVICT_TIMEOUT,
		TCA_HHF_NON_HH_WEIGHT,
		__TCA_HHF_MAX
	};

	struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    
	mnl_attr_put_u32(nlh, TCA_HHF_BACKLOG_LIMIT, limit_);
    
    mnl_attr_nest_end(nlh, opts);
	
	return netlink_send(sock_fd, nlh);
}

int create_qdisc_pfifo(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "pfifo");
	
	return netlink_send(sock_fd, nlh);
}

// struct tc_netem_qopt {
// 	__u32	latency;	/* added delay (us) */
// 	__u32   limit;		/* fifo limit (packets) */
// 	__u32	loss;		/* random packet loss (0=none ~0=100%) */
// 	__u32	gap;		/* re-ordering gap (0 for none) */
// 	__u32   duplicate;	/* random packet dup  (0=none ~0=100%) */
// 	__u32	jitter;		/* random jitter in latency (us) */
// };
// struct tc_netem_corrupt {
// 	__u32	probability;
// 	__u32	correlation;
// };
// enum {
// 	TCA_NETEM_UNSPEC,
// 	TCA_NETEM_CORR,
// 	TCA_NETEM_DELAY_DIST,
// 	TCA_NETEM_REORDER,
// 	TCA_NETEM_CORRUPT,
// 	TCA_NETEM_LOSS,
// 	TCA_NETEM_RATE,
// 	TCA_NETEM_ECN,
// 	TCA_NETEM_RATE64,
// 	TCA_NETEM_PAD,
// 	TCA_NETEM_LATENCY64,
// 	TCA_NETEM_JITTER64,
// 	TCA_NETEM_SLOT,
// 	TCA_NETEM_SLOT_DIST,
// 	__TCA_NETEM_MAX,
// };
#define NLMSG_TAIL(nmsg) \
	((struct rtattr *) (((void *) (nmsg)) + NLMSG_ALIGN((nmsg)->nlmsg_len)))

int create_qdisc_netem(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "netem");

	// struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    
	// copied from https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/q_netem.c#L437
	// because this protocol has such a stupid parser
	struct rtattr *tail = NLMSG_TAIL(nlh);

    struct tc_netem_qopt qopt = {
        .limit = 1000, 
        .latency = 0,  
        .jitter = 0,   
        .loss = 0,    
        .gap = 1,
        .duplicate = 0,
    };
	struct tc_netem_corrupt corrupt = {
		.probability = UINT32_MAX-1,
		.correlation = 30
	};

    mnl_attr_put(nlh, TCA_OPTIONS, sizeof(qopt), &qopt);
	mnl_attr_put(nlh, TCA_NETEM_CORRUPT, sizeof(corrupt), &corrupt);
	// struct nlattr *loss_opts = mnl_attr_nest_start(nlh, TCA_NETEM_LOSS);
	// mnl_attr_put_u32(nlh, TCA_HHF_BACKLOG_LIMIT, limit_);
	// mnl_attr_nest_end(nlh, loss_opts);

    tail->rta_len = (void *) NLMSG_TAIL(nlh) - (void *) tail;
	
	return netlink_send(sock_fd, nlh);
}

int create_qdisc_cake_v2(int sock_fd, __u32 my_handle, __u32 parent_handle, __u32 limit, __u32 cake_type) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "cake");

    struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
	if (limit)
    mnl_attr_put_u32(nlh, TCA_CAKE_MEMORY, limit);
	if (cake_type)
    mnl_attr_put_u32(nlh, TCA_CAKE_DIFFSERV_MODE, cake_type);
    mnl_attr_nest_end(nlh, opts);
	
	return netlink_send(sock_fd, nlh);
}

int create_qdisc_qfq(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "qfq");
	
	return netlink_send(sock_fd, nlh);
}

int create_qdisc_cake(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "cake");


	
	return netlink_send(sock_fd, nlh);
}

int replace_qdisc_cake(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "cake");

    struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    // mnl_attr_put_u32(nlh, TCA_CAKE_MEMORY, limit);
    mnl_attr_nest_end(nlh, opts);
	
	return netlink_send(sock_fd, nlh);
}


int create_qdisc_hfsc(int sock_fd, __u32 my_handle, __u32 parent_handle) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;


	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, "hfsc");

	struct tc_hfsc_qopt qopt = {};
    mnl_attr_put(nlh, TCA_OPTIONS, sizeof(qopt), &qopt);
	
	return netlink_send(sock_fd, nlh);
}

int delete_qdisc(int sock_fd, __u32 my_handle, __u32 parent_handle, const char* kind) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_DELQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L346
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, kind);

	return netlink_send(sock_fd, nlh);
}


int create_class(const int sock_fd, const __u32 child_handle, const __u32 parent_handle) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTCLASS;
    // Request + Create + Acknowledge + Exclusive
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_CREATE | NLM_F_ACK;

    // Add the TC message header
    struct tcmsg *tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    
    // Use the same interface as the parent qdisc
    unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
    if (ifindex == 0)
        fatal("ifindex");
    tcm->tcm_ifindex = ifindex;

    // Set up class handle and parent
    tcm->tcm_handle = child_handle;
    tcm->tcm_parent = parent_handle;  // Link to parent qdisc

    // Specify that this is a DRR class
    mnl_attr_put_strz(nlh, TCA_KIND, "drr");

    // Add DRR-specific parameters if needed
    struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    
    // For DRR, you might want to set quantum (optional)
    // Default quantum is 2000 bytes
    // mnl_attr_put_u32(nlh, TCA_DRR_QUANTUM, 2000);
    
    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

int create_class_custom(const int sock_fd, const __u32 child_handle, const __u32 parent_handle, const char* kind) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTCLASS;
    // Request + Create + Acknowledge + Exclusive
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_CREATE | NLM_F_ACK;

    // Add the TC message header
    struct tcmsg *tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    
    // Use the same interface as the parent qdisc
    unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
    if (ifindex == 0)
        fatal("ifindex");
    tcm->tcm_ifindex = ifindex;

    // Set up class handle and parent
    tcm->tcm_handle = child_handle;
    tcm->tcm_parent = parent_handle;  // Link to parent qdisc

    // Specify that this is a DRR class
    mnl_attr_put_strz(nlh, TCA_KIND, kind);

    // Add DRR-specific parameters if needed
    struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    
    // For DRR, you might want to set quantum (optional)
    // Default quantum is 2000 bytes
    // mnl_attr_put_u32(nlh, TCA_DRR_QUANTUM, 2000);
    
    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}

int create_class_hfsc(const int sock_fd, const __u32 child_handle, const __u32 parent_handle, struct tc_service_curve* rsc, struct tc_service_curve* fsc, struct tc_service_curve* usc) {
    char buf[0x1000] = {0};
    struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

    nlh->nlmsg_type = RTM_NEWTCLASS;
    // Request + Create + Acknowledge + Exclusive
    nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_EXCL | NLM_F_CREATE | NLM_F_ACK;

    // Add the TC message header
    struct tcmsg *tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
    
    // Use the same interface as the parent qdisc
    unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
    if (ifindex == 0)
        fatal("ifindex");
    tcm->tcm_ifindex = ifindex;

    // Set up class handle and parent
    tcm->tcm_handle = child_handle;
    tcm->tcm_parent = parent_handle;  // Link to parent qdisc

    // Specify that this is a DRR class
    mnl_attr_put_strz(nlh, TCA_KIND, "hfsc");

    // Add DRR-specific parameters if needed
    struct nlattr *opts = mnl_attr_nest_start(nlh, TCA_OPTIONS);
    
	if (rsc)
    mnl_attr_put(nlh, TCA_HFSC_RSC, sizeof(struct tc_service_curve), rsc);
	if (fsc)
    mnl_attr_put(nlh, TCA_HFSC_FSC, sizeof(struct tc_service_curve), fsc);
	if (usc)
    mnl_attr_put(nlh, TCA_HFSC_USC, sizeof(struct tc_service_curve), usc);
    
    mnl_attr_nest_end(nlh, opts);

    return netlink_send(sock_fd, nlh);
}


int replace_qdisc_parent(int sock_fd, __u32 my_handle, __u32 new_parent_handle, const char* kind) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_NEWQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L350
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_REPLACE | NLM_F_ACK | NLM_F_CREATE;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = new_parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, kind);

	return netlink_send(sock_fd, nlh);
}

int dump_qdisc(int sock_fd, __u32 my_handle, __u32 parent_handle, const char* kind) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_GETQDISC;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L350
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, kind);

	return netlink_send(sock_fd, nlh);
}

int dump_class(int sock_fd, __u32 my_handle, __u32 parent_handle, const char* kind) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_GETTCLASS;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L350
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK | NLM_F_DUMP;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, kind);

	return netlink_send(sock_fd, nlh);
}

int delete_class(int sock_fd, __u32 my_handle, __u32 parent_handle, const char* kind) {
	char buf[0x1000] = {0};
	struct nlmsghdr *nlh = mnl_nlmsg_put_header(buf);

	nlh->nlmsg_type = RTM_DELTCLASS;
	// https://github.com/pantoniou/iproute2/blob/f443565f8df65e7d3b3e7cb5f4e94aec1e12d067/tc/tc_qdisc.c#L350
	nlh->nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;

	struct tcmsg* tcm = mnl_nlmsg_put_extra_header(nlh, sizeof(struct tcmsg));
    tcm->tcm_family = AF_UNSPEC;
	unsigned int ifindex = if_nametoindex(PWN_TC_QDISC_INTERFACE);
	if (ifindex == 0)
		fatal("ifindex");
    tcm->tcm_ifindex = ifindex;  // Interface index (change as needed)
    tcm->tcm_handle = my_handle;
    tcm->tcm_parent = parent_handle;

	// policy use: https://elixir.bootlin.com/linux/v6.11/source/net/sched/sch_api.c#L1616
	mnl_attr_put_strz(nlh, TCA_KIND, kind);

	return netlink_send(sock_fd, nlh);
}

#endif