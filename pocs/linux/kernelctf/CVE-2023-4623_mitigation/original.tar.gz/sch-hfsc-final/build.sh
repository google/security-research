#!/bin/bash

gcc -L. -I/usr/include/libiptc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-mitigation-6.1-v2 exploit-mitigation-6.1-v2.c -pthread -lnl-cli-3 -lnl-route-3 -lnl-3 -ldl
