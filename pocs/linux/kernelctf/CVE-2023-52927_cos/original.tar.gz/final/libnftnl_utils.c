#include "./libnftnl_utils.h"
#include <libnftnl/chain.h>
#include <libnftnl/expr.h>
#include <libnftnl/object.h>
#include <linux/netfilter/nf_tables.h>
#include <stdint.h>

batch batch_init(size_t size) {
    void *buf = malloc(size);
    batch b = mnl_nlmsg_batch_start(buf, size);
    nftnl_batch_begin(mnl_nlmsg_batch_current(b), seq++);
    mnl_nlmsg_batch_next(b);
    rseq = seq;
    return b;
}

void batch_end(batch b) {
    nftnl_batch_end(mnl_nlmsg_batch_current(b), seq);
    mnl_nlmsg_batch_next(b);
}

ssize_t batch_send(batch b, sock s) { return mnl_socket_sendto(s, mnl_nlmsg_batch_head(b), mnl_nlmsg_batch_size(b)); }

void batch_free(batch b) {
    void *buf = mnl_nlmsg_batch_head(b);
    mnl_nlmsg_batch_stop(b);
    free(buf);
}

table make_table(const char *name, uint32_t family, const void *udata, uint32_t udlen) {
    table t = nftnl_table_alloc();
    if (t == NULL) {
        ERROR("Couldn't allocate a table");
        exit(EXIT_FAILURE);
    }

    nftnl_table_set_str(t, NFTNL_TABLE_NAME, name);

    if (udata != NULL && udlen > 0)
        nftnl_table_set_data(t, NFTNL_TABLE_USERDATA, udata, udlen);

    return t;
}

void batch_new_table(batch b, table t, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWTABLE, family, NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND, seq++);
    nftnl_table_nlmsg_build_payload(hdr, t);
    mnl_nlmsg_batch_next(b);
}

void batch_del_table(batch b, table t, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_DELTABLE, family, NLM_F_ACK, seq++);
    nftnl_table_nlmsg_build_payload(hdr, t);
    mnl_nlmsg_batch_next(b);
}

chain make_chain(const char *table, const char *name, uint32_t flags, uint32_t hooknum, uint32_t prio, char *type) {
    chain c = nftnl_chain_alloc();
    if (c == NULL) {
        ERROR("Couldn't allocate a chain");
        exit(EXIT_FAILURE);
    }

    nftnl_chain_set_str(c, NFTNL_CHAIN_TABLE, table);
    nftnl_chain_set_str(c, NFTNL_CHAIN_NAME, name);
    nftnl_chain_set_u32(c, NFTNL_CHAIN_FLAGS, flags);

    if (type)
        nftnl_chain_set_str(c, NFTNL_CHAIN_TYPE, type);

    if (hooknum != -1) {
        nftnl_chain_set_u32(c, NFTNL_CHAIN_HOOKNUM, hooknum);
        nftnl_chain_set_u32(c, NFTNL_CHAIN_PRIO, prio);
    }
    return c;
}

void batch_new_chain(batch b, chain c, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWCHAIN, family, NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND, seq++);
    nftnl_chain_nlmsg_build_payload(hdr, c);
    mnl_nlmsg_batch_next(b);
}

void batch_del_chain(batch b, chain c, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_DELCHAIN, family, NLM_F_ACK, seq++);
    nftnl_chain_nlmsg_build_payload(hdr, c);
    mnl_nlmsg_batch_next(b);
}

rule make_rule(const char *table, const char *chain, expr *exprs, size_t num_exprs, const void *udata, uint32_t udlen, uint64_t handle) {
    rule r = nftnl_rule_alloc();
    if (r == NULL) {
        ERROR("Couldn't allocate a rule");
        return NULL;
    }

    nftnl_rule_set_str(r, NFTNL_RULE_TABLE, table);
    nftnl_rule_set_str(r, NFTNL_RULE_CHAIN, chain);

    for (int i = 0; i < num_exprs; ++i)
        nftnl_rule_add_expr(r, exprs[i]);

    if (udlen > 0)
        nftnl_rule_set_data(r, NFTNL_RULE_USERDATA, udata, udlen);

    if (handle > 0)
        nftnl_rule_set_u64(r, NFTNL_RULE_HANDLE, handle);

    return r;
}

void batch_new_rule(batch b, rule r, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWRULE, family, NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND, seq++);
    nftnl_rule_nlmsg_build_payload(hdr, r);
    mnl_nlmsg_batch_next(b);
}

void batch_del_rule(batch b, rule r, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_DELRULE, family, NLM_F_ACK, seq++);
    nftnl_rule_nlmsg_build_payload(hdr, r);
    mnl_nlmsg_batch_next(b);
}

set make_set(const char *table, const char *name, uint32_t flags, uint32_t policy) {
    set s = nftnl_set_alloc();
    if (s == NULL) {
        ERROR("Couldn't allocate a set");
        exit(EXIT_FAILURE);
    }

    nftnl_set_set_str(s, NFTNL_SET_TABLE, table);
    nftnl_set_set_str(s, NFTNL_SET_NAME, name);
    nftnl_set_set_u32(s, NFTNL_SET_KEY_LEN, sizeof(uint16_t));
    nftnl_set_set_u32(s, NFTNL_SET_ID, 1);

    /* inet service type, see nftables/include/datatypes.h */
    nftnl_set_set_u32(s, NFTNL_SET_KEY_TYPE, 13);

    //   nftnl_set_set_u32(s, NFTNL_SET_GC_INTERVAL,
    //                     CVE_2023_4244_GC_INTERVAL); // CVE_2023_4244
    nftnl_set_set_u32(s, NFTNL_SET_FLAGS, flags);
    nftnl_set_set_u32(s, NFTNL_SET_DATA_TYPE, NFT_DATA_VERDICT);

    nftnl_set_set_u32(s, NFTNL_SET_POLICY, policy);

    nftnl_set_set_u32(s, NFTNL_SET_DESC_SIZE, 1); // rb_tree

    return s;
}

void batch_new_set(batch b, set s, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWSET, family, NLM_F_ACK | NLM_F_CREATE | NLM_F_APPEND, seq++);
    nftnl_set_nlmsg_build_payload(hdr, s);
    mnl_nlmsg_batch_next(b);
}

void batch_del_set(batch b, set s, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_DELSET, family, NLM_F_ACK, seq++);
    nftnl_set_nlmsg_build_payload(hdr, s);
    mnl_nlmsg_batch_next(b);
}

// static expr make_immediate_jump_expr(const char *target_chain) {
//   expr e = nftnl_expr_alloc("immediate");
//   if (e == NULL)
//     return NULL;

//   nftnl_expr_set_u32(e, NFTNL_EXPR_IMM_DREG, NFT_REG_VERDICT);
//   nftnl_expr_set_u32(e, NFTNL_EXPR_IMM_VERDICT, NFT_JUMP);
//   nftnl_expr_set_str(e, NFTNL_EXPR_IMM_CHAIN, target_chain);

//   return e;
// }

expr make_immediate_expr(uint32_t dreg, char *data) {
    expr e = nftnl_expr_alloc("immediate");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_IMM_DREG, dreg);
    nftnl_expr_set_str(e, NFTNL_EXPR_IMM_DATA, data);

    return e;
}

// static expr make_lookup_expr(const char *target_set, u_int32_t sreg,
//                              uint32_t dreg) {
//   expr e = nftnl_expr_alloc("lookup");
//   if (e == NULL)
//     return NULL;

//   nftnl_expr_set_str(e, NFTNL_EXPR_LOOKUP_SET, target_set);
//   nftnl_expr_set_u32(e, NFTNL_EXPR_LOOKUP_SREG, sreg);
//   nftnl_expr_set_u32(e, NFTNL_EXPR_LOOKUP_DREG, dreg);

//   return e;
// }

expr make_notrack_expr() { return nftnl_expr_alloc("notrack"); }

// static expr make_connlimit_expr() {
//   expr e = nftnl_expr_alloc("connlimit");
//   if (e == NULL)
//     return NULL;

//   nftnl_expr_set_u32(e, NFTNL_EXPR_CONNLIMIT_COUNT, 10);

//   return e;
// }

expr make_ct_set_expr(uint32_t sreg, uint32_t key) {
    expr e = nftnl_expr_alloc("ct");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_CT_KEY, key);
    nftnl_expr_set_u32(e, NFTNL_EXPR_CT_SREG, sreg);

    //   nftnl_expr_set_u32(e, NFTNL_EXPR_CT_DIR, ?); // optional

    return e;
}

expr make_ct_get_expr(uint32_t dreg, uint32_t key) {
    expr e = nftnl_expr_alloc("ct");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_CT_KEY, key); // fixed
    nftnl_expr_set_u32(e, NFTNL_EXPR_CT_DREG, dreg);

    //   nftnl_expr_set_u32(e, NFTNL_EXPR_CT_DIR, ?); // optional

    return e;
}

expr make_ct_set_zone_expr(uint32_t sreg) { return make_ct_set_expr(sreg, NFT_CT_ZONE); }

expr make_dup_ipv4_expr(uint32_t sreg_addr) {
    expr e = nftnl_expr_alloc("dup");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_DUP_SREG_ADDR, sreg_addr);

    return e;
}

expr make_queue_expr(uint16_t num, uint16_t total, uint16_t flags) {
    expr e = nftnl_expr_alloc("queue");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u16(e, NFTNL_EXPR_QUEUE_NUM, num);

    if (total)
        nftnl_expr_set_u16(e, NFTNL_EXPR_QUEUE_TOTAL, total);

    if (flags)
        nftnl_expr_set_u16(e, NFTNL_EXPR_QUEUE_FLAGS, flags);

    return e;
}

expr make_nat_expr(uint32_t type, uint32_t family, uint32_t reg_addr_min, uint32_t reg_proto_min, uint32_t flags) {
    expr e = nftnl_expr_alloc("nat");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_NAT_TYPE, type);
    nftnl_expr_set_u32(e, NFTNL_EXPR_NAT_FAMILY, family);
    nftnl_expr_set_u32(e, NFTNL_EXPR_NAT_REG_ADDR_MIN, reg_addr_min);
    nftnl_expr_set_u32(e, NFTNL_EXPR_NAT_REG_PROTO_MIN, reg_proto_min);
    nftnl_expr_set_u32(e, NFTNL_EXPR_NAT_FLAGS, flags);

    return e;
}

expr make_meta_get_expr(uint32_t dreg, uint32_t key) {
    expr e = nftnl_expr_alloc("meta");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_META_DREG, dreg);
    nftnl_expr_set_u32(e, NFTNL_EXPR_META_KEY, key);

    return e;
}

expr make_cmp_expr(uint32_t sreg, uint32_t cmp_op, uint32_t data) {
    expr e = nftnl_expr_alloc("cmp");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_CMP_SREG, sreg);
    nftnl_expr_set_u32(e, NFTNL_EXPR_CMP_OP, cmp_op);
    nftnl_expr_set_u32(e, NFTNL_EXPR_CMP_DATA, data);

    return e;
}

expr make_random_expr(uint32_t dreg, uint32_t modulus) {
    expr e = nftnl_expr_alloc("numgen");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_NG_TYPE, NFT_NG_RANDOM);
    nftnl_expr_set_u32(e, NFTNL_EXPR_NG_DREG, dreg);
    nftnl_expr_set_u32(e, NFTNL_EXPR_NG_MODULUS, modulus);

    return e;
}

expr make_log_expr(char *prefix) {
    expr e = nftnl_expr_alloc("log");
    if (e == NULL)
        return NULL;

    if (prefix) {
        nftnl_expr_set_str(e, NFTNL_EXPR_LOG_PREFIX, prefix);
    }
    nftnl_expr_set_u32(e, NFTNL_EXPR_LOG_LEVEL,
                       NFT_LOGLEVEL_AUDIT); // skip code

    return e;
}

expr make_payload_expr(uint32_t base, uint32_t offset, uint32_t len, uint32_t dreg) {
    expr e = nftnl_expr_alloc("payload");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_BASE, base);
    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_OFFSET, offset);
    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_LEN, len);
    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_DREG, dreg);

    return e;
}

expr make_payload_set_expr(uint32_t base, uint32_t offset, uint32_t len, uint32_t sreg) {
    expr e = nftnl_expr_alloc("payload");
    if (e == NULL)
        return NULL;

    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_BASE, base);
    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_OFFSET, offset);
    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_LEN, len);
    nftnl_expr_set_u32(e, NFTNL_EXPR_PAYLOAD_SREG, sreg);
    nftnl_expr_set_u32(e, NFTA_PAYLOAD_CSUM_TYPE, NFT_PAYLOAD_CSUM_NONE);

    return e;
}

// static set make_set_elems(const char *table, const char *set_name, uint16_t
// key,
//                           const char *target_chain) {
//   set s = nftnl_set_alloc();
//   if (s == NULL) {
//     ERROR("Couldn't allocate a set");
//     exit(EXIT_FAILURE);
//   }

//   set_elem e = nftnl_set_elem_alloc();
//   if (e == NULL) {
//     ERROR("Couldn't allocate a set elem");
//     exit(EXIT_FAILURE);
//   }

//   nftnl_set_set_str(s, NFTNL_SET_TABLE, table);
//   nftnl_set_set_str(s, NFTNL_SET_NAME, set_name);

//   if (key) {
//     nftnl_set_elem_set(e, NFTNL_SET_ELEM_KEY, &key, sizeof(key));
//   }

//   if (target_chain) {
//     nftnl_set_elem_set_u32(e, NFTNL_SET_ELEM_VERDICT, NFT_JUMP);
//     nftnl_set_elem_set_str(e, NFTNL_SET_ELEM_CHAIN, target_chain);
//   }

//   // nftnl_set_elem_set_u32(e, NFTNL_SET_ELEM_EXPIRATION,
//   // CVE_2023_4244_EXPIRATION); // CVE_2023_4244

//   nftnl_set_elem_add(s, e);

//   return s;
// }

// static set make_set_elems_catchall(const char *table, const char *name,
//                                    const char *target_chain) {
//   set s = nftnl_set_alloc();
//   if (s == NULL) {
//     ERROR("Couldn't allocate a set");
//     exit(EXIT_FAILURE);
//   }

//   set_elem e = nftnl_set_elem_alloc();
//   if (e == NULL) {
//     ERROR("Couldn't allocate a set elem");
//     exit(EXIT_FAILURE);
//   }

//   nftnl_set_set_str(s, NFTNL_SET_TABLE, table);
//   nftnl_set_set_str(s, NFTNL_SET_NAME, name);

//   nftnl_set_elem_set_u32(e, NFTNL_SET_ELEM_FLAGS, NFT_SET_ELEM_CATCHALL);

//   if (target_chain) {
//     nftnl_set_elem_set_u32(e, NFTNL_SET_ELEM_VERDICT, NFT_JUMP);
//     nftnl_set_elem_set_str(e, NFTNL_SET_ELEM_CHAIN, target_chain);
//   }

//   nftnl_set_elem_set_u64(e, NFTNL_SET_ELEM_EXPIRATION,
//                          CVE_2023_4244_EXPIRATION);     // CVE_2023_4244
//   nftnl_set_elem_set_u64(e, NFTNL_SET_ELEM_TIMEOUT, 1); // CVE_2023_4244

//   nftnl_set_elem_add(s, e);

//   return s;
// }

// static void batch_new_set_elems(batch b, set s) {
//   nlmsghdr hdr = nftnl_nlmsg_build_hdr(
//       (char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWSETELEM, family,
//       NLM_F_ACK | NLM_F_CREATE | NLM_F_EXCL, seq++);
//   nftnl_set_elems_nlmsg_build_payload(hdr, s);
//   mnl_nlmsg_batch_next(b);
// }

// static void batch_del_set_elems(batch b, set s) {
//   nlmsghdr hdr =
//       nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b),
//                             NFT_MSG_DELSETELEM, family, NLM_F_ACK, seq++);
//   nftnl_set_elems_nlmsg_build_payload(hdr, s);
//   mnl_nlmsg_batch_next(b);
// }

obj make_object(const char *table, const char *name, uint32_t type) {
    obj o = nftnl_obj_alloc();
    if (o == NULL) {
        ERROR("Couldn't allocate an object");
        exit(EXIT_FAILURE);
    }

    nftnl_obj_set_str(o, NFTNL_OBJ_TABLE, table);
    nftnl_obj_set_str(o, NFTNL_OBJ_NAME, name);
    nftnl_obj_set_u32(o, NFTNL_OBJ_TYPE, type);

    return o;
}

obj make_secmark_object(const char *table, const char *name, const char *secmark_ctx) {
    obj o = nftnl_obj_alloc();
    if (o == NULL) {
        ERROR("Couldn't allocate an object");
        exit(EXIT_FAILURE);
    }

    nftnl_obj_set_str(o, NFTNL_OBJ_TABLE, table);
    nftnl_obj_set_str(o, NFTNL_OBJ_NAME, name);
    nftnl_obj_set_u32(o, NFTNL_OBJ_TYPE, NFT_OBJECT_SECMARK);
    nftnl_obj_set_str(o, NFTNL_OBJ_SECMARK_CTX, secmark_ctx);

    return o;
}

void batch_new_object(batch b, obj o, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWOBJ, family, NLM_F_ACK, seq++);
    nftnl_obj_nlmsg_build_payload(hdr, o);
    mnl_nlmsg_batch_next(b);
}

flowtable make_flowtable(const char *table, const char *name, const char *devs[], uint32_t flags) {
    flowtable f = nftnl_flowtable_alloc();
    if (f == NULL) {
        ERROR("Couldn't allocate a flowtable");
        exit(EXIT_FAILURE);
    }

    nftnl_flowtable_set_str(f, NFTNL_FLOWTABLE_TABLE, table);
    nftnl_flowtable_set_str(f, NFTNL_FLOWTABLE_NAME, name);
    nftnl_flowtable_set_u32(f, NFTNL_FLOWTABLE_HOOKNUM,
                            NF_NETDEV_INGRESS); // flowtable hook is always NF_NETDEV_INGRESS
    nftnl_flowtable_set_u32(f, NFTNL_FLOWTABLE_PRIO,
                            0); // add flowtable with prio 0 or update hook but not update prio
    nftnl_flowtable_set_data(f, NFTNL_FLOWTABLE_DEVICES, devs, 0);
    nftnl_flowtable_set_u32(f, NFTNL_FLOWTABLE_FLAGS, flags);

    return f;
}

void batch_new_flowtable(batch b, flowtable f, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr((char *)mnl_nlmsg_batch_current(b), NFT_MSG_NEWFLOWTABLE, family, NLM_F_ACK, seq++);
    nftnl_flowtable_nlmsg_build_payload(hdr, f);
    mnl_nlmsg_batch_next(b);
}

// static nlmsghdr dump_rule(rule r, char *buf) {
//   nlmsghdr hdr =
//       nftnl_nlmsg_build_hdr(buf, NFT_MSG_GETRULE, family, NLM_F_ACK, seq++);
//   nftnl_rule_nlmsg_build_payload(hdr, r);
//   return hdr;
// }

int run_callbacks(sock s, mnl_cb_t cb, void *data) {
    // INFO("Start callback: rseq = %d, seq = %d", rseq, seq);
    char buf[MNL_SOCKET_BUFFER_SIZE];
    int ret = 0;
    while (rseq < seq) {
        ret = mnl_socket_recvfrom(s, buf, sizeof(buf));
        if (ret <= 0)
            break;
        ret = mnl_cb_run(buf, ret, rseq, mnl_socket_get_portid(s), cb, data);
        if (ret < 0)
            break;
        rseq += ret == 0;
    }
    // INFO("End callback: rseq = %d, seq = %d", rseq, seq);
    return ret;
}

nlmsghdr dump_rule(rule r, char *buf, uint32_t family) {
    nlmsghdr hdr = nftnl_nlmsg_build_hdr(buf, NFT_MSG_GETRULE, family, NLM_F_ACK, seq++);
    nftnl_rule_nlmsg_build_payload(hdr, r);
    return hdr;
}
