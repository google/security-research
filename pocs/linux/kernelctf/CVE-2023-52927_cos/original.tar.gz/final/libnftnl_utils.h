#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <linux/netfilter.h>
#include <linux/netfilter/nf_tables.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nfnetlink_queue.h>

#include <libmnl/libmnl.h>
#include <libnftnl/chain.h>
#include <libnftnl/expr.h>
#include <libnftnl/flowtable.h>
#include <libnftnl/object.h>
#include <libnftnl/rule.h>
#include <libnftnl/set.h>
#include <libnftnl/table.h>

#include <libnetfilter_queue/libnetfilter_queue.h>

/* only for NFQA_CT, not needed otherwise: */
#include <linux/netfilter/nfnetlink_conntrack.h>

#define INFO(fmt, ...) fprintf(stderr, "[*] " fmt "\n", ##__VA_ARGS__)
#define WARN(fmt, ...) fprintf(stderr, "[!] " fmt "\n", ##__VA_ARGS__)
#define ERROR(msg)                                                             \
  fprintf(stderr, "[-] %s:%d: %s: %s\n", __func__, __LINE__, msg,              \
          strerror(errno))

struct list_head {
  struct list_head *next, *prev;
};

struct rhash_head {
  struct rhash_head *next;
};

struct rhlist_head {
  struct rhash_head rhead;
  struct rhlist_head *next;
};

struct msg_msgseg {
  struct msg_msgseg *next;
};

struct nft_expr {
  struct nft_expr_ops *ops;
  unsigned char data[] __attribute__((aligned(__alignof__(uint64_t))));
};

struct nft_rule {
  struct list_head list;
  uint64_t handle : 42, genmask : 2, dlen : 12, udata : 1;
  unsigned char data[] __attribute__((aligned(__alignof__(struct nft_expr))));
};

struct nft_rule_dp {
  uint64_t is_last : 1, dlen : 12, handle : 42; /* for tracing */
  unsigned char data[] __attribute__((aligned(__alignof__(struct nft_expr))));
};

struct nft_rule_blob {
  unsigned long size;
  unsigned char data[]
      __attribute__((aligned(__alignof__(struct nft_rule_dp))));
};

struct nft_chain {
  struct nft_rule_blob *blob_gen_0;
  struct nft_rule_blob *blob_gen_1;
  struct list_head rules;
  struct list_head list;
  struct rhlist_head rhlhead;
  struct nft_table *table;
  uint64_t handle;
  uint32_t use;
  uint8_t flags : 5, bound : 1, genmask : 2;
  char *name;
  uint16_t udlen;
  uint8_t *udata;

  /* Only used during control plane commit phase: */
  struct nft_rule_blob *blob_next;
};

struct nft_userdata {
  uint8_t len;
  unsigned char data[];
};

typedef struct mnl_socket *sock;
typedef struct mnl_nlmsg_batch *batch;
typedef struct nlmsghdr *nlmsghdr;

typedef struct nftnl_table *table;
typedef struct nftnl_chain *chain;
typedef struct nftnl_set *set;
typedef struct nftnl_set_elem *set_elem;
typedef struct nftnl_rule *rule;
typedef struct nftnl_expr *expr;
typedef struct nftnl_obj *obj;
typedef struct nftnl_flowtable *flowtable;

static uint32_t seq = 1, rseq = 1;

batch batch_init(size_t size);
void batch_end(batch b);
ssize_t batch_send(batch b, sock s);
void batch_free(batch b);

table make_table(const char *name, uint32_t family, const void *udata,
                 uint32_t udlen);
void batch_new_table(batch b, table t, uint32_t family);
void batch_del_table(batch b, table t, uint32_t family);

chain make_chain(const char *table, const char *name, uint32_t flags,
                 uint32_t hooknum, uint32_t prio, char *type);
void batch_new_chain(batch b, chain c, uint32_t family);
void batch_del_chain(batch b, chain c, uint32_t family);

rule make_rule(const char *table, const char *chain, expr *exprs,
               size_t num_exprs, const void *udata, uint32_t udlen,
               uint64_t handle);
void batch_new_rule(batch b, rule r, uint32_t family);
void batch_del_rule(batch b, rule r, uint32_t family);

set make_set(const char *table, const char *name, uint32_t flags,
             uint32_t policy);
void batch_new_set(batch b, set s, uint32_t family);
void batch_del_set(batch b, set s, uint32_t family);

obj make_object(const char *table, const char *name, uint32_t type);
obj make_secmark_object(const char *table, const char *name, const char* secmark_ctx);
void batch_new_object(batch b, obj o, uint32_t family);

flowtable make_flowtable(const char *table, const char *name,
                         const char *devs[], uint32_t flags);
void batch_new_flowtable(batch b, flowtable f, uint32_t family);

expr make_immediate_expr(uint32_t dreg, char *data);
expr make_ct_set_expr(uint32_t sreg, uint32_t key);
expr make_ct_get_expr(uint32_t dreg, uint32_t key);
expr make_ct_set_zone_expr(uint32_t sreg);
expr make_dup_ipv4_expr(uint32_t sreg_addr);
expr make_queue_expr(uint16_t num, uint16_t total, uint16_t flags);
expr make_nat_expr(uint32_t type, uint32_t family, uint32_t reg_addr_min,
                   uint32_t reg_proto_min, uint32_t flags);
expr make_notrack_expr();
expr make_meta_get_expr(uint32_t dreg, uint32_t key);
expr make_cmp_expr(uint32_t sreg, uint32_t cmp_op, uint32_t data);
expr make_random_expr(uint32_t dreg, uint32_t modulus);
expr make_log_expr(char *prefix);
expr make_payload_expr(uint32_t base, uint32_t offset, uint32_t len, uint32_t dreg);
expr make_payload_set_expr(uint32_t base, uint32_t offset, uint32_t len, uint32_t sreg);

int run_callbacks(sock s, mnl_cb_t cb, void *data);

nlmsghdr dump_rule(rule r, char *buf, uint32_t family);
