#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-17800.147.60 exploit-17800.147.60.c  -pthread -lm -lkeyutils -laio -DDEBUG
