#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-6.1.77 exploit-6.1.77.c  -pthread -lm -lkeyutils
