#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-6.1.74 exploit-6.1.74.c  -pthread -lm 
