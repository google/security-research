#!/bin/bash

gcc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit exploit.c -pthread -lnftnl -lmnl -lnl-cli-3 -lnl-route-3 -lnl-3 -ldl

