#!/bin/bash

gcc -L. -I/usr/include/libiptc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-6.1.58 exploit-6.1.58.c  -pthread
