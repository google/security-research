#!/bin/bash

gcc -L. -I/usr/include/libiptc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-17412.156.69 exploit-17412.156.69.c  -pthread
