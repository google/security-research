#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-17412.294.29 exploit-17412.294.29.c -pthread -lm -lkeyutils -laio
