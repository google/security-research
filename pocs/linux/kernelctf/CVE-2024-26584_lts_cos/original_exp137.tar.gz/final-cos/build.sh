#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-17412.294.10 exploit-17412.294.10.c -pthread -lm -lkeyutils -laio
