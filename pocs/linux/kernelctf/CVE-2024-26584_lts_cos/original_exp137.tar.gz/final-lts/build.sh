#!/bin/bash

gcc -fomit-frame-pointer -g -static -o exploit-6.1.76 exploit-6.1.76.c  -pthread -lm -lkeyutils -laio
gcc -fomit-frame-pointer -g -static -o leak leak.c  -pthread -lm -lkeyutils 
