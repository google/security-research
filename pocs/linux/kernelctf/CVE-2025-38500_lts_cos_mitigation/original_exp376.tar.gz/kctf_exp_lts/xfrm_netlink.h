#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <netlink/msg.h>
#include <netlink/attr.h>
#include <netlink/netlink.h>


void create_xfrm_link_collect(struct nl_sock * socket, char *ifname){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * xfrm_data = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST | NLM_F_CREATE 
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));
    nla_put_flag(xfrm_data, IFLA_XFRM_COLLECT_METADATA);
    nla_put_string(link_info, IFLA_INFO_KIND, "xfrm");
    nla_put_nested(link_info, IFLA_INFO_DATA, xfrm_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len); 
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}

void create_xfrm_link_with_ifid(struct nl_sock * socket, char *ifname, uint32_t id){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * xfrm_data = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST | NLM_F_CREATE 
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));
    nla_put_u32(xfrm_data, IFLA_XFRM_LINK, 0);
    nla_put_u32(xfrm_data, IFLA_XFRM_IF_ID, id);
    nla_put_string(link_info, IFLA_INFO_KIND, "xfrm");
    nla_put_nested(link_info, IFLA_INFO_DATA, xfrm_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);
    nla_put_u32(msg, IFLA_NUM_TX_QUEUES, 0x80);
    nla_put_u32(msg, IFLA_NUM_RX_QUEUES, 0x100);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len); 
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    } else {
    }
}

void change_xfrm_link(struct nl_sock * socket, char *ifname, uint32_t id){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * xfrm_data = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_NEWLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST 
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));
    nla_put_u32(xfrm_data, IFLA_XFRM_LINK, 0);
    nla_put_u32(xfrm_data, IFLA_XFRM_IF_ID, id);
    nla_put_string(link_info, IFLA_INFO_KIND, "xfrm");
    nla_put_nested(link_info, IFLA_INFO_DATA, xfrm_data);
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    nla_put_nested(msg, IFLA_LINKINFO, link_info);
    nla_put_string(msg, IFLA_IFNAME, ifname);

    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len); 
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);

    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    }
}

void delete_xfrm_link(struct nl_sock * socket, char *ifname){
    struct nl_msg * msg = nlmsg_alloc();
    struct nl_msg * link_info = nlmsg_alloc();
    struct nl_msg * xfrm_data = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            RTM_DELLINK,   // TYPE
            sizeof(struct ifinfomsg),
            NLM_F_REQUEST 
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg));
    memset(h, 0, sizeof(struct ifinfomsg));
    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg));
    nla_put_string(msg, IFLA_IFNAME, ifname);

    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len); 
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    nlmsg_free(msg);
    if (res < 0) {
        fprintf(stderr, "sending message failed\n");
    }
}
