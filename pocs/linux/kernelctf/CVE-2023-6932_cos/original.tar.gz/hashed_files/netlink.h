#ifndef __H_NETLINK
#define __H_NETLINK

#include <stdint.h>
#include <stddef.h>

#include <linux/netlink.h>

typedef uint16_t u16;

int netlink_open(int proto);

int netlink_recv(int fd, void* nlh, size_t size);

int __netlink_send(int fd, const void* nlh, size_t size);
static inline int netlink_send(int fd, const struct nlmsghdr* nlh) {
    return __netlink_send(fd, nlh, nlh->nlmsg_len);
}

int netlink_errno(const struct nlmsghdr* nlh);

void netlink_attr_put(struct nlmsghdr* nlh, u16 nla_type, const void* data, u16 data_len);
void netlink_attr_put_nested(struct nlattr* attr, u16 nla_type, const void* data, u16 data_len);

#endif /* __H_NETLINK */
