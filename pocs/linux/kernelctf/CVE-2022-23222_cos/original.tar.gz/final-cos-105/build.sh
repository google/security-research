#!/bin/bash

gcc -O2 -g -static -o exploit-5.15.133 exploit-5.15.133.c  -pthread -lm -ldl -DDEBUG
gcc -O2 -fomit-frame-pointer -g -static -o exploit-17412.294.62 exploit-17412.294.62.c  -pthread -lm -ldl -DDEBUG
