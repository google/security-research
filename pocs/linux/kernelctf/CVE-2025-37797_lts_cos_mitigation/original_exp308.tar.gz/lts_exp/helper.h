#ifndef PWN_HELPER_H
#define PWN_HELPER_H

#define _GNU_SOURCE
#include <stdio.h>
#include <sched.h>
#include <err.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stddef.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/xattr.h>
#include <netinet/ip.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <libmnl/libmnl.h>
#include <sys/auxv.h>
#include <sys/sendfile.h>
#include <libnftnl/table.h>
#include <libnftnl/flowtable.h>
#include <libnftnl/chain.h>
#include <libnftnl/rule.h>
#include <libnftnl/expr.h>
#include <libnftnl/object.h>
#include <linux/if_packet.h>
#include <net/ethernet.h> /* the L2 protocols */
#include <sys/socket.h>
#include <linux/netfilter.h>
#include <linux/netfilter/nf_tables.h>
#include <linux/if_link.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <sys/resource.h>
#include <linux/if.h>
#include <linux/keyctl.h>
#include <byteswap.h>
#include <linux/netfilter/ipset/ip_set.h>
#include <linux/netfilter/ipset/ip_set_bitmap.h>
#include <err.h>
#include <linux/if_ether.h>
#include <linux/tc_act/tc_gact.h>
#include <linux/pkt_cls.h>
#include <limits.h>

void fatal(const char *msg)
{
	printf("[Fatal!] ");
	puts(msg);
	fflush(stdout);
	fflush(stderr);
	exit(EXIT_FAILURE);
}

#define SYSCHK(x) ({              \
	typeof(x) __res = (x);        \
	if (__res == (typeof(x))-1)   \
		err(1, "SYSCHK(" #x ")"); \
	__res;                        \
})

#define SYSOK(x) ({                     \
	typeof(x) __res = (x);              \
	if (__res != (typeof(x))0)          \
		err(1, "[fail] SYSOK(" #x ")"); \
	__res;                              \
})

void set_cpu(int c)
{
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(c, &mask);
	sched_setaffinity(0, sizeof(mask), &mask);
}
#include <errno.h>
char nlbuf[4096]; // Buffer to store the response
int __netlink_send(int fd, const void *nlh, size_t size)
{
	struct iovec iov = {
		.iov_base = (void *)nlh,
		.iov_len = size,
	};
	struct msghdr msg = {
		.msg_name = NULL,
		.msg_namelen = 0,
		.msg_iov = &iov,
		.msg_iovlen = 1,
		.msg_control = NULL,
		.msg_controllen = 0,
		.msg_flags = 0,
	};

	if (sendmsg(fd, &msg, 0) < 0)
	{
		perror("sendmsg()");
		return -1;
	}

	memset(nlbuf, 0, sizeof(nlbuf));
	// Now, receive the response

	ssize_t ret = recvfrom(fd, nlbuf, sizeof(nlbuf), 0, NULL, NULL);
	if (ret == -1)
	{
		perror("recvfrom()");
		return -1;
	}

	struct nlmsghdr *response_nlh = (struct nlmsghdr *)nlbuf;

	// Check if the message type is an acknowledgment of success or failure
	// if (response_nlh->nlmsg_type == NLMSG_ERROR)
	{
		struct nlmsgerr *err = (struct nlmsgerr *)NLMSG_DATA(response_nlh);
		if (err->error)
		{
			fprintf(stderr, "Netlink Result: %s\n", strerror(-err->error));
		}
		return -err->error;
		// return -1;
	}

	// return 0;
}

static inline int netlink_send(int fd, const struct nlmsghdr *nlh)
{
	return __netlink_send(fd, nlh, nlh->nlmsg_len);
}

static inline int netlink_send_noack(int fd, const struct nlmsghdr *nlh)
{
	size_t size = nlh->nlmsg_len;
	struct iovec iov = {
		.iov_base = (void *)nlh,
		.iov_len = size,
	};
	struct msghdr msg = {
		.msg_name = NULL,
		.msg_namelen = 0,
		.msg_iov = &iov,
		.msg_iovlen = 1,
		.msg_control = NULL,
		.msg_controllen = 0,
		.msg_flags = 0,
	};

	if (sendmsg(fd, &msg, 0) < 0)
	{
		perror("sendmsg()");
		return -1;
	}

	return 0;
}

int netlink_open(int proto)
{
	struct sockaddr_nl addr = {0};
	addr.nl_family = AF_NETLINK;

	int s = socket(AF_NETLINK, SOCK_RAW, proto);
	if (s < 0)
	{
		perror("socket()");
		return s;
	}
	if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) == -1)
	{
		perror("bind()");
		return -1;
	}

	return s;
}

void cyclic(char *s, size_t n)
{
	unsigned char seq[4] = {0, 0, 0, 0};
	for (size_t i = 0; i * 4 < n; i++)
	{
		for (size_t j = 0; j < n - i * 4; j++)
		{
			s[i * 4 + j] = seq[3 - j] + 'a';
		}

		// increment loop
		if (++seq[3] == 26)
		{
			seq[3] = 0;
			if (++seq[2] == 26)
			{
				seq[2] = 0;
				if (++seq[1] == 26)
				{
					seq[1] = 0;
					++seq[0];
				}
			}
		}
	}
}

void mypause()
{
	printf("[~] pausing... (press enter to continue)\n");
	char scratch[11];
	read(0, scratch, 10); // wait for input
}

#include "utils/qdisc.h"
#include "utils/tc_filters.h"

// end qdisc section

#endif