#!/bin/bash

gcc -L. -I/usr/include/libiptc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-6.1.36 exploit-6.1.36.c -pthread -lip4tc -lnl-cli-3 -lnl-route-3 -lnl-3 -ldl
gcc -L. -I/usr/include/libiptc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-mitigation exploit-mitigation.c -pthread -lip4tc -lnl-cli-3 -lnl-route-3 -lnl-3 -ldl
gcc -L. -I/usr/include/libiptc -I/usr/include/libnl3 -fomit-frame-pointer -g -static -o exploit-17162.127.42 exploit-17162.127.42.c -pthread -lip4tc -lnl-cli-3 -lnl-route-3 -lnl-3 -ldl
