from Crypto.Cipher import AES
import struct

def generate_tls_record(plaintext, key, salt, rec_seq_int, content_type=b'\x17'):
    """
    Generates a raw TLS 1.2 record with AES-CCM-128 encryption.

    Args:
        plaintext (bytes): The data to encrypt.
        key (bytes): The 128-bit (16-byte) encryption key.
        salt (bytes): The 4-byte salt.
        rec_seq_int (int): The record sequence number as an integer.
        content_type (bytes, optional): The TLS record content type. 
                                        Defaults to b'\x17' (Application Data).

    Returns:
        bytes: The raw TLS 1.2 record.
    """
    # Convert the integer sequence number to an 8-byte big-endian byte string
    rec_seq_bytes = rec_seq_int.to_bytes(8, 'big')

    # TLS protocol version for TLS 1.2
    tls_version = b'\x03\x03'

    # The 12-byte nonce is the 4-byte salt plus the 8-byte explicit sequence number
    nonce = salt + rec_seq_bytes

    # Construct the Additional Authenticated Data (AAD) for integrity protection
    # AAD = seq_num + TLSCompressed.type + TLSCompressed.version + TLSCompressed.length
    aad = rec_seq_bytes + content_type + tls_version + struct.pack('!H', len(plaintext))

    # Initialize AES-CCM cipher with a 16-byte (128-bit) authentication tag
    cipher = AES.new(key, AES.MODE_CCM, nonce=nonce, mac_len=16)
    
    # Provide the AAD to the cipher
    cipher.update(aad)
    
    # Encrypt the plaintext and get the authentication tag
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)

    # The encrypted payload for AEAD ciphers in TLS is: nonce_explicit + aead_ciphertext
    encrypted_payload = rec_seq_bytes + ciphertext + tag

    # Construct the 5-byte TLS record header: Type (1) + Version (2) + Length (2)
    record_header = content_type + tls_version + struct.pack('!H', len(encrypted_payload))

    # The final raw TLS record to be sent
    raw_tls_record = record_header + encrypted_payload

    return raw_tls_record

def format_as_c_array(data, var_name="tls_record"):
    """Formats a bytes object into a C-style unsigned char array."""
    hex_values = [f"0x{byte:02x}" for byte in data]
    c_array = f"unsigned char {var_name}[] = {{\n    "
    
    for i in range(0, len(hex_values), 12):
        line = ", ".join(hex_values[i:i+12])
        c_array += line
        if i + 12 < len(hex_values):
            c_array += ",\n    "
    
    c_array += "\n};\n"
    c_array += f"unsigned int {var_name}_len = sizeof({var_name});"
    
    return c_array

if __name__ == '__main__':
    # Static parameters
    key = b'\x00' * 16
    salt = b'\x00' * 4
    
    # Define an array of plaintexts to send (already as bytes)
    plaintexts = [
        b"Hello world",
        b"Hello world",
        b"Hello world"
    ]
    content_types = [b"\x17", b"\x16", b"\x17"]
    
    # Initialize the record sequence number
    current_sequence_number = 0

    # Loop through plaintexts and generate records
    for i, plaintext_bytes in enumerate(plaintexts):
        
        # Generate the TLS record. We don't need to pass content_type
        # as we are using the default value (0x17).
        tls_record = generate_tls_record(
            plaintext_bytes, 
            key, 
            salt, 
            current_sequence_number,
            content_types[i]
        )
        
        # Format the output as a unique C array
        c_array_output = format_as_c_array(tls_record, f"tls_record_{i+1}")
        
        # We decode the plaintext bytes here only for the comment generation
        print(f"/* MESSAGE {i+1}: Raw TLS 1.2 record for plaintext: '{plaintext_bytes.decode()}' */")
        print(f"/* Sequence Number: {current_sequence_number} */")
        print(f"/* Content Type: 0x{b'\x17'.hex()} (Application Data) */")
        print(f"/* Total length: {len(tls_record)} bytes */")
        print(c_array_output)
        print("\n" + "="*50 + "\n")
        
        # CRITICAL: Increment the sequence number for the next message
        current_sequence_number += 1

